﻿$(document).ready(function () {
  console.log('Carousel slider loaded.');
  let data = [];
  data.push({ id: '0', text: 'Bart 1', img: 'http://localhost:15536/images/thumbs/0000003_basketball-jersey.png' });
  data.push({ id: '1', text: 'Homer 2', img: 'http://localhost:15536/images/thumbs/0000005_basketball-shorts.png' });
  data.push({ id: '2', text: 'Marge 3', img: 'http://localhost:15536/images/thumbs/0000018_shorts.png' });
  data.push({ id: '3', text: 'Maggie 4', img: 'http://localhost:15536/images/thumbs/0000017_socks.png' });
  data.push({ id: '4', text: 'Lisa 5', img: 'http://localhost:15536/images/thumbs/0000019_t-shirt.png' });

  //data.push({ id: '5', text: 'Millhouse 6', img: 'http://localhost:15536/images/thumbs/0000003_basketball-jersey_415.png' });
  //data.push({ id: '6', text: 'Ned 7', img: 'http://localhost:15536/images/thumbs/0000003_basketball-jersey_415.png' });
  //data.push({ id: '7', text: 'Mr. Burns 8', img: 'http://localhost:15536/images/thumbs/0000003_basketball-jersey_415.png' });
  //data.push({ id: '8', text: 'Moe 9', img: 'http://localhost:15536/images/thumbs/0000003_basketball-jersey_415.png' });

  // Creating SVG and path elements and insert to DOM

  var svgNS = 'http://www.w3.org/2000/svg';
  var svgEl = document.createElementNS(svgNS, 'svg');

  var pathEl = document.createElementNS(svgNS, 'path');
  // The `getSinPath` function return the `path` in String format
  // pathEl.setAttribute('d', getSinPath());

  //var sinPath = 'M 1000 50 Q 1950 450 700 900 Q 300 1050 600 1200';

  //var sinPath = 'M 975 0 Q 1650 75 1425 300 Q 875 850 275 575';
  //var sinPath = 'M 975 0 Q 1875 75 1525 350 Q 875 850 275 575';
  //var sinPath = 'M 975 0 Q 1875 75 1525 350 Q 875 775 225 500';
  var sinPath = 'M 975 0 Q 1875 75 1525 300 Q 875 700 225 475';

  pathEl.setAttribute('d', sinPath);

  pathEl.setAttribute('class', 'path-slider__path');

  svgEl.appendChild(pathEl);
  document.body.appendChild(svgEl);

  let slider$ = $('.path-slider');
  for (let i = 0; i < 5; i++) {
    let anchor = `
      <a
        href="#"
        class="path-slider__item size-${i}"
        data-idx="${data[i].id}" >
        <div 
          class="item__circle"
          style="background-image: url('${data[i].img}')"
        >
        </div>
      </a>
    `
    slider$.append(anchor);
  }

  // Changing `background-image`
  // Firstly, saving the computed `background` of each item, as these are defined in CSS
  // When item is selected, the `background` is set accordingly

  var items = document.querySelectorAll('.path-slider__item');
  var images = [];
  for (var j = 0; j < items.length; j++) {
    images.push(
      getComputedStyle(
        items[j].querySelector('.item__circle')
      ).getPropertyValue('background-image')
    );
  }

  var imgAnimation;
  var lastIndex;
  var setBackgroundImage = function (index) {
    if (imgAnimation) {
      imgAnimation.pause();
      sliderContainer.style['background-image'] = images[lastIndex];
      sliderContainerBackground.style['opacity'] = 0;
    }
    lastIndex = index;
    // sliderContainerBackground.style['background-image'] = images[index];
    // imgAnimation = anime({
    //   targets: sliderContainerBackground,
    //   opacity: 1,
    //   easing: 'linear',
    // });
  };

  // Adding the extra element needed to fade the images smoothly
  // Also set the image for the initial current item (the first one)
  let x = $("<div />").appendTo("body");
  x.attr('class', "path-slider");

  let sliderContainer = document.querySelector('.path-slider');
  let sliderContainerBackground = document.createElement('div');
  sliderContainerBackground.setAttribute('class', 'path-slider__background');
  setBackgroundImage(0);
  sliderContainer.appendChild(sliderContainerBackground);

  // Initializing the slider

  let carouselWindow = {
    start: 0,
    end: 4,
    windowSize: 5,
    items: 8
  };

  let startIndex = 2;

  let options = {
    startLength: 'three-fourths',
    paddingSeparation: 100,
    easing: 'easeOutCubic',
    beginAll: function (params) {
      //console.log('begin all event', params);
      //console.log('moved:', params.newPositionIndex - params.oldPositionIndex);

      //let moveWindow = params.newPositionIndex - params.oldPositionIndex;

      //carouselWindow.start = carouselWindow.start + moveWindow;
      //carouselWindow.end = carouselWindow.end + moveWindow;
      //console.log('carousel', carouselWindow);

      //item[startIndex].querySelector('div')
      //  .style.backgroundImage = `url('${data[startIndex + 4].img}')`;
      //startIndex++;
      //if (startIndex > 4) {
      //  startIndex == 0;
      //}

    },
    endAll: function () {
      console.log('end all event');

      $('.path-slider__item').attr('href', "#");
      $('.size-0').attr('href',
          "http://localhost:15536/basketball-jersey#/customise/43867856?categoryPathIds=43870966&basketIndex=2");
    },
    begin: function (params) {
      // Item get selected, then set the `background` accordingly
      console.log('begin', params);

      let remove = `size-${params.oldPositionIndex}`;
      let add = `size-${params.newPositionIndex}`;

      params.node.classList.remove(remove);
      params.node.classList.add(add);

      let idx = params.node.getAttribute("data-idx");
      // console.log("idx", idx);

      // if (params.oldPositionIndex == 1 && params.newPositionIndex == 2) {
      //   // rotate clockwise 1
      //   params.node.querySelector(
      //     'div'
      //   ).style.backgroundImage = `url('${data[6].img}')`;
      // }

      if (params.selected) {
        setBackgroundImage(params.index);
      }
    },
  };

  var slider = new PathSlider(pathEl, '.path-slider__item', options);

  // Regenerate the SVG `path` and update items position on `resize` event (responsive behavior)

  window.addEventListener('resize', function () {
    // pathEl.setAttribute('d', getSinPath());
    pathEl.setAttribute('d', sinPath);
    slider.updatePositions();
  });
});
