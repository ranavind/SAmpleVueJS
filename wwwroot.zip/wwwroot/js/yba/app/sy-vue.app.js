((sy) => {

  class ServiceBusEvent{
    constructor(){
        this.events = {};
    }

    on(eventName, fn) {
        this.events[eventName] = this.events[eventName] || [];
        this.events[eventName].push(fn);
    }

    off(eventName, fn) {
        if (this.events[eventName]) {
            for (var i = 0; i < this.events[eventName].length; i++) {
                if (this.events[eventName][i] === fn) {
                    this.events[eventName].splice(i, 1);
                    break;
                }
            };
        }
    }

    trigger(eventName, data) {
        if (this.events[eventName]) {
            this.events[eventName].forEach(function(fn) {
                fn(data);
            });
        }
    }
  }

  // Application State Tree
  const store = new Vuex.Store({});

  // Register state modules
  sy.stateModules.forEach(x => store.registerModule(x.name, x.module));

  // Create the app
  const syApp = Vue.createApp({});
  syApp.config.globalProperties.$bus = new ServiceBusEvent();
  syApp.use(store);
  sy.syApp = syApp;

  // Register components
  sy.components.forEach(c => {
    syApp.component(c.element, c.component);
  });

  // Start the app
  syApp.mount('#syApp');

  // Prevent scroll problem on Mobile
  document.ontouchmove = (e) => e.preventDefault();

})(sy);
