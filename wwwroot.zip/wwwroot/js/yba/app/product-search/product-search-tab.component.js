((sy) => {
  sy.components.push({
    id: "productSearchTab",
    element: "sy-product-search-tab",
    component: {
      name: "productSearchTab",
      computed: {
        isPreviewVisible() {
          return this.$store.getters.productSearch_IsPreviewVisible
        }
      },
      template: `
        <div class="product-search-tab">
          <div class="product-search-container" v-if="!isPreviewVisible">
            <sy-product-search-filter></sy-product-search-filter>
            <sy-product-search-results></sy-product-search-results>
          </div>
          <sy-product-preview v-else></sy-product-preview>
        </div>
      `,
    },
  });
})(sy);
