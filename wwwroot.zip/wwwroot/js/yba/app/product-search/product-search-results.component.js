/// <reference path="../../../newproductscreen.js" />
((sy) => {
  sy.components.push({
    id: "productSearchResults",
    element: "sy-product-search-results",
    component: {
      name: "productSearchResults",
      data() {
        return {
          productViewport: null,
          productList: null,
          scrollTop: 0
        };
      },
      computed: {
        products() {
          // if (this.productList) {
          //   console.log('Scroll to:', this.scrollTop);
          //   document.getElementById('productSearchViewPort').scrollTop = this.scrollTop;
          // }
          return this.$store.getters.productSearch_SearchResultProducts;
        },
        isPreviewVisible() {
          return this.$store.getters.productSearch_IsPreviewVisible
        },
        searchMessage() {
          return this.$store.getters.productSearch_SearchMessage;
        },
        searchInProgress() {
          return this.$store.getters.productSearch_searchInProgress;
        },
      },
      methods: {
        onPreview(selectedProductIndex) {
          this.$store.commit('productsSearch_setPrevewProductIndex', selectedProductIndex);
          this.$store.dispatch('productSearch_ShowPreview');
          this.$store.dispatch('productSearch_SelectProduct');
        },
        onScroll() {
          this.productViewport = $('#productSearchViewPort');
          this.productList = $('#productList');

          //List height
          const scrollHeight = this.productList.height();

          //scroll position
          var scrollPos = this.productViewport.height() + this.productViewport.scrollTop();

          // fire if the scroll position is 300 pixels above the bottom of the viewer
          if (((scrollHeight - 300) >= scrollPos) / scrollHeight == 0) {
            this.scrollTop = document.getElementById('productSearchViewPort').scrollTop;
            this.$store.dispatch('productSearch_LoadMoreProducts');
          }
          console.log('Scrolled', scrollHeight, scrollPos);
        }
      },
      template: `
     
              <div class="row row-cols-2 row-cols-sm-2 row-cols-md-2 row-cols-lg-2 d-flex justify-content-center" id="productList" v-if="products.length > 0 && !searchInProgress">
                <div class="col" v-for="(product, index) in products" :key="product.id" @click="onPreview(index)">
<label>{{ product.name }}</label>                 
<img :src="product.image" class="img-fluid"  />
                  
                </div>
              </ul>

            </div>
       
      `,
    },
  });
})(sy);
