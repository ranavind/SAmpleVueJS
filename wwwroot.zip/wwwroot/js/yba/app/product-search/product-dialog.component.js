((sy) => {
  sy.components.push({
    id: "productSearchDialog",
    element: "sy-product-dialog",
    component: {
      name: "productSearchDialog",
      computed: {
        isVisible() {
          return this.$store.getters.productSearch_IsVisible;
        },
        selectedTab() {
          return this.$store.getters.productSearch_selectedTab;
        }
      },
      methods: {
        onModalClick(event) {
          event.cancelBubble = true;
          event.preventDefault();
        },
        onCloseDialog() {
          this.$store.commit("toolbar_ClearSelectedTool");
          this.$store.dispatch('productSearch_HideDialog');
        }
      },
      template: `
        <div id="productDialog" class="sy-product-search-modal" :style="{ 'display': isVisible ? 'block' : 'none', 'visibility': isVisible ? 'visible' : 'hidden' }">
          <div class="sy-modal-container">
            <div class="sy-modal-title">
              Catalog
            </div>
            <div class="sy-modal-header">
              <span class="sy-modal-close" @click="onCloseDialog()">
                <i class="fas fa-times"></i>
              </span>
            </div>
            <div class="sy-modal-tabs">
              <ul>
                <li :class="{ 'active': selectedTab === 1 }" @click="$store.commit('productSearch_SetSelectedTab', 1)">Search</li>
              </ul>
            </div>
            <div class="sy-modal-body">
              <sy-product-search-tab v-if="selectedTab === 1"></sy-product-search-tab>
            </div>
          </div>
        </div>
      `,
    },
  });
})(sy);
