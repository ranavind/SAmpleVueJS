(sy => {
  sy.components.push({
    id: 'productPreview',
    element: 'sy-product-preview',
    component: {
      name: 'productPreview',
      computed: { 
        product() {
          return this.$store.getters.productSearch_PrevewProduct;
        }
      },
      template: `
        <div class="preview-container">
          <div class="image-container">
            <img id="previewFileBytes" :src="product.image" />
            <div class="product-description">
              <h2 class="title">{{ product.name }}</h2>
              <p class="description" v-html="product.fullDescription"></p>
            </div>
          </div>
          <div class="preview-buttons">
            <button type="button" class="discard-btn" @click="$store.dispatch('productSearch_HidePreview')">Back</button>
            <button type="button" class="select-btn" @click="$store.dispatch('productSearch_SelectProduct')">Select</button>
          </div>
        </div>
      `
    }
  });
})(sy);