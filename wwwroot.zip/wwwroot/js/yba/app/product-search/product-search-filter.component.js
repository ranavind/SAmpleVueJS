((sy) => {
  sy.components.push({
    id: "productSearchFilter",
    element: "sy-product-search-filter",
    component: {
      name: "productSearchFilter",
      data() {
        return {
          shirts: [{ key: 'all', text: 'All' }, { key: 'short sleeve t', text: 'Short Sleeve T' }, { key: 'long sleeve t', text: 'Long Sleeve T' }, { key: 'hoodie', text: 'Hoodie' }],
          themes: [{ key: 'all', text: 'All' }, { key: 'gaming', text: 'Gaming' }, { key: 'animals', text: 'Animals' }, { key: 'food', text: 'Food' }, { key: 'random', text: 'Random/Goofy/Funny' }, { key: 'fantasy', text: 'Fantasy' }],
         // fits: [{ key: 'all', text: 'All' }, { key: 'unisex', text: 'Unisex' }, { key: 'women', text: 'Women' }, { key: 'men', text: 'Men' }, { key: 'youth', text: 'Youth' }],
          prints: [{ key: 'all', text: 'All' }, { key: 'DTG', text: 'Direct to Garment' }, { key: 'Sublimation', text: 'Sublimation' }],
          materials: [{ key: 'all', text: 'All' }],
          fits: [
            { id: 1, text: 'Women', value: 'Women', selected: 'false', isactive: '', target: "pills-women" },
            { id: 2, text: 'Men', value: 'Men', selected: 'true', isactive: 'active', target: "pills-Men" },
            { id: 3, text: 'Youth', value: 'Youth', selected: 'false', isactive: '', target: "pills-youth" },
          ],
        };
      },
      computed: {
        isExpanded() {
          return this.$store.getters.productSearch_SearchIsExpanded;
        },
        filterKeywords: {
          get() {
            return this.$store.getters.productSearch_FilterKeywords
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterKeywords", value);
          }
        },
        filterShirts: {
          get() {
            return this.$store.getters.productSearch_FilterShirts;
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterShirts", value);
          }
        },
        filterFits: {
          get() {
            return this.$store.getters.productSearch_FilterFits;
          },
          set(value) {
            console.log(value);
            this.$store.commit("productSearch_SetFilterFits", value);
          }
        },
        filterThemes: {
          get() {
            return this.$store.getters.productSearch_FilterThemes;
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterThemes", value);
          }
        },
        filterPrints: {
          get() {
            return this.$store.getters.productSearch_FilterPrints;
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterPrints", value);
          }
        },
        filterMaterials: {
          get() {
            this.$store.getters.productSearch_FilterMaterials;
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterMaterials", value);
          }
        }
      },
      methods: {
        warn: function (message, event) {
          // now we have access to the native event
          for (i = 0; i < this.fits.length; i++) {

            if (this.fits[i].text === message) {
              this.fits[i].isactive = "active";
              //this.filterFits.set(this.fits[i].target);
              this.$store.commit("productSearch_SetFilterFits", this.fits[i].value);
            }
            else {
              this.fits[i].isactive = "";
             // this.$store.commit("productSearch_SetFilterFits", "All");
            }
            // <------ ... IT WORKS
          }
          this.$store.commit('productSearch_ClearProducts');
          this.$store.dispatch('productSearch_executeSearch');
        },
        onSearch(e) {
          e.preventDefault();
          e.stopPropagation();

          this.$store.commit('productSearch_ClearProducts');
          this.$store.dispatch('productSearch_executeSearch');

          // This handles a phenomenon in IOS where the screen 
          // scrolls up when the virtual keyboard opens and does not scroll
          // back.  This is a manual intervention.
          this.scrollTop();
        },
        onExpand() {
          this.$store.commit("productSearch_ToggleSearchExpanded", !this.isExpanded);
        },
        onFocus(e) {
          this.scrollTop();
        },
        scrollTop() {
          window.scrollTo(0, 0);
          document.body.scrollTop = 0;
        }
      },
      template: `
        <ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="tablist">
              <template v-for="item in fits" :key="item.text">
              <li  class="nav-item" role="tab">
             <button v-model="filterFits" class="nav-link rounded-pill px-4 me-2" :class="item.isactive"  v-bind:id="item.target +'-tab'" data-bs-toggle="pill"
                             v-bind:data-bs-target="'#'+item.target" type="button" role="tab" :aria-controls="item.target"
                            :aria-selected="item.selected" v-on:click="warn(item.text, $event)">
                        {{item.text}}
                    </button>
              </li>
          </template>
          </ul>        
<div class="search-filter-container" :class="{ expanded: isExpanded }">
          <div class="search-filter-title">
            <span v-if="isExpanded">
              Search Filters
            </span>
            <button @click="onExpand()">
              <i v-if="isExpanded" class="fas fa-times fa-lg"></i>
              <i v-else class="fas fa-search fa-lg"></i>
            </button>
          </div>
          <form class="search-filter-criteria" v-if="isExpanded">
            <dl>
              <dt><label>Search:</label></dt>
              <dd><input type="text" v-model="filterKeywords" placeholder="keywords" maxlength="200" @focus="onFocus($event)" @blur="onFocus($event)" /></dd>

              <dt><label>Shirt:</label></dt>
              <dd>
                <select v-model="filterShirts">
                  <option v-for="item in shirts" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd>
 
              <dt><label>Fit:</label></dt>
              <dd>
                <select v-model="filterFits">
                  <option v-for="item in fits" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd>
 
              <dt><label>Theme:</label></dt>
              <dd>
                <select v-model="filterThemes">
                  <option v-for="item in themes" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd>
 
              <dt><label>Print:</label></dt>
              <dd>
                <select v-model="filterPrints">
                  <option v-for="item in prints" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd>

              <!-- <dt><label>Material:</label></dt>
              <dd>
                <select v-model="filterMaterials">
                  <option v-for="item in materials" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd> -->
            </dl>
            <button class="search-btn" type="submit" @click="onSearch($event)">
              Search
            </button>
          </form>
        </div>
      `,
    },
  });
})(sy);
