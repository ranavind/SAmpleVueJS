((sy) => {
  sy.components.push({
    element: 'sy-sharing',
    component: {
      id: 'Sharing',
      computed: {
        isVisible() {
          if (this.$store.getters.sharing_shareStreamsAreVisible) {
            const productContainer = document.getElementById('productContainer');
            productContainer.classList.add('friend-share');
          } else {
            const productContainer = document.getElementById('productContainer');
            if (productContainer) {
              productContainer.classList.remove('friend-share');
            }
          }
          return this.$store.getters.sharing_shareStreamsAreVisible;
        }
      },
      beforeMount() {
        this.$bus.on('product_beforeProductChange', data => {
          console.log('pause sharing');
          this.$store.dispatch('sharing_pauseSharing');
        });

        this.$bus.on('product_loaded', data => {
          if (this.$store.getters.sharing_isSharing) {
            this.$store.dispatch('sharing_shareRenderer');
          }
        });
      },
      template: `
        <div v-if="isVisible">
          <sy-sharing-local></sy-sharing-local>
          <sy-sharing-remote></sy-sharing-remote>
        </div>
        <sy-sharing-dialog></sy-sharing-dialog>
      `
    }
  });
})(sy);