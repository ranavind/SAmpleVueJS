((sy) => {

  window.yba = window.yba ||
  {
    sharing: {}
  };

  window.yba.sharing = {
    hub: null,
    peer: null,
    remoteVideoStream: null,
    remoteCanvasStream: null,
    localVideoStream: null,
    initiator: false,
  };

  sy.stateModules.push({
    name: 'webRtc',
    module: {
      state: () => ({
        shareDialogIsVisible: false,
        shareDialogStep: 1,
        shareStreamsAreVisible: false,

        localUserName: '',
        localSignalRId: '',
        localRtcConnectionId: '',

        remoteUserName: '',
        remoteSignalRId: '',
        remoteRtcConnectionId: '',
        remoteSignalReceived: false,

        peerConnectionError: null,
        iceServers: null,
        initiator: false,
        isSharing: false,
        nextStreamType: ''
      }),
      mutations: {
        sharing_setLocalUserName(state, userName) {
          state.localUserName = userName;
        },
        sharing_setLocalSignalRId(state, localSignalRId) {
          state.localSignalRId = localSignalRId;
        },
        sharing_setLocalRtcId(state, localRtcId) {
          state.localRtcConnectionId = localRtcId
        },

        sharing_setRemoteUserName(state, userName) {
          state.remoteUserName = userName;
        },
        sharing_setRemoteSignalRId(state, signalRId) {
          state.remoteSignalRId = signalRId;
        },
        sharing_setRemoteRtcId(state, remoteRtcId) {
          state.remoteRtcConnectionId = remoteRtcId;
        },

        sharing_showDialog(state, dialogStep) {
          state.shareDialogIsVisible = true;
          state.shareDialogStep = dialogStep || 1;
        },

        sharing_hideDialog(state) {
          state.shareDialogIsVisible = false;
        },

        sharing_setDialogStep(state, step) {
          state.shareDialogStep = step;
        },

        sharing_showShareStreams(state) {
          state.shareStreamsAreVisible = true;
        },
        sharing_hideShareStreamsAreVisible(state) {
          state.shareStreamsAreVisible = false;
        },

        sharing_setPeerConnectionError(state, error) {
          state.peerConnectionError = error;
        },

        sharing_setRemoteSignalReceived(state, value) {
          state.remoteSignalReceived = value;
        },

        sharing_setIceServers(state, iceServers) {
          state.iceServers = iceServers;
        },

        sharing_setInitiator(state, initiator) {
          state.initiator = initiator;
          yba.sharing.initiator = initiator;
        },

        sharing_setIsSharing(state, value) {
          state.isSharing = value;
        },

        sharing_setNextStreamType(state, value) {
          state.nextStreamType = value;
        }
      },
      actions: {
        // transaction.dispatch('sharing_createPeer', true);
        // yba.sharing.initiator = initiator;

        async sharing_connectSignalR(transaction) {

          if (yba.sharing.hub && yba.sharing.hub.connection.connectionState == "Connected") {
            return;
          }

          yba.sharing.hub = new signalR.HubConnectionBuilder()
            .withUrl('/signalrtc')
            .build();

          // Receive RTC connection info peer info from
          yba.sharing.hub.on('SendRtcSignal', (remoteSignalRId, remoteRtcId) => {
            // console.log('SignalR RTC Received', remoteSignalRId, remoteRtcId);
            transaction.commit('sharing_setRemoteSignalRId', remoteSignalRId);
            transaction.dispatch('sharing_receiveRemoteRtcSignal', remoteRtcId);
          });
          await yba.sharing.hub.start();

          transaction.commit('sharing_setLocalSignalRId', yba.sharing.hub.connection.connectionId);
        },

        async sharing_receiveRemoteRtcSignal(transaction, remoteRtcId) {
          transaction.commit('sharing_setRemoteRtcId', remoteRtcId);
          yba.sharing.peer.signal(JSON.parse(remoteRtcId));
          // console.log('Peer.signal sent to remote peer.');
        },

        async sharing_getIceServers(transaction) {
          try {
            if (transaction.state.iceServers) { return; }
            
            const response = await axios({
              method: 'get',
              url: `/api/LiveShareApi/IceServers`
            });
              
            const iceServers = response.data;
            transaction.commit('sharing_setIceServers', iceServers);
            // console.log('Ice Servers Retrieved: ', iceServers);
          }
          catch (error) {
            // console.log('Error getting Ice Servers: ', error);
          }
        },

        // Create the RTC Peer Connection
        sharing_createPeer(transaction) {
          if (yba.sharing.peer) {
            return;
          }

          const peer = new SimplePeer({
            initiator: yba.sharing.initiator,
            trickle: true,
            iceServers: transaction.state.iceServers
          });
          yba.sharing.peer = peer;

          peer.on('error', error => { transaction.dispatch('sharing_onPeerError', error); });
          peer.on('signal', localPeerInfo => { transaction.dispatch('sharing_onPeerSignal', localPeerInfo); });
          peer.on('connect', () => { transaction.dispatch('sharing_onPeerConnect'); });
          peer.on('stream', stream => { transaction.dispatch('sharing_onPeerStream', stream); });
          peer.on('data', data => { transaction.dispatch('sharing_onPeerData', data); });
        },

        async sharing_onPeerSignal(transaction, localPeerInfo) {

          // 1. Save the local RTC connection info
          const localPeerRtcConnection = JSON.stringify(localPeerInfo);
          transaction.commit('sharing_setLocalRtcId', localPeerRtcConnection);

          // 2. Send the local RTC connection info to the peer via SginalR
          // console.log('Transmitting Web RTC via SignalR to Peer', localPeerInfo);
          try {
            await yba.sharing.hub
              .invoke('SendRtcSignal', localPeerRtcConnection, transaction.state.remoteSignalRId);
          }
          catch (err) {
            console.log(err);
            transaction.commit('sharing_setPeerConnectionError', err);

            // Show error to user
            transaction.commit('sharing_showDialog', 5);
          }
        },

        sharing_onPeerConnect(transaction) {
          console.log('Peer connected to remote');
          yba.sharing.peer.send('Hello Peer! ' + Math.random());
          sy.syApp.config.globalProperties.$bus.trigger('sharing_start');

          // Display prompt to share stream
          transaction.commit('sharing_showDialog', 4);
        },

        sharing_onPeerError(transaction, error) {
          console.log('Simple Peer Error: ', error);
          transaction.commit('sharing_setPeerConnectionError', error);

          // Show error to user
          transaction.commit('sharing_showDialog', 5);
        },

        sharing_onPeerStream(transaction, stream) {
          // Display streams
          transaction.commit('sharing_showShareStreams');

          console.log('Peer stream received');

          if (transaction.state.nextStreamType == 'transmit:renderer') {
            yba.sharing.remoteCanvasStream = stream;
            setTimeout(() => {
              sy.syApp.config.globalProperties.$bus.trigger('sharing_playRemoteRenderer', stream);
            }, 100);

            console.log('Sending renderer acknowledgement');
            yba.sharing.peer.send('acknowledge:renderer');
          } else if (transaction.state.nextStreamType == 'transmit:camera') {
            yba.sharing.remoteVideoStream = stream;
            setTimeout(() => {
              sy.syApp.config.globalProperties.$bus.trigger('sharing_playRemoteVideo', stream);
            }, 100);

            console.log('Sending renderer acknowledgement');
            yba.sharing.peer.send('acknowledge:camera');
          }
        },

        sharing_onPeerData(transaction, data) {
          const value = new TextDecoder("utf-8").decode(data);
          console.log('received data', value);

          if (value.indexOf('transmit') > -1) {
            transaction.commit('sharing_setNextStreamType', value);
            return;
          }

          if (value.indexOf('acknowledge') > -1) {
            transaction.dispatch('sharing_streamAcknowledged', value);
            return;
          }
          
          if (value == 'stop' || data == 'stop') {
            console.log('Sharing stopped by remote.');
            transaction.dispatch('sharing_stopShare');
            return;
          } 
        },

        sharing_startStreamSharing(transaction) {
          transaction.commit('sharing_setIsSharing', true);

          // Display streams
          transaction.commit('sharing_showShareStreams');

          // 3D renderer stream
          transaction.dispatch('sharing_shareRenderer');

          console.log('Hide share dialog');
          transaction.commit('sharing_hideDialog');
        },

        sharing_shareRenderer(transaction) {
          console.log('start streaming renderer');
          try {
            yba.sharing.peer.send('transmit:renderer');

            const canvas = document.querySelector('canvas');
            const canvasStream = canvas.captureStream(30);

            // let options = {
            //   audioBitsPerSecond : 128000,
            //   videoBitsPerSecond : 2500000,
            //   mimeType : 'video/mp4'
            // }
            // let mediaRecorder = new MediaRecorder(canvasStream,options);
            // debugger;

            yba.sharing.localCanvasStream = canvasStream;
            yba.sharing.peer.addStream(canvasStream);
            console.log('Canvas stream added to peer');
          } catch (err) {
            console.log('Canvas renderer stream error: ', err);
          }
        },

        async sharing_shareCamera(transaction) {
          console.log('start streaming camera');
          try {
            yba.sharing.peer.send('transmit:camera');

            if (!navigator || !navigator.mediaDevices) return;
            const videoStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });

            // Save reference to the stream
            yba.sharing.localVideoStream = videoStream;
            yba.sharing.peer.addStream(videoStream);

            sy.syApp.config.globalProperties.$bus.trigger('sharing_playLocalVideo', videoStream);

            console.log('Video stream added to peer');
          } catch (err) {
            console.log('video stream error: ', err)
          }
        },

        sharing_streamAcknowledged(transaction, data) {

          if (data.indexOf('renderer') > -1) {
            // After the stream has been acknowledged by remote:
            // Rotate the renderer from front 
            // This will create some activity to update the canvas on the remote computer
            setTimeout(() => { 
              angular.element(document.querySelector('.kb-preview-panel')).scope().changeView(1);
              setTimeout(() => angular.element(document.querySelector('.kb-preview-panel')).scope().changeView(0), 1000);
            }, 1000);

            // Video Camera Stream
            if (yba.sharing.localVideoStream == null) {
              transaction.dispatch('sharing_shareCamera');
            }
          }
        },
        
        sharing_pauseSharing(transaction) {
          transaction.dispatch("sharing_stopShareRenderer");
        },

        sharing_stopShare(transaction) {
          if (yba.sharing.peer) {
            transaction.commit('sharing_setIsSharing', false);

            transaction.commit('sharing_hideShareStreamsAreVisible');
            yba.sharing.peer.send('stop');

            transaction.dispatch('sharing_stopShareVideo');
            transaction.dispatch('sharing_stopShareRenderer');

            yba.sharing.peer.destroy();

            sy.syApp.config.globalProperties.$bus.trigger('sharing_end');
            yba.sharing.peer = null;
          }
        },

        sharing_stopShareRenderer() {
          try {
            console.log('Stop sharing renderer.');
            if (yba.sharing.localCanvasStream) {
              const tracks = yba.sharing.localCanvasStream.getTracks();
              tracks.forEach(function (track) {
                track.stop();
              });
              yba.sharing.peer.removeStream(yba.sharing.localCanvasStream);
              yba.sharing.localCanvasStream = null;
            }
          } catch (e) {
            console.error('Error stopping local canvas renderer share.', e);
          }
        },

        sharing_stopShareVideo() {
          try {
            if (yba.sharing.localVideoStream) {
              const tracks = yba.sharing.localVideoStream.getTracks();
              tracks.forEach(function (track) {
                track.stop();
              });
              yba.sharing.peer.removeStream(yba.sharing.localVideoStream);
              yba.sharing.localVideoStream = null;
            }
          } catch (e) {
            console.error('Error stopping local video share.', e);
          }
        }
      },
      getters: {
        sharing_shareDialogIsVisible: (state => state.shareDialogIsVisible),
        sharing_shareDialogStep: (state => state.shareDialogStep),
        sharing_shareStreamsAreVisible: (state => state.shareStreamsAreVisible),

        sharing_localSignalRId: (state => state.localSignalRId),
        sharing_localUserName: (state => state.localUserName),

        sharing_remoteSignalRId: (state => state.remoteSignalRId),
        sharing_remoteUserName: (state => state.remoteUserName),

        sharing_isSharing: (state) => state.isSharing,
      },
    },
  });
})(sy);
