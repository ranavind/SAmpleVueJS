((sy) => {
  sy.components.push({
    element: 'sy-sharing-dialog',
    component: {
      id: 'SharingDialog',
      data() {
        return {
          dialogVisible: false,
          isConnecting: false
        }
      },
      computed: {
        shareDialogIsVisible() {
          if (this.$store.getters.sharing_shareDialogIsVisible) {
            this.$store.dispatch('sharing_connectSignalR');
            this.$store.dispatch('sharing_getIceServers');
          }

          setTimeout(() => {
            this.dialogVisible = this.$store.getters.sharing_shareDialogIsVisible ? true : false;
          }, 0);

          return this.$store.getters.sharing_shareDialogIsVisible;
        },
        shareDialogStep() {
          return this.$store.getters.sharing_shareDialogStep;
        },
        signalRId() {
          return this.$store.getters.sharing_localSignalRId;
        },
        remoteSignalRId: {
          get() {
            return this.$store.getters.sharing_remoteSignalRId;
          },
          set(value) {
            this.$store.commit('sharing_setRemoteSignalRId', value);            
          }
        }
      },
      methods: {

        onClose() {
          // Let the dialog fade out
          this.dialogVisible = false;
          this.isConnecting = false;
          // before removing the component from the dom
          setTimeout(() => {
            this.$store.commit('sharing_hideDialog');
          }, 1000);
        },

        createCode() {
          this.$store.commit('sharing_setInitiator', false);
          this.$store.dispatch('sharing_createPeer');
          this.$store.commit('sharing_setDialogStep', 2);
        },

        haveCode() {
          this.$store.commit('sharing_setDialogStep', 3);
        },

        callAFriend() {
          this.isConnecting = true;
          this.$store.commit('sharing_setInitiator', true);
          this.$store.dispatch('sharing_createPeer');
        },

        copyCodeToClipboard() {
          const code = document.querySelector("#friendSharingCode");
          code.select();
          document.execCommand("copy");
        },

        shareStreams() {
          this.$store.dispatch('sharing_startStreamSharing');
          this.onClose();
        }
      },
      template: `
        <div 
          v-if="shareDialogIsVisible" 
          class="sharing-dialog"
        >
          <div class="sharing-dialog-body" :class="{ visible: dialogVisible }">
              <button type="button" class="close-dialog" @click="onClose()" title="Close share dialog">
                <i class="fas fa-times"></i>
              </button>

              <div style="text-align: center">

                <!-- Step 1: Start -->
                <div class="sharing-step" v-if="shareDialogStep === 1">
                  <h2>
                    It's more fun to shirt together!
                  </h2>
                  <br />
                  <span class="message"> 
                    How would you like to join?
                  </span>
                  <div class="dialog-buttons">
                    <button type="button" class="button" @click="haveCode()">Have a code</button>
                    <button type="button" class="button" @click="createCode()">Send a code</button>
                  </div>
                </div>

                <!-- Step 2: Send a code -->
                <div class="sharing-step" v-if="shareDialogStep === 2">
                  <h2>
                    Get ready to play!
                  </h2>
                  <br />
                  <span class="message"> 
                    Click to copy this code and send it to your friend to start shirting together.
                  </span>
                  <br />
                  <input 
                    type="input"
                    id="friendSharingCode" 
                    class="share-code" 
                    :value="signalRId" 
                    @click="copyCodeToClipboard()"
                    readonly />
                  <button class="copy-button" @click="copyCodeToClipboard()" title="Copy to clipboard">
                    <i class="fas fa-copy"></i>
                  </button>
                  <div>
                    <button type="button" class="button" @click="onClose()" title="Done">Done</button>
                  </div>
                </div>

                <!-- Step 3: Join with code -->
                <div class="sharing-step" v-if="shareDialogStep === 3">
                  <h2>
                    Get ready to play!
                  </h2>
                  <br />

                  <span class="message"> 
                    Enter the code
                  </span>
                  <br />

                  <input type="text" v-model="remoteSignalRId" class="share-code" />
                  <button 
                    type="button" 
                    class="button"
                    @click="callAFriend()"
                    :disabled="isConnecting">
                      {{ isConnecting ? 'Connecting' : 'Join' }}
                  </button>
                </div>

                <!-- Step 4: Friend has joined -->
                <div class="sharing-step" v-if="shareDialogStep === 4">
                  <h2>
                    Your friend has joined!
                  </h2>
                  <br />

                  <span class="message"> 
                    Please grant access to your mic and camera when prompted.
                  </span>
                  <br />
                  
                  <button 
                    type="button" 
                    class="button"
                    @click="shareStreams()">
                    Go!
                  </button>
                </div>

                 <!-- Step 5: Error connecting -->
                 <div class="sharing-step" v-if="shareDialogStep === 5">
                  <h2>
                    There was a problem!
                  </h2>
                  <br />

                  <span class="message"> 
                    Something went wrong connecting to your friend.  Please try again later.
                  </span>
                  <br />
                  <button type="button" class="button" @click="onClose()" title="Close">Close</button>
                </div>
              </div>
          </div>
        </div>
      `
    }
  });
})(sy);