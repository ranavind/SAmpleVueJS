((sy) => {
  sy.components.push({
    element: "sy-sharing-remote",
    component: {
      id: "SharingRemote",
      data() {
        return {};
      },
      beforeMount() {
        this.$bus.on('sharing_playRemoteVideo', stream => {
          console.log('Sharing remote component received trigger to play video.')
          this.playRemoteVideo(stream);
        });
        this.$bus.on('sharing_playRemoteRenderer', stream => {
          console.log('Sharing remote component received trigger to play renderer.')
          this.playRemoteRenderer(stream);
        });
      },
      beforeUnmount() {
        this.$bus.off('sharing_playRemoteVideo', stream => {
          this.playRemoteVideo(stream);
        });
        this.$bus.off('sharing_playRemoteRenderer', stream => {
          this.playRemoteRenderer(stream);
        });
      },
      computed: {
        isVisible() {
          return this.$store.getters.sharing_shareStreamsAreVisible;
        }
      },
      methods: {
        playRemoteVideo(stream) {
          if (!yba.sharing.remoteVideoStream) {
            return;
          }
          const remoteVideo = document.getElementById('remoteVideo');
          if (remoteVideo) {
            remoteVideo.srcObject = stream; // yba.sharing.remoteVideoStream;
            remoteVideo.play();
          }
        },
        playRemoteRenderer(stream) {
          if (!yba.sharing.remoteCanvasStream) {
            return;
          }
          const remoteCanvas = document.getElementById('remoteCanvas');
          if (remoteCanvas) {
            remoteCanvas.srcObject = stream; // yba.sharing.remoteCanvasStream;
            remoteCanvas.play();
          }
        }
      },
      template: `
        <div 
          v-if="isVisible"
          class="remote-stream-container"
        >
          <video 
            id="remoteVideo" 
            class="remote-video"
            playsinline 
            autoplay
          >
          </video>
          <video 
            id="remoteCanvas" 
            class="remote-renderer"
            playsinline 
            autoplay 
            muted>
          </video>
          <div class="remote-button-container">
            <button id="btnHangUp" @click="$store.dispatch('sharing_stopShare', 1)" title="Stop sharing">
              <i class="fas fa-phone-slash"></i>
            </button>
          </div>
        </div>      
      `,
    },
  });
})(sy);
