((sy) => {
  sy.components.push({
    element: 'sy-sharing-local',
    component: {
      id: 'SharingLocal',
      beforeMount() {
        this.$bus.on('sharing_playLocalVideo', stream => { 
          this.playLocalVideoStream(stream);
        })
      },
      beforeUnmount() {
        this.$bus.on('sharing_playLocalVideo', stream => { 
          this.playLocalVideoStream(stream);
        })
      },      
      computed: {
        isVisible() {
          return this.$store.getters.sharing_shareStreamsAreVisible;
        }
      },
      methods: {
        playLocalVideoStream(stream) {
          const localVideo = document.getElementById('localVideo');
          if (localVideo) {
            localVideo.srcObject = stream; // yba.sharing.localVideoStream;
            localVideo.play();
          }
        },
      },
      template: `
        <div 
          v-if="isVisible"
          class="local-stream-container"
        >
          <video id="localVideo" 
            playsinline 
            autoplay 
            muted 
            style="width: 100%; height: 100%">
          </video>
        </div>            
      `
    }
  });
})(sy);