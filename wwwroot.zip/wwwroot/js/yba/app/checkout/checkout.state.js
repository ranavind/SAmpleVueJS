﻿((sy) => {
  sy.stateModules.push({
    name: 'checkout',
    module: {
      state: () => ({
        isVisible: false,
        kitBuilderSizes: [],
        sizes: [],
        materials: [],
        lineItems: []
      }),
      mutations: {
        checkout_ToggleVisibility: (state, visible) => state.isVisible = visible,
        checkout_KitBuilderSizes: (state, kbSizes) => state.kitBuilderSizes = kbSizes,
        checkout_setLineItems: (state, lineItems) => state.lineItems = lineItems,
        checkout_setSizes: (state, sizes) => state.sizes = sizes,
        checkout_setMaterials: (state, materials) => state.materials = materials,
        checkout_removeItem: (state, index) => state.lineItems.splice(index, 1)
      },
      actions: {
        checkoutHide: (transaction) => {
          transaction.commit('checkout_ToggleVisibility', false);
          transaction.dispatch('toolbars_show');

          const kb = document.getElementById('kitBuilder');
          if (kb) { kb.classList.remove('shrink-kit-builder'); }
        },
        checkoutShow: (transaction) => {
          transaction.commit('checkout_ToggleVisibility', true);
          transaction.dispatch('toolbars_hide');

          const kb = document.getElementById('kitBuilder');
          if (kb) { kb.classList.add('shrink-kit-builder'); }

          if (transaction.state.lineItems.length === 0) {
            transaction.dispatch('checkout_addRow');
          }
        },

        checkout_getSizesFromKb(transaction) {
          // Get a handle to the scope of the quantities inputs
          let selector = '.kb-field-teamdetails > div > div.kb-wizard-form-field.kb-wizard-form-field-full-width.ng-scope > div > div > div.kb-pane-aggregate > div:nth-child(1) > div > table > tbody > tr:nth-child(4) > td.kb-table-cell.kb-table-cell-number.kb-aggregate-size-quantity > input';
          let scope = angular.element(document.querySelector(selector)).scope();
            if (!scope) {
            return;
          }

          let sizes = new Set();
          let materials = new Set();
          scope.sizes.forEach(size => {
            let values = size.name.split('_');
            if (values.length > 1) {
              materials.add({ name: values[1] });
            }
            sizes.add({ name: values[0] });
          })

          transaction.commit('checkout_setSizes', [...sizes].filter((v, i, a) => a.findIndex(t => (t.name === v.name)) === i));
          transaction.commit('checkout_setMaterials', [...materials].filter((v,i,a)=>a.findIndex(t=>(t.name === v.name))===i));

          transaction.dispatch('checkout_syncQuantityFromKitBuilder');
        },

        checkout_syncQuantityFromKitBuilder(transaction) {
          let selector = '.kb-field-teamdetails > div > div.kb-wizard-form-field.kb-wizard-form-field-full-width.ng-scope > div > div > div.kb-pane-aggregate > div:nth-child(1) > div > table > tbody > tr:nth-child(4) > td.kb-table-cell.kb-table-cell-number.kb-aggregate-size-quantity > input';
          let scope = angular
            .element(document.querySelector(selector))
            .scope();
  
          if (!scope) {
            return;
          }
  
          let lineItems = [];
          const teamSizes = scope.teamDetailSizes();
          const kbAvailableSizes = scope.sizes;

          for (const property in teamSizes) {
            if (teamSizes[property] > 0) {

              const kbSize = kbAvailableSizes.find(x => x.id == property);
              const splitSize = kbSize.name.split('_');
              let sizeName = splitSize[0];
              let materialName = splitSize.length > 1 ? splitSize[1] : '';

              lineItems.push({
                id: 0,
                size: sizeName,
                material: materialName,
                qty: teamSizes[property],
                price: yba.currentProduct.price.PriceValue
              });
            }
          }

          transaction.commit('checkout_setLineItems', lineItems);
        },

        checkout_syncQuantityToKitBuilder(transaction) {
          let selector = '.kb-field-teamdetails > div > div.kb-wizard-form-field.kb-wizard-form-field-full-width.ng-scope > div > div > div.kb-pane-aggregate > div:nth-child(1) > div > table > tbody > tr:nth-child(4) > td.kb-table-cell.kb-table-cell-number.kb-aggregate-size-quantity > input';
          let scope = angular.element(document.querySelector(selector)).scope();
          if (!scope) {
            return;
          }
  
          // Iterate over team sizes in KitBuilder
          // Filter the list of line items to items that have matching "size|material"
          // Sum those quantities and write them back to the kit builder TeamSize
          const teamSizes = scope.teamDetailSizes();
          const hasMaterials = transaction.getters.checkout_hasMaterials;
          scope.sizes.forEach(size => {
            let qty = transaction.state
              .lineItems
              .filter(li => (hasMaterials ? `${li.size}_${li.material}` : li.size) == size.name)
              .reduce((accumulator, x) => accumulator + x.qty, 0);

            teamSizes[size.id] = +qty;
          });
        },

        checkout_addRow(transaction) {
          // let selectedSizes = transaction.state.lineItems.map(x => x.size);
          // let notSelectedSizes = transaction.state.sizes.filter(size => !selectedSizes.includes(size));
          // if (notSelectedSizes.length === 0) { return; }
          transaction.state.lineItems.push({
            id: 0,
            style: 'M',
            size: transaction.state.sizes[0].name,
            material: transaction.state.materials.length > 0 ? transaction.state.materials[0].name : "",
            qty: 1,
            price: transaction.getters.product_price
          });

          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        },

        checkout_removeRow(transaction, removeItem) {
          const idx = transaction.state.lineItems.findIndex(item => item == removeItem);
          transaction.commit('checkout_removeItem', idx);
          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        },

        checkout_itemSizeChange(transaction, { item, size }) {
          item.size = size;
          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        },

        checkout_itemMaterialChange(transaction, { item, material }) {
          item.material = material;
          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        },

        checkout_itemQuantityChanged(transaction, { item, quantity }) {
          const parsedValue = parseInt(quantity, 10);
          item.qty = isNaN(parsedValue) || parsedValue == 0 ? 1 : parsedValue;
          // ToDo: update quantity in store

          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        }

      },
      getters: {
        checkout_Visible: state => state.isVisible,
        checkout_grandSubtotal: state => {
          let total = 0;
          state.lineItems.forEach(item => total += item.price * item.qty);
          return `${total.toFixed(2)}`;
        },
        checkout_missingQuantity: state => {
          let noQuantity = state.lineItems
            .filter(x => parseInt(x.qty, 10) == 0 || isNaN(parseInt(x.qty, 10)))
            .length > 0;
          return noQuantity;
        },
        checkout_items: state => state.lineItems,
        checkout_sizes: state => state.sizes,
        checkout_materials: state => state.materials,
        checkout_hasMaterials: state => state.materials.length > 0,
      }
    }
  });
})(sy);

