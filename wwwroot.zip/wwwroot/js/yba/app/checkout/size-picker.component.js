﻿((sy) => {
  sy.components.push({
    element: 'sy-size-picker',
    component: {
      id: 'SizePicker',
      props: ['value', 'sizes'],
      data() {
        return {
          dropdownVisible: true
        }
      },
      methods: {
        onSelect(item) {
          this.$emit('changed', item.name);
          this.toggleDropdown();
        },
        toggleDropdown(e) {
          this.dropdownVisible = !this.dropdownVisible;
        }
      },
      template: `
        <div class="drop-down-button-container">
          <div @click="toggleDropdown($event)" class="drop-down-button">
            <span>
              {{ value }}
            </span>
          </div>
          <div v-if="dropdownVisible" class="dropdown">
            <ul>
              <li
                v-for="size in sizes" 
                :key="size.id" 
                :class="[{ 'selected': size.name == value }]"
                @click="onSelect(size)"
              >
                {{ size.name }}
              </li>
            </ul>
          </div>
        </div>
      `
    }
  });
})(sy);