((sy) => {
  sy.components.push({
    element: 'sy-material-picker',
    component: {
      id: 'MaterialPicker',
      props: ['value', 'materials'],
      data() {
        return {
          dropdownVisible: false
        }
      },
      methods: {
        onSelect(item) {
          this.$emit('changed', item.name);
          this.toggleDropdown();
        },
        toggleDropdown(e) {
          this.dropdownVisible = !this.dropdownVisible;
        }
      },
      template: `
        <div class="drop-down-button-container">
          <div @click="toggleDropdown($event)" class="drop-down-button">
            <span>
              {{ value }}
            </span>
          </div>
          <div v-if="dropdownVisible" class="dropdown">
            <ul>
              <li
                v-for="material in materials" 
                :key="material.name" 
                :class="[{ 'selected': material.name == value }]"
                @click="onSelect(material)"
              >
                {{ material.name }}
              </li>
            </ul>
          </div>
        </div>
      `
    }
  });
})(sy);