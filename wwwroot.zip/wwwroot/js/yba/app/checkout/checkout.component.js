﻿((sy) => {
  sy.components.push({
    element: 'sy-checkout',
    component: {
      computed: {
        checkoutVisible() {
          return this.$store.getters.checkout_Visible;
        },
        grandSubtotal() {
          return this.$store.getters.checkout_grandSubtotal;
        },
        missingQuantity() {
          return this.$store.getters.checkout_missingQuantity;
        },
        lineItems() {
          return this.$store.getters.checkout_items;
        },
        sizes() {
          return this.$store.getters.checkout_sizes;
        },
        materials() {
          return this.$store.getters.checkout_materials;
        },
        hasMaterials() {
          return this.$store.getters.checkout_hasMaterials;
        },
        isMobile() {
          return this.$store.getters.responsive_getDevice == 1;
        }
      },
      methods: {
        subTotal(item) {
          return `${(item.price * item.qty).toFixed(2)}`;
        },
        onDeleteItem(removeItem) {
          this.$store.dispatch('checkout_removeRow', removeItem);
        },
        onAddItem() {
          this.$store.dispatch('checkout_addRow');
        },
        onCloseCheckout() {
          this.$store.dispatch('checkoutHide');
        },
        onCheckout() {
          let button = angular.element(document.querySelector('.kb-button-single-item-checkout-buy-now'));
          button.triggerHandler('click');
          this.$store.dispatch('waiting_show');
          this.$store.commit('waiting_setMessage', 'Please wait while we prepare the patterns for your custom order.');
        },
        onSizeChange(size, item) {
          this.$store.dispatch('checkout_itemSizeChange', { item, size });
        },
        onMaterialChange(material, item) {
          this.$store.dispatch('checkout_itemMaterialChange', { item, material });
        },
        onQuantityChanged(quantity, item) {
          this.$store.dispatch('checkout_itemQuantityChanged', { item, quantity });
        },
      },
      beforeMount() {
        this.$bus.on('product_loaded', data => {
          this.$store.dispatch('checkout_getSizesFromKb');
        });
      },
      template: `
        <div
          class="size-checkout-container"
          v-if="checkoutVisible"
        >
        <div id="sizeCheckout" class="size-checkout">

          <div class="size-checkout-title">
            Select quantity and sizes
  
            <button type="button" id="closeCheckout" class="close-checkout" @click="onCloseCheckout()">
              <i class="fas fa-times" />
            </button>
          </div>
  
          <table class="size-checkout-table">
            <thead>
              <tr>
                <td class="label material">
                  <span v-if="hasMaterials">material:</span>
                  <div v-else class="material"></div></td>
                <td class="label">size:</td>
                <td class="label" v-if="isMobile">qty:</td>
                <td class="label" v-else>quantity:</td>
                <td class="garment-subtotal">price:</td>
                <td class="garment-remove"></td>
              </tr>
            </thead>
            <tbody>
              <tr class="checkout-row" v-for="item in lineItems" :key="item.id">
                <td class="material">
                  <sy-material-picker
                    v-if="hasMaterials"
                    class="material"
                    :value="item.material"
                    :materials="materials"
                    @changed="onMaterialChange($event, item)"
                  ></sy-material-picker>
                </td>
                <td class="size">
                  <sy-size-picker
                    class="size"
                    :value="item.size"
                    :sizes="sizes"
                    @changed="onSizeChange($event, item)"
                  ></sy-size-picker>
                </td>
                <td class="value">
                  <input 
                    type="number" maxlength="4" min="0" max="9999" step="1" 
                    :value="item.qty"
                    @input="onQuantityChanged($event.target.value, item)" />
                </td>
                <td class="garment-subtotal">
                  $ {{ subTotal(item) }}
                </td>
                <td class="garment-remove">
                  <button type="button" @click="onDeleteItem(item)"><i class="fas fa-times" /></button>
                </td>
              </tr>
            </tbody>  
            <tfoot class="checkout-footer">
              <tr>
                <td colspan="3" style="text-align: right; padding: 5px 20px; vertical-align: top;">
                  <button type="button" class="add-button" id="addSizeButton" @click="onAddItem()" style="float: left;">
                    add size <i class="fas fa-plus" />
                  </button>
                  <span class="total-label">subtotal</span>
                </td>
                <td colspan="2" class="total-container" style="text-align: left; ">
                  <div class="total-value">$ {{ grandSubtotal }}</div>
                  <div class="shipping-message">+ plus tax and shipping</div>
                </td>
              </tr>
            </tfoot>
          </table>

          <div class="checkout-buttons">
            <button type="button" class="checkout-button" @click="onCheckout()" :disabled="missingQuantity || lineItems.length === 0">check out</button>
          </div>
        </div>
      </div>
      `
    }
  });
})(sy);
