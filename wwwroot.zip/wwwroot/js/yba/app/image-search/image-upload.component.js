((sy) => {
  sy.components.push({
    id: "imageUpload",
    element: "sy-image-upload",
    component: {
      name: "imageUpload",
      data() {
        return {
          isDragOver: false,
          previewFileBytes: "#",
          isPreviewVisible: false,
          showPlacements: false,
          file: null,
        };
      },
      computed: {
        imagePlacementOptions() {
          return this.$store.getters.imageDialog_PlacementOptions;
        },
      },
      methods: {
        onDrag(e) {
          this.preventDefault(e);
        },

        onDragOver(e) {
          this.preventDefault(e);
          this.isDragOver = true;
        },

        onDragEnd(e) {
          this.preventDefault(e);
          this.isDragOver = false;
        },

        onDrop(e) {
          this.preventDefault(e);
          this.isDragOver = false;

          if (
            !e.dataTransfer ||
            !e.dataTransfer.files ||
            e.dataTransfer.files.length === 0
          ) {
            return;
          }

          this.file = e.dataTransfer.files[0];
          this.showPreview();
        },

        preventDefault(e) {
          e.preventDefault();
          e.stopPropagation();
        },

        onFileAdded(event) {
          if (!event.currentTarget.files || event.currentTarget.files == 0) {
            return;
          }
          this.file = event.currentTarget.files[0];
          this.showPreview();
        },

        onPlaceImageClicked() {
          this.showPlacements = !this.showPlacements;
        },

        showPreview() {
          this.previewFileBytes = URL.createObjectURL(this.file); // convert to base64 string
          this.isPreviewVisible = true;
        },

        onUploadFile(placementKey) {
          this.showPlacements = false;
          this.isPreviewVisible = false;

          this.$store.commit("kitBuilderImagePlaceholderSelect", placementKey);

          this.$store.dispatch("uploadImageFromLocal", {
            file: this.file,
            placementKey,
          });
          this.isPreviewVisible = false;
        },

        onDiscard() {
          this.file = null;
          this.isPreviewVisible = false;
          this.showPlacements = false;
        },

        openFileDialog(e) {
          console.log("open file dialog");
          const fileInput = document.querySelector("#uploadImageInput");
          fileInput.click();
        },
      },
      template: `
      <div class="image-upload-tab">
        <div v-if="!isPreviewVisible"
          class="drop-container"
          :class="{ 'drag-over': isDragOver }"

          @drag="onDrag($event)" 
          @dragstart="onDrag($event)" 
          @dragend="onDragEnd($event)" 
          @dragover="onDragOver($event)" 
          @dragenter="onDragOver($event)" 
          @dragleave="onDragEnd($event)" 
          @drop="onDrop($event)"
          @click="openFileDialog($event)"
        >
          <label class="upload-text">
            Drag and Drop an image here or click to upload.

            <span class="upload-icon">
              <i class="fas fa-file-upload"></i>
            </span>
          </label>
          <div style="display: none">
            <input
                id="uploadImageInput"
                name="uploadImageInput"
                type="file"
                @change="onFileAdded($event)"
                max-size="26214400"
                allowed-mime-types="image/jpeg,image/png,image/gif,application/postscript,application/pdf,application/illustrator"
                accept="image/jpeg,image/png,image/gif,application/postscript,application/pdf,application/illustrator"
            />
          </div>
        </div>
        
        <div v-else class="preview-container">
          <div class="image-container">
            <img id="previewFileBytes" :src="previewFileBytes" />
          </div>
          <div class="preview-buttons">
              <button type="button" class="discard-btn" @click="onDiscard()">Discard</button>

              &nbsp;&nbsp;&nbsp;
              
              <div class="dropdown">
                <button @click="onPlaceImageClicked()" class="dropdown-btn">Place Image</button>
                <div class="dropup-content" :class="{ 'show': showPlacements }">
                  <ul class="dropdown-list">
                    <li v-for="p in imagePlacementOptions" @click="onUploadFile(p.placementKey)">{{ p.name }}</li>
                  </ul>
                </div>
              </div>
          </div>
        </div>
    </div>
      `,
    },
  });
})(sy);
