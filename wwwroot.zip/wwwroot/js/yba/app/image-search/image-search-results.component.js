((sy) => {
  sy.components.push({
    id: "imageSearchResults",
    element: "sy-image-search-results",
    component: {
      name: "imageSearchResults",
      data() {
        return {
          searchResultElement: null,
          isPreviewVisible: false,
          selectedImage: {},
          showPlacements: false,
        };
      },
      computed: {
        images() {
          if (this.searchResultElement) {
            this.searchResultElement.scrollTop = 0;
          }
          return this.$store.getters.imageDialog_SearchResultImages;
        },
        searchMessage() {
          return this.$store.getters.imageDialog_SearchMessage;
        },
        searchInProgress() {
          return this.$store.getters.imageDialog_searchInProgress;
        },
        imagePlacementOptions() {
          return this.$store.getters.imageDialog_PlacementOptions;
        },
      },
      methods: {
        onImageSelected(placementKey) {
          this.isPreviewVisible = false;
          this.showPlacements = false;
          this.$store.dispatch("imageDialog_ProcessVendorImage", {
            image: this.selectedImage,
            placementKey,
          });
        },
        onPreview(image) {
          this.selectedImage = image;
          this.isPreviewVisible = true;
        },
        onCancel() {
          this.isPreviewVisible = false;
          this.showPlacements = false;
        },
        onPlaceImageClicked() {
          this.showPlacements = !this.showPlacements;
        },
      },
      mounted() {
        this.searchResultElement = document.getElementById("searchResults");
      },
      template: `
        <div class="image-library-tab">
          <div class="image-library-container" v-if="!isPreviewVisible">
            <sy-image-search-filter></sy-image-search-filter>
            <div class="search-results-container" id="searchResults">
              <div class="image-list-container">
                <ul class="image-list" v-if="images.length > 0 && !searchInProgress">
                  <li v-for="image in images" :key="id" @click="onPreview(image)">
                    <img :src="image.medium_thumbnail" />
                  </li>
                </ul>
                <span v-else>
                    {{ searchMessage }}
                </span>
              </div>    
              <sy-search-pager></sy-search-pager>
            </div>
          </div>
          <div v-else class="preview-container">
            <div class="image-container">
              <img id="previewFileBytes" :src="selectedImage.url_big" />
            </div>
            <div class="preview-buttons">
              <button type="button" class="discard-btn" @click="onCancel()">Cancel</button>

              &nbsp;&nbsp;&nbsp;
              
              <div class="dropdown">
                <button @click="onPlaceImageClicked()" class="dropdown-btn">Place Image</button>
                <div class="dropup-content" :class="{ 'show': showPlacements }">
                  <ul class="dropdown-list">
                    <li v-for="p in imagePlacementOptions" @click="onImageSelected(p.placementKey)">{{ p.name }}</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      `,
    },
  });
})(sy);
