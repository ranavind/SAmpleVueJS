(sy => {
  sy.components.push({
    id: 'imagePreview',
    element: 'sy-image-preview',
    component: {
      name: 'imagePreview',
      data() {
        return {
        }
      },
      computed: {
      },
      methods: {
      },
      template: `
        <div> 
          <div>
            Preview Image here
            <img />
          </div>
          <div>
            <button type="button">Cancel</button>
            <button type="button">Use</button>
          </div>
        </div>
      `
    }
  });
})(sy);