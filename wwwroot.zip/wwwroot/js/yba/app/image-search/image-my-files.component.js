((sy) => {
  sy.components.push({
    id: "imageMyFiles",
    element: "sy-image-my-files",
    component: {
      name: "imageMyFiles",
      data() {
        return {
          images: [],
          distributionId: "",
          selectedImage: {},
          selectedImageSrc: "",
          isPreviewVisible: false,
          showPlacements: false,
        };
      },
      computed: {
        imagePlacementOptions() {
          return this.$store.getters.imageDialog_PlacementOptions;
        },
      },
      methods: {
        refreshImages() {
          const kbPlacementElement = document.querySelector(
            ".kb-editor-placement-image"
          );
          if (kbPlacementElement) {
            const scope = angular.element(kbPlacementElement).scope();
            this.images = Array
              .from(new Set(scope.imageLibrary.images.map(x => x.thumbnailImageId)))
              .map(id => scope.imageLibrary.images.find(item => item.thumbnailImageId == id));
              
              // scope.imageLibrary.images
              // .filter(x => x.thumbnailImageId && x.thumbnailImageId > 0)
              // .filter((x, i, a) => a.indexOf(x) == i)
          }
        },
        onImageSelected(placementKey) {
          this.isPreviewVisible = false;
          this.showPlacements = false;
          this.$store.dispatch("placeImageOnGarment", {
            placementKey: placementKey,
            fileData: {
              id: this.selectedImage.thumbnailImageId,
              isBitmap: this.selectedImage.isBitmap,
              bitmapWidth: this.selectedImage.originalWidth,
              bitmapHeight: this.selectedImage.originalHeight,
            },
          });
          this.$store.commit("imageDialog_ToggleVisibility", false);
        },
        onPreview(image) {
          this.selectedImage = image;
          this.selectedImageSrc = `https://api.kitbuilder.co.uk/Api/file/${this.selectedImage.thumbnailImageId}/?width=500&height=500&${this.distributionId}`;
          this.isPreviewVisible = true;
        },
        onCancel() {
          this.isPreviewVisible = false;
          this.showPlacements = false;
        },
        onPlaceImageClicked() {
          this.showPlacements = !this.showPlacements;
        },
      },
      mounted() {
        this.distributionId = yba.kitBuilder.distributionId;
        this.refreshImages();
      },
      template: `
        <div class="image-my-files-tab">
          <div class="my-images-content" v-if="!isPreviewVisible">
            <ul class="image-list" v-if="images.length > 0">
              <li v-for="image in images" :key="image.thumbnailImageId" @click="onPreview(image)">
                <i class="fas fa-cog fa-spin fa-3x" style="opacity: .5"></i>
                <img :src="'https://api.kitbuilder.co.uk/Api/file/' + image.thumbnailImageId + '/?width=175&height=172&' + distributionId" />
              </li>
            </ul>
            <span v-else class="no-files">
              No images have been previously selected or uploaded.  Use the Image Library to select from the Shirt Yourself image library or the "Upload" to use your own photos.
            </span>
          </div>
          <div v-else class="preview-container">
            <div class="image-container" style="vertical-align: center">
              <img :src="selectedImageSrc" />
            </div>
            <div class="preview-buttons">
              <button type="button" class="discard-btn" @click="onCancel()">Cancel</button>

              &nbsp;&nbsp;&nbsp;
              
              <div class="dropdown">
                <button @click="onPlaceImageClicked()" class="dropdown-btn">Place Image</button>
                <div class="dropup-content" :class="{ 'show': showPlacements }">
                  <ul class="dropdown-list">
                    <li v-for="p in imagePlacementOptions" @click="onImageSelected(p.placementKey)">{{ p.name }}</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>        
        </div>
      `,
    },
  });
})(sy);
