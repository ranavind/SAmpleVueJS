((sy) => {
  sy.components.push({
    id: "imageSearchDialog",
    element: "sy-image-dialog",
    component: {
      name: "imageSearchDialog",
      data() {
        return { };
      },
      computed: {
        isVisible() {
          return this.$store.getters.imageDialog_IsVisible;
        },
        selectedTab() {
          return this.$store.getters.imageDialog_selectedTab;
        }
      },
      methods: {
        onClose() {
          this.$store.commit("imageDialog_ToggleVisibility", false);
        },
        onModalClick(event) {
          event.cancelBubble = true;
          event.preventDefault();
        },
        onSelectTab(tab) {
          this.activeTab = tab;
          this.scrollTop();
        },
        scrollTop() {
          window.scrollTo(0, 0);
          document.body.scrollTop = 0;
        }
      },
      template: `
        <div id="imageDialog" class="sy-modal" :style="{ 'display': isVisible ? 'block' : 'none' }">
          <div class="sy-modal-container">
          <!-- @click="onModalClick($event)" -->
            <div class="sy-modal-title">
              IMAGE CHOOSER
            </div>
            <div class="sy-modal-header">
              <span class="sy-modal-close" @click="onClose()">
                <i class="fas fa-times"></i>
              </span>
            </div>
            <div class="sy-modal-tabs">
              <ul>
                <li :class="{ 'active': selectedTab === 1 }" @click="$store.commit('imageDialog_SetSelectedTab', 1)">Image Library</li>
                <li :class="{ 'active': selectedTab === 2 }" @click="$store.commit('imageDialog_SetSelectedTab', 2)">Upload Image</li>
                <li :class="{ 'active': selectedTab === 3 }" @click="$store.commit('imageDialog_SetSelectedTab', 3)">My Images</li>
              </ul>
            </div>
            <div class="sy-modal-body">
              <sy-image-search-results v-if="selectedTab === 1"></sy-image-search-results>
              <sy-image-upload v-if="selectedTab === 2"></sy-image-upload>
              <sy-image-my-files v-if="selectedTab === 3"></sy-image-my-files>
            </div>
          </div>
        </div>
      `,
    },
  });
})(sy);
