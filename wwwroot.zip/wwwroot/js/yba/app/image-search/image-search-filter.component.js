((sy) => {
  sy.components.push({
    id: "imageSearchFilter",
    element: "sy-image-search-filter",
    component: {
      name: "imageSearchFilter",
      data() {
        return {};
      },
      computed: {
        isExpanded() {
          return this.$store.getters.imageDialog_SearchIsExpanded;
        },
        searchQuery: {
          get() {
            return this.$store.getters.imageDialog_SearchQuery;
          },
          set(value) {
            this.$store.commit("imageDialog_UpdateSearchQuery", value);
          },
        },
        imageType: {
          get() {
            return this.$store.getters.imageDialog_SearchImageType;
          },
          set(value) {
            this.$store.commit("imageDialog_UpdateSearchImageType", value);
          },
        },
      },
      methods: {
        onSearch(e) {
          e.preventDefault();
          e.stopPropagation();
          // this.pager.currentPage = 1;

          this.$store.dispatch("imageSearch_executeSearch");
          this.scrollTop();
        },
        upateImageType(value) {
          this.$store.commit("imageDialog_UpdateSearchImageType", value);
        },
        onExpand() {
          this.$store.commit(
            "imageDialog_ToggleSearchExpanded",
            !this.isExpanded
          );
        },
        scrollTop() {
          window.scrollTo(0, 0);
          document.body.scrollTop = 0;
        }
      },
      template: `
        <div class="search-filter-container" :class="{ expanded: isExpanded }">
          <div class="search-filter-title">
            <span v-if="isExpanded">
              Search Filters
            </span>
            <button @click="onExpand()">
              <i v-if="isExpanded" class="fas fa-times fa-lg"></i>
              <i v-else class="fas fa-search fa-lg"></i>
            </button>
          </div>
          <form class="search-filter-criteria" v-if="isExpanded">
            <dl>
              <dt><label>Search:</label></dt>
              <dd><input type="text" v-model="searchQuery" placeholder="keywords" maxlength="200" @blur="scrollTop()" /></dd>

              <dt><label>Image Type:</label></dt>
              <dd>
                <select v-model="imageType">
                  <option value="all">All</option>
                  <option value="vector">Illustration</option>
                  <option value="photo">Photo</option>
                </select>
              </dd>
            </dl>
            <button class="search-btn" type="submit" @click="onSearch($event)" :disabled="!searchQuery">
              Search Library
            </button>
          </form>
        </div>
      `,
    },
  });
})(sy);
