﻿((sy) => {

  const defaultSearchMessage = 'Search our library of over 150,000,000 million images.  Enter some key words in the search box to begin.';

  sy.stateModules.push({
    name: 'imagePicker',
    module: {
      state: () => ({
        imageDialog: {
          isVisible: false,
          selectedTab: 1,
          pager: {
            pageSize: 100,
            currentPage: 0,
            pageCount: 0,
            total: 0
          },
          searchFilter: {
            searchQuery: '',
            imageType: 'all',
          },
          searchIsExpanded: true,
          searchInProgress: false,
          searchMessage: defaultSearchMessage,
          images: []
        },
        kitBuilder: {
          images: {
            placeholders: [],
            selectedPlacementKey: ''
          },
        },
      }),
      mutations: {
        imageDialog_ToggleVisibility(state, visible) {
          state.imageDialog.isVisible = visible;
        },
        imageDialog_UpdateSearchQuery(state, searchQuery) {
          state.imageDialog.searchFilter.searchQuery = searchQuery;
        },
        imageDialog_UpdateSearchImageType(state, imageType) {
          state.imageDialog.searchFilter.imageType = imageType;
        },
        imageDialog_ToggleSearchExpanded(state, expanded) {
          state.imageDialog.searchIsExpanded = expanded;
        },
        imageDialog_InsertImages(state, images) {
          state.imageDialog.images = images;
        },
        imageDialog_UpdateMessage(state, message) {
          state.imageDialog.searchMessage = message;
        },
        imageDialog_UpdateSearchInProgress(state, value) {
          state.imageDialog.searchInProgress = value;
        },
        imageDialog_UpdatePagerTotal(state, value) {
          const pager = state.imageDialog.pager;

          pager.total = value;
          pager.pageCount = (pager.total > 0 && pager.pageSize > 0) ? Math.round(pager.total / pager.pageSize) : 0;
        },
        imageDialog_SetPagerPage(state, value) {
          state.imageDialog.pager.currentPage = +value;
        },
        imageDialog_SetSelectedTab(state, tabIndex) {
          state.imageDialog.selectedTab = tabIndex;
        },

        kitBuilderImagePlaceholderInsert(state, placeholder) {
          state.kitBuilder.images.placeholders.push(placeholder);
        },
        kitBuilderImagePlaceholderClear(state) {
          state.kitBuilder.images.placeholders.length = 0;
        },

        kitBuilderImagePlaceholderSelect(state, placeholderKey) {
          state.kitBuilder.images.selectedPlacementKey = placeholderKey;
        },
      },
      actions: {
        imageDialog_NextPage(transaction) {
          const pager = transaction.state.imageDialog.pager;
          if (pager.currentPage + 1 <= pager.pageCount) {
            const nextPage = pager.currentPage < pager.pageCount ? pager.currentPage + 1 : pager.pageCount;
            transaction.commit('imageDialog_SetPagerPage', nextPage);
            transaction.dispatch('imageSearch_executeSearch');
          }
        },
        imageDialog_PreviousPage(transaction) {
          const pager = transaction.state.imageDialog.pager;
          if (pager.currentPage - 1 > 0) {
            const nextPage = pager.currentPage > 1 ? pager.currentPage - 1 : 1;
            transaction.commit('imageDialog_SetPagerPage', nextPage);
            transaction.dispatch('imageSearch_executeSearch');
          }
        },
        imageDialog_SetPage(transaction, page) {
          const pager = transaction.state.imageDialog.pager;
          if (page > 0 && page <= pager.pageCount) {
            transaction.commit('imageDialog_SetPagerPage', page);
            transaction.dispatch('imageSearch_executeSearch');
          }
        },

        imageDialog_ProcessVendorImage(transaction, payload) {
          let imageId = payload.image.id;
          let imageType = payload.image.type;
          transaction.commit('imageDialog_ToggleVisibility', false);
          transaction.dispatch('waiting_show');
          transaction.commit('waiting_setMessage', 'Please wait while we retrieve the high resolution image.');

          axios({
            method: 'get',
            url: `/api/imagesapi/ProcessImage`,
            params: { imageId, imageType }
          }).then((response) => {
            transaction.dispatch('placeImageOnGarment', {
              placementKey: payload.placementKey,
              fileData: response.data
            })
          })
          .catch(function (error) {
            transaction.dispatch('waiting_hide');

            let errorMessage = 'There was a problem uploading and placing this image.';
            if (error.response && error.response.data) {
              if (error.response.data.message) {
                errorMessage = error.response.data.message;
              } else {
                errorMessage = error.response.data;
              }
            }

            transaction.commit('messageDialog_show', {
              message: errorMessage,
              title: 'Error',
              dialogType: 3
            });
            console.log(error);
          });
        },
   
        uploadImageFromLocal(transaction, { file, placementKey }) {
    
          transaction.commit('imageDialog_ToggleVisibility', false);
          transaction.dispatch('waiting_show');
          transaction.commit('waiting_setMessage', 'Please wait while we upload your image.');

          const formData = new FormData();
          formData.append("image", file);
          axios.post('/api/imagesapi/Upload',
            formData,
            {
              headers: {
                'Content-Type': 'multipart/form-data'
              }
            }
          ).then(response => { 
            transaction.dispatch('placeImageOnGarment', {
              placementKey: placementKey,
              fileData: response.data
            })
          }).catch(function (error) {
            transaction.dispatch('waiting_hide');

            let errorMessage = 'There was a problem uploading and placing this image.';
            if (error.response && error.response.data) {
              if (error.response.data.message) {
                errorMessage = error.response.data.message;
              } else {
                errorMessage = error.response.data;
              }
            }

            transaction.commit('messageDialog_show', {
              message: errorMessage,
              title: 'Error',
              dialogType: 3
            });
            console.log(error);
          });
        },

        placeImageOnGarment(transaction, { fileData, placementKey }) {

          transaction.commit('waiting_setMessage', 'Almost there, placing the image on your garment.');

          // Get the Angular scope of the upload input
          let scope = angular
            .element(document.querySelector(`.kb-placement-${placementKey} input`))
            .scope();

          // Call the success method to update the UI with the
          // new image (will display the image in the selector)
          scope.uploadSuccess(fileData);

          // Add the image to the garment
          scope.addImage(
            placementKey,
            fileData.id,
            fileData.bitmapWidth,
            fileData.bitmapHeight
          );
          transaction.dispatch('waiting_hide');
        },

        imageSearch_executeSearch(transaction) {

          const searchFilter = transaction.state.imageDialog.searchFilter;
          const pager = transaction.state.imageDialog.pager;
          transaction.state.imageDialog.pager.currentPage = transaction.state.imageDialog.pager.currentPage > 0 ? transaction.state.imageDialog.pager.currentPage : 1;
          let params = {
            searchQuery: searchFilter.searchQuery,
            pageIndex: pager.currentPage > 0 ? pager.currentPage : 1,
            pageSize: pager.pageSize
          };

          if (searchFilter.imageType !== 'all') {
            params.imageType = searchFilter.imageType;
          }

          transaction.commit('imageDialog_UpdateSearchInProgress', true);
          transaction.commit('imageDialog_UpdateMessage', 'Searching the library ...');

          axios({
            method: 'get',
            url: '/api/imagesapi/search',
            params
          })
          .then((response) => {
            const payload = response.data;
            const images = payload.result.filter(x => x.iseditorial === false);

            transaction.commit('imageDialog_UpdatePagerTotal', payload.count);
            transaction.commit('imageDialog_InsertImages', images);
            transaction.commit('imageDialog_UpdateSearchInProgress', false);
              
            if (payload.result.length > 0) {
              transaction.commit('imageDialog_UpdateMessage', defaultSearchMessage);
              transaction.commit('imageDialog_ToggleSearchExpanded', false);
            } else {
              transaction.commit('imageDialog_UpdateMessage', 'No images were found that match your search.  Please enter a different search and try again.');
              transaction.commit('imageDialog_SetPagerPage', 1);
            }
          })
          .catch(function (error) {
            // console.log(error);
            transaction.commit('imageDialog_UpdateSearchInProgress', false);
            transaction.commit('imageDialog_UpdateMessage', defaultSearchMessage);
          });
        }

      },
      getters: {
        imageDialog_IsVisible: state => state.imageDialog.isVisible,
        imageDialog_PlacementOptions: state => state.kitBuilder.images.placeholders,
        imageDialog_SelectedPlacementKey: state => state.kitBuilder.images.selectedPlacementKey,
        imageDialog_SearchQuery: state => state.imageDialog.searchFilter.searchQuery,
        imageDialog_SearchImageType: state => state.imageDialog.searchFilter.imageType,
        imageDialog_SearchPager: state => state.imageDialog.pager,
        imageDialog_SearchResultImages: state => state.imageDialog.images,
        imageDialog_SearchIsExpanded: state => state.imageDialog.searchIsExpanded,
        imageDialog_SearchMessage: state => state.imageDialog.searchMessage,
        imageDialog_searchInProgress: state => state.imageDialog.searchInProgress,
        imageDialog_selectedTab: state => state.imageDialog.selectedTab,
      }
    }
  });
})(sy);

