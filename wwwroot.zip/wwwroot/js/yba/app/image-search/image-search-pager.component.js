((sy) => {
  sy.components.push({
    id: "imageSearchPager",
    element: "sy-search-pager",
    component: {
      name: "imageSearchPager",
      data() {
        return {};
      },
      computed: {
        pager() {
          return this.$store.getters.imageDialog_SearchPager;
        }
      },
      methods: {
        onPreviousPage() {
          this.$store.dispatch('imageDialog_PreviousPage');
        },
        onNextPage() {
          this.$store.dispatch('imageDialog_NextPage');
        },
        executeSearch(value) {
          this.$store.dispatch('imageDialog_SetPage', value);
        }
      },
      template: `
        <div class="image-pager" v-if="pager.total > 0">
          <div class="page-counts">
            <span>Images: {{ pager.total }}</span>
            &nbsp;&nbsp;&nbsp;  
            <span>Displaying page {{ pager.currentPage }} of {{ pager.pageCount }}</span>
          </div>
          <div class="page-controls">
            <span @click="onPreviousPage()"><i class="fas fa-less-than" style="cursor: pointer"></i></span>
            &nbsp;
            <input :value="pager.currentPage" id="currentPage" @blur="executeSearch($event.target.value)" style="width: 25px" />
            &nbsp;
            <span @click="onNextPage()"><i class="fas fa-greater-than" style="cursor: pointer"></i></span>
          </div>
        </div>
      `,
    },
  });
})(sy);
