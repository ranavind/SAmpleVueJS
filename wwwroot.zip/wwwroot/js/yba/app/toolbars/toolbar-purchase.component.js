﻿((sy) => {
  sy.components.push({
    element: 'sy-toolbar-purchase',
    component: {
      data() {
        return {
          tools: [             
            { id: 2, name: 'locker room', image: 'fa-piggy-bank', controlId: 'btnLockerRoom', title: "My saved designs", bottom: 0, left: 0 },
            { id: 3, name: 'save', image: 'fa-save', controlId: 'btnSave', title: "Save this design for later.", bottom: 0, left: 0 },
            { id: 4, name: 'checkout', image: 'fa-shopping-cart', controlId: 'btnCheckout', title: "Select sizes and quantity", bottom: 0, left: 0 },
            { id: 5, name: 'description', image: 'fa-clipboard-list', controlId: 'btnDescription', title: "Product description", bottom: 0, left: 0 },
            { id: 6, name: 'live share', image: 'fa-user-friends', controlId: 'btnLiveShare', title: "Shirt yourself with a friend", display: 'none', bottom: 0, left: 0 },
            { id: 7, name: 'stop share', image: 'fa-phone-slash', controlId: 'btnStopShare', title: "Stop sharing", display: 'none', bottom: 0, left: 0 }
          ],
          selectedTool: { name: '' },
          title: 'I LIKE IT!'
        }
      },
      computed: {
        toolbarsVisible() {
          return this.$store.getters.toolbarsVisible && (window.yba && window.yba.showBuyToolbar);
        },
        collapsed() {
          return this.$store.getters.toolbarsPurchaseCollapsed;
        },
        liveShareEnabled() {
          // Hack: Hide live share until it's ready
          const device = this.$store.getters.responsive_getDevice;
          const enabledForDevice = device > 2; // liveshare is only on desktop

          const shareButton = this.tools.find(x => x.controlId === 'btnLiveShare');
          shareButton.display = this.$store.getters.product_liveShareEnabled && enabledForDevice ? 'block' : 'none';

          return this.$store.getters.product_liveShareEnabled;
        },
        lockerRoomEnabled() {
          // Hack: Hide locker room until it's ready
          const lockerButton = this.tools.find(x => x.controlId === 'btnLockerRoom');
          // lockerButton.visible = this.$store.getters.product_lockerRoomEnabled ? 'visible' : 'hidden';
          lockerButton.display = this.$store.getters.product_lockerRoomEnabled ? 'block' : 'none';
          
          const saveButton = this.tools.find(x => x.controlId === 'btnSave');
          // saveButton.visible = lockerButton.visible;
          saveButton.display = lockerButton.display;
          
          return this.$store.getters.product_lockerRoomEnabled;
        },
        isMobile() {
          return this.$store.getters.responsive_getDevice == 1;
        }
      },
      methods: {
        toolClick(tool, e) {

          switch (tool.controlId) {
            case 'btnCheckout':
              this.$store.dispatch('checkoutShow');
              break;
            case 'btnLiveShare':
              this.$store.commit('sharing_showDialog', 1);
              break;
            case 'btnStopShare':
              this.$store.dispatch('sharing_stopShare', 1);
              break;
            case 'btnSave':
              this.$store.dispatch('lockerRoom_ShowSave')
              break;
            case 'btnLockerRoom':
              this.$store.dispatch('lockerRoom_ShowLockerRoom');
              break;
            case 'btnDescription':
              let descriptionWidth = 500;
              if (this.$store.getters.responsive_getDevice === 1) {
                descriptionWidth = 400;
              }

              tool.bottom = `${e.target.offsetTop + 45}px`;
              tool.left = `${e.target.offsetLeft - descriptionWidth}px`;

              this.$store.dispatch('toolbars_toggleProductPrice');
              break;
          }

        },
        toggleCollapse() {
          this.$store.dispatch('toolbars_toggle', { toolbar: 'purchaseToolbar' });
        },
        liveShareUpdate(isActive) {
          const btnStopShare = this.tools.find(x => x.controlId === 'btnStopShare');
          btnStopShare.display = isActive  ? 'block' : 'none';

          const btnLiveShare = this.tools.find(x => x.controlId === 'btnLiveShare');
          btnLiveShare.display = isActive ? 'none' : 'block';
        }
      },
      beforeMount() {
        this.$bus.on('sharing_start', () => { this.liveShareUpdate(true); });
        this.$bus.on('sharing_end', () => { this.liveShareUpdate(false); });
      },
      beforeUnmount() {
        this.$bus.off('sharing_start', () => { this.liveShareUpdate(true); });
        this.$bus.off('sharing_end', () => { this.liveShareUpdate(false); });
      },
      template: `
      <div
        :class="['toolbar', 'toolbar-bottom', { 'toolbar-collapsed': collapsed } ]"
        :style="[{ 'width': isMobile ? '180px' : 'auto' }]"
        
      >
        <div class="toolbar-title" @click="toggleCollapse()">
            <span class="toolbar-label"> {{ title }} </span>
        </div>
        <div class="toolbar-arrow arrow-down" @click="toggleCollapse()"></div>
        <div class="toolbar-tools">
          <div class="toolbar-tools-body">
            <template v-for="tool in tools" :key="tool.id">
              <button 
                :id="tool.controlId" 
                :title="tool.title" 
                :style="[{ 'display': tool.display || 'default' }]"
                @click="toolClick(tool, $event)"
                class="toolbar-item" 
              >
                <i :class="['fas', tool.image]"></i>
                <label class="tool-label">{{ tool.name }}</label>
              </button>
              <!-- <div class="toolbar-divider-vertical" v-if="tool.id < 4" :id="'btn' + tool.name"></div> -->

              <sy-price-popover 
                v-if="tool.controlId == 'btnCheckout'" 
              ></sy-price-popover>
              <!-- :style="{ bottom: tool.bottom, left: tool.left }" -->
              
              <sy-product-description-popover 
                v-if="tool.controlId == 'btnDescription'"
              >
              </sy-product-description-popover>
            </template>
          </div>
        </div>
        <div style="display:none">
          {{ liveShareEnabled }}
          {{ lockerRoomEnabled }}
        </div>
      </div>
    `
    }
  });
})(sy);
