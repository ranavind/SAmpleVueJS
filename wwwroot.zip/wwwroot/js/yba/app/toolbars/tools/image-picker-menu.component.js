﻿
((sy) => {
  sy.components.push({
    element: 'sy-image-menu',
    component: {
      name: 'imageMenu',
      data() {
        return {
          selectedItem: '',
          maskAreas: [],
          domObserver: null
        }
      },
      beforeMount() {
        this.$bus.on('product_change', data => { 
          this.reset();
        })
        this.$bus.on('product_loaded', data => {
          this.repositionKbPickers();
        });
      },
      beforeUnmount() {
        this.$bus.off('product_change', data => {
          this.reset();
        });
        if (this.domObserver) {
          this.domObserver.disconnect();
        };
      },      
      methods: {
        reset() {
          if (this.domObserver) {
            this.domObserver.disconnect();
          };
  
          this.maskAreas.forEach(item => {
            const parentNode = document.getElementById(`placedImageContainer${item.id}`);
            while (parentNode.firstChild) {
              parentNode.removeChild(parentNode.firstChild);
            }
          });
          this.$store.commit('kitBuilderImagePlaceholderClear');
          this.maskAreas.length = 0;
        },
        repositionKbPickers() {
          if (this.maskAreas.length > 0) { return; }

          let kitBuilderImagePickerContainer = document.querySelector('.kb-wizard > li:nth-child(2) > div .kb-wizard-form-row .kb-wizard-form-field .kb-editor');
          kitBuilderImagePickerContainer.children.forEach(group => {
            let header = group.querySelector('.kb-wizard-group-header');
            header.style = 'display: none !important;';

            let scope = angular.element(group).scope();
            this.maskAreas.push({
              id: this.maskAreas.length,
              text: header.innerText.replace('Upload Your', ''),
              placement: scope.placement,
              kbElement: group,
              isLoaded: false,
              scope: scope,
              isLabelVisible: true
            });
            this.$store.commit('kitBuilderImagePlaceholderInsert', scope.placement);

            // item in getModel('image', placement.placementKey)  get list of placed images
          });

          if (this.maskAreas.length > 0 && this.maskAreas[0].placement) {
            this.$store.commit('kitBuilderImagePlaceholderSelect', this.maskAreas[0].placement.placementKey);
          }

          setTimeout(() => {
            this.maskAreas.forEach(item => {
              if (item.kbElement) {

                // Reparent placed image
                let addImageContainer = document.getElementById(`placedImageContainer${item.id}`);
                addImageContainer.append(item.kbElement);

                let image = item.kbElement.querySelector('.kb-editor-placement-image > div:nth-child(2)');
                image.style = 'display: block !important; visibility: visible !important';

                item.isLoaded = true;
              }
            });

            // Update labels and price
            this.onImageUpdate();
            this.watchDom();
          }, 1);
        },

        watchDom() {
          let dom = document.querySelector('.sy-image-menu');

          // Options for the observer (which mutations to observe)
          const config = { attributes: true, childList: true, subtree: true };
          let updatePlacedImages = this.onImageUpdate;

          // Callback function to execute when mutations are observed
          const domMutated = function (mutationsList, observer) {
            for (const mutation of mutationsList) {
              if (mutation.type !== 'attributes') {
                updatePlacedImages();
              }
            }
          };

          // Create an observer instance linked to the callback function
          this.domObserver = new MutationObserver(domMutated);

          // Start observing the target node for configured mutations
          this.domObserver.observe(dom, config);
        },

        onImageUpdate() {
          this.maskAreas.forEach(item => {
            let addImageContainer = document.getElementById(`placedImageContainer${item.id}`);
            let image = addImageContainer.querySelectorAll('img');

            // If area has images then display Label
            item.isLabelVisible = (image.length > 0) ? true : false;

            let sideText = item.text.toLowerCase();
            let side = sideText.indexOf('front') > 0 ? 'front' :
              sideText.indexOf('back') > 0 ? 'back' :
              sideText.indexOf('left') > 0 ? 'left' :
              sideText.indexOf('right') > 0 ? 'right' : null;

            // Update price for DTG garments that are printed on more than one side
            if (image.length > 0 && side !== null) {
              this.$store.commit('product_setImageSide', { side, value: true });
            } else {
              this.$store.commit('product_setImageSide', { side, value: false });
            }
          });
        },

        onOpenSearch() {
          this.$store.commit('imageDialog_SetSelectedTab', 1)
          this.$store.commit('imageDialog_ToggleVisibility', true);
        },
        onUploadImage() {
          this.$store.commit('imageDialog_SetSelectedTab', 2)
          this.$store.commit('imageDialog_ToggleVisibility', true);
        },
        closeMenu() {
          this.$store.commit("toolbar_ClearSelectedTool");
        }
      },
      template: `
        <div class="sy-image-menu">
          <div class="close-toolbar" @click="closeMenu()"></div>
          <div class="image-button-container">
            <div>
              <button
                type="button"
                id="btnUploadImage"
                title="Upload image from your computer"
                @click="onUploadImage()"
              >
                  <i class="fas fa-upload fa-3x"></i>
              </button>
              <label for="btnUploadImage">Upload</label>
            </div>
            <div>
              <button
                type="button"
                id="btnSearchImageLibrary"
                title="Search our library for images"
                @click="onOpenSearch()"
              >
                <i class="fas fa-search fa-3x"></i>
              </button>
              <label for="btnSearchImageLibrary">Library</label>
            </div>
          </div>
          <div
            v-for="menuItem in maskAreas"
            :key="menuItem.id"
            :id="'addedImageContainer' + menuItem.id"
            class="placed-image-container"
            v-show="menuItem.isLabelVisible"
          >
          <!-- v-show="isLabelVisible" -->

            <div :id="'placedImageContainer' + menuItem.id" class="placed-images kb-wrapper">
              <div class="image-area-label">
                <span>{{ menuItem.text }}: </span>
              </div>
              <!-- insert KitBuilder image placement here  -->
            </div>
          </div>
        </div>
      `
    }
  });
})(sy);
