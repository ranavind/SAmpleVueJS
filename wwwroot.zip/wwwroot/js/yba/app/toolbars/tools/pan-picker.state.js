﻿(sy => {
  sy.stateModules.push({
    name: 'stylePicker',
    module: {
      state: () => ({
        isVisible: false,
        styles: [],
        matrix: [],
        currentOffset: 0,
        imageWidth: 270,
        pagination: {
          CurrentPage: 0,
          TotalPages: 0,
          PageSize: 15,
          TotalCount: 0,
          HasPrevious: false,
          HasNext: false
        }
      }),
      mutations: {
        stylePickerToggleVisibility: (state, visible) => state.isVisible = visible,
        stylePickerAppendStyles: (state, styles) => state.styles = state.styles.concat(styles),
        stylePickerUpdateMatrix: (state, matrix) => state.matrix = state.matrix.concat(matrix),
        stylePickerUpdateOffset: (state, offset) => state.currentOffset = offset,
        stylePickerUpdatePagination: (state, pagination) => state.pagination = pagination,
        stylePickerUpdateHero: (state, { index, value }) => state.matrix[index].hero = value
      },
      actions: {
        stylePickerHide: (transaction) => transaction.commit('stylePickerToggleVisibility', false),
        stylePickerShow: (transaction) => {
          if (transaction.state.styles.length == 0) {
            transaction.dispatch('stylePickerFetchStyles');
            return;
          }
          transaction.commit('stylePickerToggleVisibility', true);
        },
        stylePickerSetHero(transaction, heroId) {
          let index = transaction.state.matrix.findIndex(m => m.hero === true);
          transaction.commit('stylePickerUpdateHero', { index, value: false });

          index = transaction.state.matrix.findIndex(m => m.id === heroId);
          transaction.commit('stylePickerUpdateHero', { index, value: true });
        },
        stylePickerFetchStyles(transaction) {
          let request = {
            method: 'get',
            url: '/api/productsapi/search',
            params: {
              page: transaction.state.pagination.CurrentPage + 1,
              pageSize: transaction.state.pagination.PageSize
            }
          }
          axios(request).then(response => transaction.dispatch('stylePickerAppendStyles', response));
        },

        stylePickerAppendStyles(transaction, response) {

          const payload = response.data;
          const pagination = JSON.parse(response.headers['x-pagination']);

          let products = payload.map(p => {
            return {
              id: p.Id,
              name: p.Name,
              href: `/${p.SeName}/${p.RendererUrl}`,
              hash: `${p.RendererUrl}`,
              image: p.DefaultPictureModel.FullSizeImageUrl
            };
          });
          let shouldInitMatrix = transaction.state.matrix.length === 0;

          transaction.commit('stylePickerAppendStyles', products);
          transaction.commit('stylePickerUpdatePagination', pagination);

          if (shouldInitMatrix) transaction.dispatch('stylePickerInitMatrix');
        },

        stylePickerInitMatrix(transaction) {
          let imgWidth = transaction.state.imageWidth;
          let styles = transaction.state.styles;

          let matrix = [
            { posX: -1, posY: -1, x: -imgWidth, y: -imgWidth, id: styles[0].id, image: styles[0].image, href: styles[0].href, hero: false, hash: styles[0].RendererUrl },
            { posX: 0, posY: -1, x: 0, y: -imgWidth, id: styles[1].id, image: styles[1].image, href: styles[1].href, hero: false, hash: styles[1].RendererUrl },
            { posX: 1, posY: -1, x: imgWidth, y: -imgWidth, id: styles[2].id, image: styles[2].image, href: styles[2].href, hero: false, hash: styles[2].RendererUrl },

            { posX: -1, posY: 0, x: -imgWidth, y: 0, id: styles[3].id, image: styles[3].image, href: styles[3].href, hero: false, hash: styles[3].RendererUrl },
            { posX: 0, posY: 0, x: 0, y: 0, id: styles[4].id, image: styles[4].image, href: styles[4].href, hero: true, hash: styles[4].RendererUrl },
            { posX: 1, posY: 0, x: imgWidth, y: 0, id: styles[5].id, image: styles[5].image, href: styles[5].href, hero: false, hash: styles[5].RendererUrl },

            { posX: -1, posY: 1, x: -imgWidth, y: imgWidth, id: styles[6].id, image: styles[6].image, href: styles[6].href, hero: false, hash: styles[6].RendererUrl },
            { posX: 0, posY: 1, x: 0, y: imgWidth, id: styles[7].id, image: styles[7].image, href: styles[7].href, hero: false, hash: styles[7].RendererUrl },
            { posX: 1, posY: 1, x: imgWidth, y: imgWidth, id: styles[8].id, image: styles[8].image, href: styles[8].href, hero: false, hash: styles[8].RendererUrl }
          ];
          transaction.commit('stylePickerUpdateMatrix', matrix);
          transaction.commit('stylePickerUpdateOffset', matrix.length);
          transaction.commit('stylePickerToggleVisibility', true);
        },

        stylePickerMatrixScrolled(transaction, id) {

          const matrixCoordinates = [
            { x: -1, y: -1 }, // topLeft
            { x: 0, y: -1 },  // topCenter
            { x: 1, y: -1 },  // topRight

            { x: -1, y: 0 }, // middleLeft
            { x: 0, y: 0 },  // middleCenter
            { x: 1, y: 0 },  // middleRight

            { x: -1, y: 1 }, // bottomLeft
            { x: 0, y: 1 },  // bottomCenter
            { x: 1, y: 1 }   // bottomRight
          ];

          const selectedItem = transaction.state.matrix.find(x => x.id === id);
          let offset = transaction.state.currentOffset + 1;
          matrixCoordinates.forEach(coord => {

            let x = selectedItem.posX + coord.x;
            let y = selectedItem.posY + coord.y;
            let state = transaction.state;
            let loaded = state.matrix.find(row => row.posX === x && row.posY === y);

            if (!loaded) {
              // ToDo: need to load more styles
              if (offset < transaction.state.styles.length) {
                const newItem = {
                  posX: x,
                  posY: y, x: x * state.imageWidth,
                  y: y * state.imageWidth,
                  id: state.styles[offset].id,
                  image: state.styles[offset].image,
                  href: state.styles[offset].href,
                  hash: state.styles[offset].hash,
                  hero: false
                };
                transaction.commit('stylePickerUpdateMatrix', [newItem]);
                transaction.commit('stylePickerUpdateOffset', offset);
                offset++;
              }
            }
          });

          // Load more records if we're near the end of the loaded data
          if ((transaction.state.styles.length - offset) < 5 && transaction.state.pagination.HasNext) {
            transaction.dispatch('stylePickerFetchStyles');
          }
        },
      },
      getters: {
        stylePickerVisible: state => {
          return state.isVisible;
        },
        stylePickerMatrix: state => {
          return state.matrix;
        }
      }
    }
  });
})(sy);