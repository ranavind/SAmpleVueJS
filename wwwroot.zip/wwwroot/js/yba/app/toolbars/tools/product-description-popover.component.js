((sy) => {
  sy.components.push({
    element: 'sy-product-description-popover',
    component: {
      computed: {
        collapsed() {
          return this.$store.getters.toolbarsPurchaseCollapsed;
        },
        isVisible() {
          return this.$store.getters.toolbars_ProductDescriptionIsVisible
        },
        description() {
          return this.$store.getters.product_fullDescription;
        },
        productName() {
          return this.$store.getters.product_productName;
        }
      },
      methods: {
        onClose() {
          this.$store.dispatch('toolbars_toggleProductPrice');
        }
      },
      template: `
        <div
          id="productDescriptionPopover"
          v-show="!collapsed && isVisible"
          class="product-description-popover-container"
        >
          <div class="product-description-popover-bubble">
            <h2 class="product-title">{{ productName }}</h2>
            <span class="product-close" @click="onClose()">
                <i class="fas fa-times"></i>
            </span>
            <div class="product-description">
              <p v-html="description"></p>
            </div>
          </div>
          <div class="product-description-popover-callout-container">
            <div class="product-description-popover-callout-arrow-outer"></div>
            <div class="product-description-popover-callout-arrow-inner"></div>
          </div>
        </div>
      `
    }
  });
})(sy);
