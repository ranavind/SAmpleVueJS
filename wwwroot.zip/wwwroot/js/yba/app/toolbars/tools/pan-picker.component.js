﻿
(sy => {
  sy.components.push({
    element: 'sy-style-picker',
    component: {
      data() {
        return {
          expand: false,
          container: {
            x: -125,
            y: -125
          },
          currentSelectedId: 0
        }
      },
      computed: {
        pickerVisible() {
          setTimeout(() => this.expand = this.$store.getters.stylePickerVisible, 100);
          return this.$store.getters.stylePickerVisible;
        },
        matrix() {
          return this.$store.getters.stylePickerMatrix;
        },
      },
      methods: {
        onItemClick(event) {

          const triggerElement = event.target;

          // Only proces events from products
          if (!triggerElement.classList.contains('picker-choice')) {
            return;
          }

          const newSelectedId = parseInt(triggerElement.getAttribute('data-item-id'), 10);
          const selectedItem = this.$store.state.stylePicker.matrix.find(x => x.id === newSelectedId);

          if (newSelectedId === this.currentSelectedId) {
            const styleItem = this.$store.state.stylePicker.styles.find(x => x.id === newSelectedId);
            
            const basketIndex = window.location.hash.indexOf('basket');
            const basketIndexFragment = window.location.hash.substring(basketIndex);
            let basketIndexParm = basketIndexFragment.split('&')[0]; // Url may contain additional parameters, split on ampersand
            const delimiter = (styleItem.hash && styleItem.hash.indexOf('?') > -1) ? '&' : '?';

            window.location.hash = `${styleItem.hash}${delimiter}${basketIndexParm}`;
            this.closeMenu();
            return;
          } else {
            this.$store.dispatch('stylePickerMatrixScrolled', newSelectedId);
            this.$store.dispatch('stylePickerSetHero', newSelectedId);
            this.currentSelectedId = newSelectedId;
          }

          let imageWidth = this.$store.state.stylePicker.imageWidth;
          this.container.x = (selectedItem.posX * -1) * imageWidth - (imageWidth / 2);
          this.container.y = (selectedItem.posY * -1) * imageWidth - (imageWidth / 2);
        },
        closeMenu() {
          this.$store.commit("toolbar_ClearSelectedTool");
          this.$store.dispatch('stylePickerHide');
        }
      },
      template: `
        <div
          id="styleViewport"
          class="style-viewport"
          v-if="pickerVisible"
          @click="onItemClick($event)"
          :class="[{ 'expand': expand }]"
        >
          <div class="close-toolbar" @click="closeMenu()"></div>
          <div
            id="styleContainer"
            class="style-container"
            :style="{ transform: 'translate(' + container.x + 'px, ' + container.y + 'px)' }"
          >
            <template v-for="product in matrix" :key="product.id">
              <div
                :class="[ 'picker-choice', { 'hero': product.hero } ] "
                :style="[{ top: product.y + 'px' }, { left: product.x + 'px' }, { 'background-image': 'url(' + product.image + ')' }, { 'background-size': 'contain' } ]"
                :id="'picker-' + product.id"
                :data-item-id="product.id"
              >
              </div>
            </template>
          </div>
        </div>
      `
    }
  });
})(sy);