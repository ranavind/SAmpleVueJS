((sy) => {
  sy.components.push({
    element: 'sy-color-menu',
    component: {
      name: 'colorMenu',
      data() {
        return {
          menuItems: [],
          selectedItem: ''
        }
      },
      beforeMount() {
        this.$bus.on('product_change', data => { 
          // console.log('color picker received product change event');
          this.reset();
        })
      },
      beforeUnmount() {
        this.$bus.off('product_change', data => { 
          this.reset();
        })
      },
      methods: {
        displayColorPicker(menuItem, e) {
          if (this.selectedItem !== menuItem.id) {
            menuItem.top = `${e.offsetTop + 40}px`;
            this.selectedItem = menuItem.id;
          } else {
            this.selectedItem = '';
          }
        },
        reset() {
          // Remove all the children that we manually appended
          this.menuItems.forEach(item => {
            let menuItemContainer = document.getElementById('menuItemContainer' + item.id);
            if (!menuItemContainer) { return; }
            while (menuItemContainer.firstChild) {
              menuItemContainer.removeChild(menuItemContainer.firstChild);
            }
          });
          // console.log('Clear color menu');
          this.menuItems = [];
        },
        repositionKbPickers() {
          if (this.menuItems && this.menuItems.length > 0) { return; }

          let colorContainers = document.querySelector('.kb-wizard > li > div').children;
          this.menuItems.length = 0;
          this.selectedItem = '';
          colorContainers.forEach(color => {
            // Check to see if it has a color picker child
            if (color.getElementsByClassName('kb-tile-picker-color').length > 0) {
              let menuItem = {
                text: color.children[0].innerText,
                id: this.menuItems.length, // color.classList.value.replace('-', '')
                kbSelector: `.${color.classList.value}`, //  '.kb-group-base-colour',
                isLoaded: false,
                top: 0,
                selectedColor: 'white'
              }
              this.menuItems.push(menuItem);
            }
          });

          // Need Vue to digest the model change and update the dom before
          // we move the KB color pickers to the menu
          // use a timeout to achieve this
          setTimeout(() => {
            this.menuItems.forEach(item => {
              if (!item.isLoaded) {
                let kbColorContainer = document.querySelector(item.kbSelector);
                let menuItemContainer = document.getElementById('menuItemContainer' + item.id);

                let node = kbColorContainer.getElementsByClassName('kb-wizard-form-row')[0];
                node.style = 'display: block !important; visibility: visible !important';

                node = kbColorContainer.getElementsByClassName('kb-wizard-form-label')[0];
                node.style = 'display: none !important';

                menuItemContainer.append(kbColorContainer);

                const colorValue = kbColorContainer.querySelector(`input[type="radio"]:checked`).value;
                item.selectedColor = this.extractColorValue(colorValue);
                item.isLoaded = true;

                if (this.menuItems.length == 1) {
                  // Display default color picker if there is only 1
                  this.displayColorPicker(this.menuItems[0], menuItemContainer);
                }
              }
            });

          }, 1);
        },
        colorChanged(menuItem) {
          colorValue = document.querySelector(`${menuItem.kbSelector} input[type="radio"]:checked`).value;
          menuItem.selectedColor = this.extractColorValue(colorValue);
        },
        closeMenu() {
          this.$store.commit("toolbar_ClearSelectedTool");
          this.selectedItem = '';
        },
        closeColorPicker() {
          this.selectedItem = '';
        },
        extractColorValue(colorValue) {
          if (colorValue.substring(0, 1) === '#')
          {
            return colorValue;
          } else if (colorValue.startsWith('kb-cmyk')) {
            return colorValue.substring(8, 15);
          }
          return '#fff';
        }
      },
      template: `
        <div class="sy-color-menu sy-toolbar-color-menu">
          <div class="close-toolbar" @click="closeMenu()"></div>
          <ul>
            <li
              v-for="menuItem in menuItems" :key="menuItem.id"
              @click="displayColorPicker(menuItem, $event.currentTarget)"
              :class="['sy-color-menu-item',
              { 'active': menuItem.id === selectedItem }]"
            >
              <label>{{ menuItem.text }}</label>
              <button 
                type="button" 
                class="color-dropdown-button"
                @click="displayColorPicker(menuItem, index, $event)"
              >
                  <i class="fas fa-caret-down outer-arrow"></i>
                  <i class="fas fa-caret-down inner-arrow" :style="{ 'color': menuItem.selectedColor }"></i>
              </button>
            </li>
          </ul>
          <div
            v-for="menuItem in menuItems"
            :key="menuItem.id"
            v-show="menuItem.id === selectedItem"
            :id="'menuItemContainer' + menuItem.id"
            class="sy-color-picker-body"
            :style="{ top: menuItem.top }"
            @click="colorChanged(menuItem)"
          >
            <div class="close-toolbar" @click="closeColorPicker()"></div>
              <!-- KB Color Picker will be inserted here -->
          </div>
        </div>
      `
    }
  });
})(sy);
