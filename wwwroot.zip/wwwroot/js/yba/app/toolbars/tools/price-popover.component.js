﻿((sy) => {
  sy.components.push({
    element: 'sy-price-popover',
    component: {
      data() {
        return { }
      },
      methods: {
      },
      computed: {
        collapsed() {
          return this.$store.getters.toolbarsPurchaseCollapsed;
        },
        isVisible() {
          return this.$store.getters.toolbars_ProductPriceIsVisible;
        },
        dollars() {
          return this.$store.getters.product_priceDollars;
        },
        cents() {
          return this.$store.getters.product_priceCents;
        }
      },
      template: `
        <div
          id="shirtPricePopover"
          v-show="!collapsed && isVisible"
          class="price-popover-container"
        >
          <div class="price-popover-bubble">
            <div>
              <span class="price-dollars"> {{ '$' + dollars }} </span>
              <span class="price-cents"> {{ cents }} </span>
            </div>
            <div>
              <span class="price-shipping"> + tax &amp; shipping </span>
            </div>
          </div>
          <div class="price-popover-callout-container">
            <div class="price-popover-callout-arrow-outer"></div>
            <div class="price-popover-callout-arrow-inner"></div>
          </div>
        </div>
      `
    }
  });
})(sy);
