﻿((sy) => {
  sy.components.push({
    element: 'sy-text-menu',
    component: {
      name: 'textMenu',
      data() {
        return {
          maskAreas: [],
          selectedItem: '',
          domObserver: null,
          selectedInputId: ''
        }
      },
      beforeMount() {
        this.$bus.on('product_change', data => { 
          this.reset();
        })
        this.$bus.on('product_loaded', data => {
          this.repositionKbPickers();
        });
      },
      beforeUnmount() {
        this.$bus.off('product_change', data => {
          this.reset();
        });
        if (this.domObserver) {
          this.domObserver.disconnect();
        };
      },
      methods: {
        reset() {
          console.log('text picker menu reset');
          // Stop watching Dom
          if (this.domObserver) {
            this.domObserver.disconnect();
          };

          // Clear reparented KitBuilder child nodes
          this.maskAreas.forEach(area => {
            area.items.forEach(item => {
              item.scope = null;
            });
            area.items.length = 0;
            area.kbElement = null;
            area.scope = null;
            area.placedTextScope = null;

            let addTextContainer = document.getElementById(`addedTextItems${area.id}`);

            // Remove text inputs
            if (addTextContainer) {
              while (addTextContainer.firstChild) {
                addTextContainer.removeChild(addTextContainer.firstChild);
              }
            }

            // Remove text color picker
            let colorPickerContainer = document.getElementById(`textColorPicker${area.id}`);
            if (colorPickerContainer) {
              while (colorPickerContainer.lastChild && colorPickerContainer.childNodes.length > 1) {
                if (!colorPickerContainer.lastChild.classList.contains('close-toolbar'))
                colorPickerContainer.removeChild(colorPickerContainer.lastChild);
              }
            }
          })

          // Clear mask areas
          this.maskAreas.length = 0;
          this.selectedItem = '';
        },
        displayMenu(toolbarMenuItem, e) {
          if (this.selectedItem !== toolbarMenuItem.id) {
            toolbarMenuItem.top = `${e.currentTarget.offsetTop + 40}px`;
            this.selectedItem = toolbarMenuItem.id;
          } else {
            this.selectedItem = '';
          }
        },
        watchDom() {
          let dom = document.querySelector('.sy-toolbar-add-text-menu');

          // Options for the observer (which mutations to observe)
          const config = { attributes: true, childList: true, subtree: true };
          let updateTextItems = this.updateTextItems;

          // Callback function to execute when mutations are observed
          const domMutated = function (mutationsList, observer) {
            for (const mutation of mutationsList) {
              if (mutation.type !== 'attributes') {
                updateTextItems();
              }
            }
          };

          // Create an observer instance linked to the callback function
          this.domObserver = new MutationObserver(domMutated);

          // Start observing the target node for configured mutations
          this.domObserver.observe(dom, config);
        },
        repositionKbPickers() {
          // Check if text areas have already been loaded
          if (this.maskAreas.length > 0) { return; }

          // Set up mask text areas
          let kitBuilderTextAreas = document.querySelectorAll(".kb-wizard-form > ul > li:nth-child(3) .kb-editor-placement");
          let idx = -1;
          kitBuilderTextAreas.forEach(textAreaNode => {
            idx++;

            let textHeadingNode = textAreaNode.querySelector('.kb-editor-heading');
            if (textHeadingNode && textHeadingNode.innerText) {
              let maskArea = {
                text: textHeadingNode.innerText,
                id: this.maskAreas.length,
                kbElement: textAreaNode.parentElement.parentElement,
                isLoaded: false,
                top: 0,
                items: [],
                scope: angular.element(textHeadingNode).scope(),
                placedTextScope: angular.element(textAreaNode.querySelector('.kb-editor-placed-texts')).scope(),
                isColorPickerVisible: false,
                index: idx
              }
              this.maskAreas.push(maskArea);

              let placedTextScope = angular.element(textAreaNode.querySelector('.kb-editor-placed-texts')).scope();
              let texts = placedTextScope.getModel('text', placedTextScope.placement.placementKey);

              texts.forEach(text => {
                let textItem = {
                  text: text.text,
                  id: maskArea.items.length,
                  fontColor: this.extractColorValue(text.fontColor),
                  strokeColor: text.strokeColor,
                  scope: placedTextScope,
                  kbItem: text,
                  isEditMode: false
                }
                maskArea.items.push(textItem);
              });

            }
          });

          setTimeout(() => {
            this.maskAreas.forEach(item => {

              if (item.kbElement) {
                // Reparent placed text
                let addTextContainer = document.getElementById(`addedTextItems${item.id}`);
                let kbPlacedText = item.kbElement.querySelector('.kb-editor-placed-texts');
                addTextContainer.append(kbPlacedText);

                // Reparent placed text color picker
                let colorPickerContainer = document.getElementById(`textColorPicker${item.id}`);
                let kbColorPicker = item.kbElement.querySelector('.kb-editor-text-controls');
                colorPickerContainer.append(kbColorPicker);

                item.isLoaded = true;
              }

            });

            this.watchDom();
          }, 1);

        },
        updateTextItems() {
          // console.log('update text items');
          this.maskAreas.forEach(maskArea => {
            let texts = maskArea.placedTextScope.getModel('text', maskArea.placedTextScope.placement.placementKey);
            if (maskArea.items.length !== texts.length) {
              maskArea.items.length = 0;
              texts.forEach(text => {
                let textItem = {
                  text: text.text,
                  id: maskArea.items.length,
                  fontColor: this.extractColorValue(text.fontColor),
                  strokeColor: text.strokeColor,
                  scope: maskArea.placedTextScope,
                  kbItem: text,
                  isEditMode: false
                }
                maskArea.items.push(textItem);
              });
            }

            // Identify side with text printing and update state for pricing
            let sideText = maskArea.text.toLowerCase();
            let side = sideText.indexOf('front') > 0 ? 'front' :
              sideText.indexOf('back') > 0 ? 'back' :
              sideText.indexOf('left') > 0 ? 'left' :
              sideText.indexOf('right') > 0 ? 'right' : null;

            // Update price for DTG garments that are printed on more than one side
            if (maskArea.items.length > 0 && side !== null) {
              this.$store.commit('product_setTextSide', { side, value: true });
            } else {
              this.$store.commit('product_setTextSide', { side, value: false });
            }
          })
        },
        onColorChange(maskArea, index, event) {
          const selectedColor = event.target.getAttribute('kb-bg-color');
          if (selectedColor) {
            maskArea.items[index].fontColor = this.extractColorValue(selectedColor);
          }
        },
        onAddNewText(maskArea) {
          maskArea.scope.addText(maskArea.scope.placement.placementKey);
        },
        onDoneEditing() {
          item.isEditMode = false;
        },
        onDeleteText(item) {
          // item.scope.deleteItem(item.kbItem)
          // ToDo: remove item from array
        },
        onFocusDisplayColorPicker(maskArea, index, e) {
          e.preventDefault();
          e.stopPropagation();

          if (e.target.type == "text") {
            if (maskArea.text.toLowerCase().indexOf('front') > -1) {
              // Rotate model to front
              angular.element(document.querySelector('.kb-preview-panel')).scope().changeView(0);

            } else if (maskArea.text.toLowerCase().indexOf('back') > -1) {
              // Rotate model to back
              angular.element(document.querySelector('.kb-preview-panel')).scope().changeView(1);
            }

            this.selectedInputId = e.target.id;
            maskArea.isColorPickerVisible = true;
            if (maskArea.isColorPickerVisible) {
              let currentInput = angular.element(document.getElementById(this.selectedInputId));
              currentInput.triggerHandler('mousedown');
              maskArea.top = `${e.target.offsetTop + 30}px`;
            }
          } else if (e.target.tagName.toLowerCase() == 'span' && e.target.classList.contains("kb-tile-picker-tile")) {
            let inputs = document.querySelectorAll(`#maskAreaContainer${maskArea.id} input`);
            let idx = 0;
            for (let cnt = 0; cnt < inputs.length; cnt++) {
              if (inputs[cnt].id === this.selectedInputId) {
                idx = cnt;
                break;
              }
            }

            this.onColorChange(maskArea, idx, e);
            return;
          } else {
            return;
          }

          this.maskAreas.forEach(i => {
            if (i.id !== maskArea.id) {
              i.isColorPickerVisible = false;
            }
          });
        },

        onColorPickerArrowClick(maskArea, index, e) {
          e.preventDefault();
          e.stopPropagation();

          maskArea.isColorPickerVisible = !maskArea.isColorPickerVisible;
          if (maskArea.isColorPickerVisible) {
            let inputs = document.querySelectorAll(`#maskAreaContainer${maskArea.id} input`);
            let currentInput = angular.element(inputs[index]);
            this.selectedInputId = inputs[index].id;
            currentInput.triggerHandler('mousedown');
            maskArea.top = `${e.currentTarget.offsetTop + 23}px`;
          }

          this.maskAreas.forEach(x => {
            if (x.id !== maskArea.id) {
              x.isColorPickerVisible = false;
            }
          });

          // KitBuildre - use this to switch to front or back
          // changeView(1) - back
          // changeView(0) - front
        },

        closeColorPicker(menuItem, e) {
          e.preventDefault();
          e.stopPropagation();
          menuItem.isColorPickerVisible = false;
        },
        closeMenu() {
          this.$store.commit("toolbar_ClearSelectedTool");
        },
        extractColorValue(colorValue) {
          if (colorValue.substring(0, 1) === '#')
          {
            return colorValue;
          } else if (colorValue.startsWith('kb-cmyk')) {
            return colorValue.substring(8, 15);
          }
          return '#fff';
        }
      },
      template: `
        <div class="sy-toolbar-add-text-menu">
          <div class="close-toolbar" @click="closeMenu()"></div>
          <div v-for="(maskArea, index) in maskAreas" :key="maskArea.id" @click="onFocusDisplayColorPicker(maskArea, index, $event)">
            
            <!-- This contains the text inputs for that clip mask area -->
            <div :id="'maskAreaContainer' + maskArea.id" class="added-text-container">
              <div :id="'addedTextItems' + maskArea.id"></div>
              <div :id="'textColorPicker' + maskArea.id"
                :v-show="maskArea.isColorPickerVisible"
                class="color-picker-container"
                :style="{ display: maskArea.isColorPickerVisible ? 'block !important' : 'none', top: maskArea.top }"
              >
                <div class="close-toolbar" @click="closeColorPicker(maskArea, $event)"></div>
              </div>
            </div>
            
            <!-- This contains the color picker arrows for -->
            <div class="added-text-color-container">
              <ul>
                <li v-for="(item, index) in maskArea.items">
                  <button 
                    type="button"
                    @click="onColorPickerArrowClick(maskArea, index, $event)">

                    <!-- Outline of arrow -->
                    <i class="fas fa-caret-down outer-arrow"></i>

                    <!-- Inside color of arrow -->
                    <i 
                      class="fas fa-caret-down inner-arrow" 
                      :style="{ 'color': item.fontColor }"
                    ></i>
                  </button>
                </li>
              </ul>
            </div>

            <div class="add-text-button-container" style="z-index: 10">
              <span>{{ maskArea.text }}</span>
              <button type="button" @click="onAddNewText(maskArea)">
                <i class="fas fa-plus"></i>
              </button>
            </div>
          </div>
        </div>
      `
    }
  });
})(sy);
