﻿((sy) => {
  sy.stateModules.push({
    name: 'toolbars',
    module: {
      state: () => ({
        isVisible: false,
        editorToolbar: {
          collapsed: false,
          selectedTool: { name: '', isSubMenuVisible: false }
        },
        purchaseToolbar: {
          collapsed: false,
          productPriceIsVisible: true,
          productDescriptionIsVisible: false
        },
      }),
      mutations: {
        toolbar_ToggleVisibility(state, visible) {
          state.isVisible = visible;
        },
        toolbar_SetCollapse(state, { toolbar, collapsed }) {
          if (toolbar == 'editorToolbar') {
            state.editorToolbar.collapsed = collapsed;
          } else {
            state.purchaseToolbar.collapsed = collapsed;
          }
        },
        toolbar_ToggleCollapse(state, { toolbar }) {
          if (toolbar == 'editorToolbar') {
            state.editorToolbar.collapsed = !state.editorToolbar.collapsed;
          } else {
            state.purchaseToolbar.collapsed = !state.purchaseToolbar.collapsed;
          }
        },
        toolbar_SetSelectedTool(state, tool) {
          state.editorToolbar.selectedTool = tool;
        },
        toolbar_ClearSelectedTool(state) {
          state.editorToolbar.selectedTool = { name: '', isSubMenuVisible: false };
        },
        toolbar_Purchase_SetProductDescriptionVisible(state, value) {
          state.purchaseToolbar.productDescriptionIsVisible = value;
        },
        toolbar_Purchase_SetPriceVisible(state, value) {
          state.purchaseToolbar.productPriceIsVisible = value;
        }
      },
      actions: {
        toolbars_show: (transaction) => {
          if (!transaction.rootState.splash.isVisible) {
            transaction.commit('toolbar_ToggleVisibility', true);
          }
        },
        toolbars_hide: (transaction) => transaction.commit('toolbar_ToggleVisibility', false),
        toolbars_collapse: (transaction, { toolbar }) => transaction.commit('toolbar_SetCollapse', { toolbar, collapsed: true }),
        toolbars_expand: (transaction, { toolbar }) => transaction.commit('toolbar_SetCollapse', { toolbar, collapsed: false }),
        toolbars_toggle: (transaction, { toolbar }) => transaction.commit('toolbar_ToggleCollapse', { toolbar }),
        toolbars_toggleProductPrice(transaction){ 
          if (transaction.state.purchaseToolbar.productDescriptionIsVisible) {
            transaction.commit('toolbar_Purchase_SetProductDescriptionVisible', false);
            transaction.commit('toolbar_Purchase_SetPriceVisible', true);
          } else {
            transaction.commit('toolbar_Purchase_SetProductDescriptionVisible', true);
            transaction.commit('toolbar_Purchase_SetPriceVisible', false);
          }
        }
      },
      getters: {
        toolbarsVisible: state => state.isVisible,
        toolbarsEditCollapsed: state => state.editorToolbar.collapsed,
        toolbarsPurchaseCollapsed: state => state.purchaseToolbar.collapsed,
        toolbarsEditSelectedTool: state => state.editorToolbar.selectedTool,
        toolbars_ProductPriceIsVisible: state => state.purchaseToolbar.productPriceIsVisible,
        toolbars_ProductDescriptionIsVisible: state => state.purchaseToolbar.productDescriptionIsVisible,
      }
    }
  });
})(sy);