((sy) => {
  sy.components.push({
    element: 'sy-toolbar-editors',
    component: {
      data() {
        return {
          tools: [
           /* { id: 1, title: 'merchandise', name: 'merchandise', image: 'fa-tshirt', controlId: 'btnMerchandise', top: 0, left: '95px' },*/
            { id: 2, title: 'colors', name: 'color', image: 'fa-palette', controlId: 'btnColorPicker', top: 0, left: '5px' },
            { id: 3, title: 'text', name: 'text', image: 'fa-font', controlId: 'btnAddText', top: 0, left: '95px' },
            { id: 4, title: 'images', name: 'image', image: 'fa-image', controlId: 'btnAddImage', top: 0, left: '95px' },
            { id: 5, title: 'print guide', name: 'printguide', image: 'fa-border-none', controlId: 'btnPrintGuide', top: 0, left: '95px' },
          ],
          title: 'DESIGN TOOLS',
          printGuide: false
        }
      },
      computed: {
        toolbarsVisible() {
          return this.$store.getters.toolbarsVisible;
        },
        collapsed() {
          return this.$store.getters.toolbarsEditCollapsed;
        },
        selectedTool() {
          return this.$store.getters.toolbarsEditSelectedTool || { name: '' };
        },
        isMobile() {
          return this.$store.getters.responsive_getDevice == 1;
        }
      },
      methods: {
        toolClick(tool, e) {

          if (this.selectedTool.name === tool.name) {
            this.$store.commit("toolbar_ClearSelectedTool");
            return;
          }

          this.$store.commit('toolbar_SetSelectedTool', tool);

          tool.top = `${e.target.offsetTop - 15}px`;
          tool.left = '95px';

          if (tool.name === 'merchandise') {
            this.$store.dispatch('productSearch_ShowDialog');
          } else if (tool.name === 'text') {
            this.$refs.textMenu.repositionKbPickers();
          } else if (tool.name === 'image') {
            this.$refs.imageMenu.repositionKbPickers();
          } else if (tool.name === 'color') {
            this.$refs.colorMenu.repositionKbPickers();
          } else if (tool.name = 'printguide') {
            const t = document.querySelector('.kb-wizard-form-key-print-guide input[type="checkbox"]');
            if (t) {
              t.click();
            }
            this.printGuide = t.checked;
            this.$store.commit("toolbar_ClearSelectedTool");
            return;
          }

          this.$store.dispatch('toolbars_collapse', { toolbar: 'purchaseToolbar', collapsed: true });
        },
        toggleCollapse() {
          this.$store.dispatch('toolbars_toggle', { toolbar: 'editorToolbar' })
        },
        closeMenu(tool) {
          tool.isSubMenuVisible = false;
        },
        initPrintGuide() {
          const kbPrintGuide = document.querySelector('.kb-wizard-form-key-print-guide');
          if (kbPrintGuide) {
            this.hasPrintGuide = true;
            this.printGuide = document.querySelector('.kb-wizard-form-key-print-guide input[type="checkbox"]').checked;
          }
        }
      },
      beforeMount() {
        this.$bus.on('product_loaded', data => {
          this.initPrintGuide();
        });
      },
      template: `
      <div class="" :class="[ 'toolbar', 'toolbar-left', 'toolbar-side', { 'toolbar-collapsed': collapsed } ]" v-show="toolbarsVisible">
        <div class="toolbar-title" @click="toggleCollapse()">
            <span class="toolbar-label">{{ title }}</span>
        </div>
        <div class="toolbar-arrow arrow-left" @click="toggleCollapse()"></div>
        <div class="toolbar-tools" id="toolsToolbarTools">
          <div class="toolbar-tools-body">
            <ul style="padding-left:1px!important;">
              <template v-for="tool in tools" :key="tool.id">
                <li>
                  <button 
                    class="toolbar-item" 
                    :class="[{ 'highlight': tool.name === 'printguide' && printGuide === true }]"
                    :id="tool.controlId" 
                    @click="toolClick(tool, $event)"
                  >
                    <i :class="['fas', tool.image]"></i>
                    <label class="tool-label">{{ tool.title }}</label>
                  </button>

                  <sy-text-menu
                    ref="textMenu"
                    v-if="tool.name === 'text'"
                    id="textMenu"
                    :style="{ top: isMobile ? 0 : tool.top, left: tool.left }"
                    :class="{ 'sy-toolbar-item-active': selectedTool.name === 'text' }"
                  ></sy-text-menu>

                  <sy-image-menu
                    ref="imageMenu"
                    id="imageMenu"
                    v-if="tool.name === 'image'"
                    :style="{ top: isMobile ? 0 : tool.top, left: tool.left }"
                    :class="{ 'sy-toolbar-item-active': selectedTool.name === 'image' }"
                  ></sy-image-menu>

                  <sy-color-menu
                    ref="colorMenu"
                    id="colorMenu"
                    v-if="tool.name === 'color'"
                    :style="{ top: isMobile ? 0 : tool.top, left: tool.left }"
                    :class="{ 'sy-toolbar-item-active': selectedTool.name === 'color' }"
                  ></sy-color-menu>
                </li>
                <li class="toolbar-divider" v-if="tool.id !== tools.length"></li>
              </template>
            </ul>
          </div>
        </div>
      </div>
    `
    }
  });
})(sy);