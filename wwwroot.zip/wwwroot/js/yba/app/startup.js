﻿(() => {

  window.addEventListener("load", function () {
    setTimeout(function () {
      // This hides the address bar:
      console.log('Hide address bar on mobile.');
      window.scrollTo(0, 1);
    }, 500);
  });

})();