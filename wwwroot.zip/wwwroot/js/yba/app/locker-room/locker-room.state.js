((sy) => {
  sy.stateModules.push({
    name: 'locker-room',
    module: {
      state: () => ({
      }),
      mutations: {
      },
      actions: { 
        lockerRoom_ShowSave: (transaction) => {
          if (yba.customer.isAuthenticated) {

            const customDesignId = window.location.hash.indexOf("customDesignId");
            if (customDesignId > -1) {
              let resaveButton = angular.element(document.querySelector('.kb-locker-room-buttons-save-update'))
              resaveButton.triggerHandler('click');
              return;
            }
            
            let saveButton = angular.element(document.querySelector('.kb-locker-room-buttons-save-new'))
            if (saveButton) {
              saveButton.triggerHandler('click')
              return;
            }

            console.log('Couldn\'t find save button to click');
            
            return;
          }
          document.getElementById('headerLoginLink').click();
        },
        
        lockerRoom_ShowLockerRoom: (transaction) => {
          if (yba.customer.isAuthenticated) {
            transaction.dispatch('stylePickerHide');
            transaction.dispatch('toolbars_hide');
            transaction.commit('product_clearProduct');
            window.location.hash = '#/locker-room';
            return;
          }
          document.getElementById('headerLoginLink').click();
        }

      },
      getters: {
        // splashIsVisible: state => state.isVisible,
      }
    }
  });
})(sy);