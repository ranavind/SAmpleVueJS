﻿((sy) => {
  sy.stateModules.push({
    name: 'splash',
    module: {
      state: () => ({
        isVisible: true,
        previouslyLoaded: true,
        loadCount: 0
      }),
      mutations: {
        splash_toggleVisible(state, isVisible) {
          state.isVisible = isVisible;
        },
        splash_setPreviouslyLoaded(state, previouslyLoaded) {
          state.previouslyLoaded = previouslyLoaded;
          localStorage.setItem('sy.previouslyLoaded', previouslyLoaded);
          localStorage.setItem('sy.lastLoadDate', new Date());
        },
        splash_incrementLoadCount(state) {
          state.loadCount = state.loadCount + 1;
          localStorage.setItem('sy.loadCount', state.loadCount);
        },
        splash_resetLoadCount(state) {
          state.loadCount = 0;
          localStorage.setItem('sy.loadCount', state.loadCount);
        },
        splash_setLoadCount(state, loadCount) {
          state.loadCount = +loadCount;
        }
      },
      actions: { 
        splash_show: transaction => transaction.commit('splash_toggleVisible', true),
        splash_hide: transaction => {
          transaction.commit('splash_toggleVisible', false);
          transaction.commit('splash_setPreviouslyLoaded', true);
          transaction.commit('splash_incrementLoadCount');
        },
        splash_rehydrateState: transaction => {
          const previouslyLoaded = localStorage.getItem('sy.previouslyLoaded');
          const firstDateLoad = localStorage.getItem('sy.lastLoadDate');
          if (firstDateLoad) {
            const today = new Date().getDate();
            const lastLoadedDay = new Date(firstDateLoad).getDate();
            if (today > lastLoadedDay) {
              transaction.commit('splash_resetLoadCount');
              // Exit, which will show the full animation sequence
              return;
            }
          }
          if (previouslyLoaded === 'true') {
            const loadCount = localStorage.getItem('sy.loadCount');
            transaction.commit('splash_setLoadCount', loadCount > 0 ? loadCount : 0);
            transaction.commit('splash_setPreviouslyLoaded', true);
          }
        }
      },
      getters: {
        splashIsVisible: state => state.isVisible,
        splashPreviouslyLoaded: state => state.previouslyLoaded,
        splashloadCount: state => state.loadCount
      }
    }
  });
})(sy);