((sy) => {
  sy.stateModules.push({
    name: 'waiting',
    module: {
      state: () => ({
        kitBuilderId: null,
        currentProduct: null,
        sidesWithImages: 0,
        images: {
          front: false,
          back: false,
          left: false,
          right: false
        },
        text: {
          front: false,
          back: false,
          left: false,
          right: false
        }
      }),
      mutations: {
        product_setKitBuilderId(state, kitBuilderId) {
          state.kitBuilderId = kitBuilderId;
        },
        product_setProduct(state, product) {
          state.currentProduct = product;
        },
        product_clearProduct(state) {
          state.currentProduct = null;
          state.kitBuilderId = null;

          state.images.front = false;
          state.images.back = false;
          state.images.left = false;
          state.images.right = false;
          state.text.front = false;
          state.text.back = false;
          state.text.left = false;
          state.text.right = false;
        },
        product_setImageSide(state, { side, value }) {
          state.images[side] = value;
        },
        product_setTextSide(state, { side, value }) {
          state.text[side] = value;
        }
      },
      actions: { 
        product_refreshProduct(transaction) {
          if (!transaction.rootState.splash.isVisible) {
            transaction.commit('waiting_setMessage', 'Getting the 3D model ready ...');
            transaction.dispatch('waiting_show');
          }

          const interval = setInterval(() => {
            console.log('waiting');
            const wrapper = document.querySelector('.kb-vector-wrapper');
            if (wrapper) {
              const isLoading = wrapper.classList.contains('kb-loading');
              if (!isLoading) {
                setTimeout(() => {
                  transaction.dispatch('waiting_hide');
                  sy.syApp.config.globalProperties.$bus.trigger('product_loaded');
                }, 1000)
                clearInterval(interval);
              }
            }
          }, 500);

          // Sample URL - #/customise/89880639?basketIndex=117&customDesignId=92774578
          let hash = window.location.hash;
          hash = hash.replace('#/customise/', ''); 
          let qsIndex = hash.indexOf('?');
          const kitBuilderProductId = hash.substring(0, qsIndex);
          transaction.commit('product_setKitBuilderId', kitBuilderProductId);
          sy.syApp.config.globalProperties.$bus.trigger('product_change', { productId: kitBuilderProductId });

          if (kitBuilderProductId === '' || kitBuilderProductId == null) {
            return;
          }

          let request = {
            method: 'get',
            url: '/api/productsapi/KitBuilderProduct',
            params: {
              kitBuilderId: kitBuilderProductId
            }
          }
          axios(request)
            .then(response => {
              transaction.commit('product_setProduct', response.data);
            });
        }
      },
      getters: {
        product_kitBuilderId: state => state.kitBuilderId,
        product_price: (state, getters) => {
          let price = state.currentProduct ? state.currentProduct.Price.PriceValue : 0;

          // No adjustments for non DTG products
          if (!getters.product_isDtg) {
            return price;
          }

          let printSidesAttribute = state.currentProduct.Attributes.find(x => x.Name.toLowerCase().indexOf('print') > -1);
          if (getters.product_sidesWithPrinting > 0 && printSidesAttribute) {
            // Locate Product Atribute that has a number corresponding to the number of printed sides
            let printSidesValue = printSidesAttribute.Values.find(x => x.Name.indexOf(getters.product_sidesWithPrinting) > -1);
            if (printSidesValue) {
              price += printSidesValue.PriceAdjustmentValue;
            }
          }
          return price;
        },
        product_priceDollars: (state, getters) => {
          const price = getters.product_price.toString().split('.');
          const dollars = price.length > 0 ? price[0] : 0;
          return dollars;
        },
        product_priceCents: (state, getters) => {
          const price = getters.product_price.toString().split('.');
          const cents = price.length > 1 ? (price[1].replace('.', '') + '00').substring(0, 2) : '00';
          return cents;
        },
        product_liveShareEnabled: state => {
          return state.currentProduct && state.currentProduct.LiveShareEnabled === true
        },
        product_lockerRoomEnabled: state => {
          return state.currentProduct && state.currentProduct.LockerRoomEnabled === true
        },
        product_sidesWithPrinting: state => {
          let cnt = 0;
          if (state.images.front || state.text.front) cnt++;
          if (state.images.back || state.text.back) cnt++;
          if (state.images.left || state.text.left) cnt++;
          if (state.images.right || state.text.right) cnt++;
          return cnt;
        },
        product_fullDescription: state => (state.currentProduct && state.currentProduct.FullDescription) ? state.currentProduct.FullDescription : '' ,
        product_productName: state => (state.currentProduct && state.currentProduct.Name) ? state.currentProduct.Name : '',
        product_isDtg: state => (state.currentProduct && state.currentProduct.Tags) ? state.currentProduct.Tags.findIndex(tag => tag == "dtg") > -1 : false,
        product_isSublimation: state => (state.currentProduct && state.currentProduct.Tags) ? state.currentProduct.Tags.findIndex(tag => tag == "sublimation") > -1 : false
      }
    }
  });
})(sy);

