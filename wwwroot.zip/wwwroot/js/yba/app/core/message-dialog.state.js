((sy) => {
  sy.stateModules.push({
    name: 'messageDialog',
    module: {
      state: () => ({
        isVisible: false,
        message: '',
        dialogType: 1,
        title: ''     // 1 = info, 2 = warning, 3 = error
      }),
      mutations: {
        messageDialog_hide(state) {
          state.isVisible = false;
        },
        messageDialog_show(state, { message, dialogType, title }) {
          state.isVisible = true;
          state.message = message || '';
          state.dialogType = dialogType || 1;
          state.title = title || '';
        },
      },
      actions: { 
      },
      getters: {
        messageDialogIsVisible: state => state.isVisible,
        messageDialogTitle: state => state.title,
        messageDialogMessage: state => state.message,
        messageDialogType: state => state.dialogType,
      }
    }
  });
})(sy);