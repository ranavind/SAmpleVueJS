﻿((sy) => {
  sy.stateModules.push({
    name: 'waitingState',
    module: {
      state: () => ({
        isVisible: false,
        message: 'Test Message'
      }),
      mutations: {
        waiting_toggleVisible(state, isVisible) {
          state.isVisible = isVisible;
          // Clear message when hiding the spinnger
          state.message = isVisible ? state.message : '';
        },
        waiting_setMessage(state, message) {
          state.message = message;
        }
      },
      actions: { 
        waiting_show: transaction => transaction.commit('waiting_toggleVisible', true),
        waiting_hide: transaction => transaction.commit('waiting_toggleVisible', false),
      },
      getters: {
        waitingIsVisible: state => state.isVisible,
        waitingMessage: state => state.message
      }
    }
  });
})(sy);

