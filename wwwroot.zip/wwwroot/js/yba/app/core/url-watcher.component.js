((sy) => {
  sy.components.push({
    element: "sy-url-watcher",
    component: {
      name: "urlWatcher",
      data() {
        return {
          oldHash: "",
          oldProductId: "",
          resizedSmaller: false,
          interval: null,
          mobileMenuLinks: null,
          skipMenuFirstClick: false
        };
      },
      mounted() {
        window.addEventListener("hashchange", (e) => this.urlChanged(e));
        this.urlChanged(null);

        window.addEventListener("resize", this.resized);
        this.interval = setInterval(() => {
          const panels = document.querySelectorAll(".kb-wrapper .kb-customise-page .kb-preview-panel, .kb-locker-room-wrapper");
          console.log('Waiting for KB to load. resized width', window.innerWidth);
          if (panels.length > 0) {
            this.resized();
            clearInterval(this.interval);
            this.interval = null;
          }
        }, 1000);

        document.getElementById("syMobileMenu")
          .addEventListener("click", () => this.toggleMobileMenu());
        this.mobileMenuLinks = document.querySelector(".header-links");

        // Reset ReturnUrl for login/register links
        const registerLink = document.getElementById('headerRegisterLink');
        if (registerLink) {
          registerLink.href = registerLink.href + encodeURI(window.location.hash);
        }
        const loginLink = document.getElementById('headerLoginLink')
        if (loginLink) {
          loginLink.href = loginLink.href + encodeURI(window.location.hash);
        }
      },
      beforeUnmount() {
        window.removeEventListener("hashchange", this.urlChanged);
        if (this.interval) { clearInterval(this.interval); }
      },
      methods: {
        toggleMobileMenu() {
          if (this.mobileMenuLinks.classList.contains("visible")) {
            this.hideMobileMenu();            
          } else {
            this.showMobileMenu();
          }
        },
        showMobileMenu() {
          window.addEventListener('click', this.hideMobileMenu);
          this.mobileMenuLinks.classList.add("visible");
          console.log('add event');
          this.skipMenuFirstClick = true;
        },
        hideMobileMenu() {
          if (this.skipMenuFirstClick) {
            this.skipMenuFirstClick = false;
            console.log('skipped');
            return;
          }
          this.mobileMenuLinks.classList.remove("visible");
          window.removeEventListener('click', this.hideMobileMenu);
          console.log('remove event');
        },

        resized() {

          // Update resolution in state
          this.$store.commit('responsive_setResolution', { width: window.innerWidth, height: window.innerHeight });

          // *** Hack for Mobile browsers to get actual screen height without the built in url bar
          // First we get the viewport height and we multiple it by 1% to get a value for a vh unit
          // let vh = window.innerHeight * 0.01;

          // Then we set the value in the --vh custom property to the root of the document
          // document.documentElement.style.setProperty('--vh', `${vh}px`);

          const forEach = function (array, callback, scope) {
            for (var i = 0; i < array.length; i++) {
              callback.call(scope, i, array[i]); // passes back stuff we need
            }
          };
          // *** end ofhack

          const panels = document.querySelectorAll(
            ".kb-wrapper .kb-customise-page .kb-preview-panel"
          );
          const image = document.querySelectorAll(
            ".kb-wrapper .kb-customise-page .kb-3d-wrapper"
          );

          if (window.innerWidth < 760 || window.innerHeight < 770) {
            if (this.resizedSmaller) return;

            console.log("scale smaller");
            forEach(panels, (index, x) => {
              x.setAttribute("style", "width: 100% !important");
            });

            let height = 500;

            if (window.innerWidth > 750 && window.innerHeight < 1025 ) {
              height = 650;
            }

            forEach(image, (index, x) => {
              x.setAttribute(
                "style",
                `width: 100% !important; height: ${ height }px !important;`
              );
            });
            this.resizedSmaller = true;
          } else {
            if (!this.resizedSmaller) return;
            console.log("scale bigger");
            forEach(panels, (index, x) => {
              x.removeAttribute("style");
            });

            forEach(image, (index, x) => {
              x.removeAttribute("style");
            });

            this.resizedSmaller = false;
          }

          let kbMobileNav = document.querySelector(".kb-customize-mobile-nav");
          kbMobileNav.setAttribute("style", "display: none !important");
        },
        urlChanged(e) {
          console.log('url changed', window.location.hash);
          if (this.oldHash == window.location.hash) {
            return;
          }

          if (window.location.hash.indexOf('custom') > -1) { 
            this.$store.dispatch('product_refreshProduct');
            this.$store.commit('toolbar_ClearSelectedTool');
          }
          this.oldHash = window.location.hash;

          // Show/Hide Toolbars depending on view
          let fragment = window.location.hash.toString();
          if (fragment.toLowerCase().indexOf('custom') > -1) {
            this.$store.dispatch('toolbars_show');
          } else if (window.location.hash.indexOf('locker') > -1) {
            this.$store.dispatch('toolbars_hide');
          } else {
            window.location.hash = yba.homeProducts[0].RendererUrl;
          }
        },
      },
      template: `
        <div></div>
      `,
    },
  });
})(sy);
