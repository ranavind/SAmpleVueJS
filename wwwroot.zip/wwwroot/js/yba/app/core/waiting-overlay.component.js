﻿((sy) => {
  sy.components.push({
    element: 'sy-waiting',
    component: {
      computed: {
        isVisible() {
          return this.$store.getters.waitingIsVisible;
        },
        message() {
          return this.$store.getters.waitingMessage;
        }
      },
      template: `
        <div 
          id="syWaitingIndicator"
          class="waiting-overlay"
          v-if="isVisible"
        >
          <div class="waiting-message">
            {{ message }}
          </div>
          <div class="waiting-animation">
            <i class="waiting-t-shirt fas fa-tshirt fa-10x"></i>
            <i class="waiting-gear fas fa-cog fa-spin fa-5x gear"></i>        
          </div>
        </div>
      `
    }
  });
})(sy);

