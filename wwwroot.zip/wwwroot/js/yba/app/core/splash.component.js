﻿((sy) => {
  sy.components.push({
    element: 'sy-splash',
    component: {
      data() {
        return {
          start: false,
          fadeOut: false,
          step: 0,
          intervalHandle: null,
          frames: [
            { text: 'Hold on to your shirts ...', color: 'black', class: 'splash-bg-stripes' },
            { text: 'Getting our Shirt together', color: 'darkred', class: 'splash-bg-polka-dots' },
            { text: 'The shirt is hitting the fan', color: 'darkblue', class: 'splash-bg-arches' },
            { text: 'Holy shirt!', color: 'darkgreen', class: 'splash-bg-butterflies' },
            { text: 'Shirt Yourself!', color: 'black', class: 'splash-bg-paisley' },
          ],
          logoPattern: null,
          nextStep: 0
        }
      },
      beforeMount() {
        this.$store.dispatch('splash_rehydrateState');
      },
      mounted() {
        this.logoPattern = document.getElementById('logoPattern');
        this.updateAnimation();
        if (this.loadCount > 1) {
          // Display waiting indicator instead
          this.$store.dispatch('waiting_show');
          this.$store.commit('waiting_setMessage', 'Getting the 3D model ready ...');
        }
        setTimeout(() => {
          this.start = true;
          this.intervalHandle = setInterval(this.updateAnimation, 1000);
        }, 500);
      },
      methods: {
        updateAnimation() {
          this.step = this.nextStep;

          const kbDesignerLoaded = this.designerLoaded();
          const kbLockerRoomLoaded = this.lockerRoomLoaded();

          if (kbLockerRoomLoaded) {
            this.hideAnimation(false);
          } else if (kbDesignerLoaded && this.loadCount >= 1) {
            this.hideAnimation(true);
          } else if (this.step >= this.frames.length && kbDesignerLoaded) {
            this.hideAnimation(true);
          }

          if (this.step > 0 && this.step < this.frames.length + 1) {
           // this.logoPattern.classList.remove(this.frames[this.step - 1].class);
          }
          if (this.step < this.frames.length) {
           // this.logoPattern.classList.add(this.frames[this.step].class);
          }
          this.nextStep++;
        },
        hideAnimation(showToolbars) {
          clearInterval(this.intervalHandle);
          this.fadeOut = true;

          // Fade in KitBuilder
          const kb = document.getElementById('kitBuilder');
          kb.setAttribute('style', 'opacity: 1');

         // this.logoPattern.classList.remove(...this.logoPattern.classList);

          this.$store.dispatch('waiting_hide');
          // Remove from the dom after 1 second
          setTimeout(
            () => {
              this.$store.dispatch('splash_hide');
              if (showToolbars) {
                this.$store.dispatch('toolbars_show');
              }
            },
            500
          );
        },
        designerLoaded() {
          const wrapper = document.querySelector('.kb-vector-wrapper');
          if (wrapper) {
            const isLoading = wrapper.classList.contains('kb-loading');
            if (!isLoading) {
              return true;
            }
          }
          return false;
        },
        lockerRoomLoaded() {
          const lockerRoom = document.querySelector('.kb-locker-room-wrapper, .kb-page-folder');
          if (lockerRoom) {
              return true;
          }
          return false;
        }
      },
      computed: {
        isVisible() {
          return this.$store.getters.splashIsVisible;
        },
        previouslyLoaded() {
          return this.$store.getters.splashPreviouslyLoaded;
        },
        loadCount() {
          return this.$store.getters.splashloadCount;
        }
      },
      template: `
        <div
          id="sySplash"
          class="splash-container"
          v-if="isVisible"
          :class="[{ 'splash-fade-out': fadeOut }]"
          v-show="loadCount < 2"        
        >
          <div :class="['splash-animation', { 'splash-animate': start }]">
            <div :class="['splash-shirt', { 'splash-bg-stripes': step == 0}, { 'splash-bg-polka-dots': step == 1}, { 'splash-bg-arches': step == 2}, { 'splash-bg-butterflies': step == 3 }, { 'splash-bg-paisley': step >= 4 } ]">
            </div>
            <svg viewBox="0 0 210 297" x="0px" y="0px">
              <clipPath id="splashClipPath" clipPathUnits="objectBoundingBox" transform="scale(0.0033670, 0.0047619)">
                <path 
                  fill="#000000" stroke-width="0.593345"
                  d="m 86.585264,288.00601 c -6.719296,-0.99306 -9.083892,-1.31525 -18.758051,-2.55586 -12.610324,-1.61713 -17.034344,-3.25908 -20.408811,-7.57461 -1.55306,-1.98617 -1.777454,-2.67028 -1.507331,-4.59541 0.174552,-1.24402 0.583244,-10.60839 0.908204,-20.80971 0.324959,-10.20133 0.995852,-25.90413 1.490874,-34.89513 1.158591,-21.04331 1.160704,-29.82638 0.01089,-45.26936 -0.514945,-6.91615 -1.181597,-20.77989 -1.481448,-30.80831 -0.878783,-29.39059 -1.88829,-42.440018 -3.283171,-42.440018 -0.212528,0 -0.832355,1.909798 -1.377394,4.243998 -0.545039,2.3342 -1.782187,6.17187 -2.749217,8.52816 -1.973737,4.80925 -1.804784,4.75659 -7.438874,2.31869 -1.53984,-0.6663 -4.941487,-1.80801 -7.559215,-2.53714 -5.756095,-1.60326 -14.072045,-5.90184 -16.9977395,-8.78626 -2.52018,-2.48462 -2.5105,-2.72051 0.46187,-11.261788 1.979906,-5.68939 2.7343305,-10.13452 3.3945615,-20.001013 0.285655,-4.268825 1.316249,-10.248312 3.328985,-19.314715 0.149736,-0.674489 0.637113,-2.089713 1.083059,-3.144943 0.445947,-1.05523 1.343443,-3.31385 1.994436,-5.019155 2.129466,-5.578237 8.833493,-14.816088 10.752224,-14.816088 0.221423,0 4.1326,-1.94513 8.691505,-4.32251 4.558905,-2.37738 11.046929,-5.223669 14.417831,-6.325086 3.370903,-1.101417 9.613571,-3.683224 13.872589,-5.737348 4.259024,-2.054123 7.994967,-3.7347701 8.302101,-3.7347701 0.307134,0 1.720567,-1.202467 3.140966,-2.672149 l 2.582542,-2.67215 17.982812,0.0838 c 9.890548,0.04609 21.741618,0.280298 26.335728,0.520461 l 8.35291,0.436659 1.72604,2.132889 c 2.11358,2.611788 15.81534,9.3904171 24.10951,11.9276311 5.28152,1.615635 10.15027,3.916726 20.64691,9.758244 5.88656,3.275947 8.6941,6.465998 11.99317,13.627145 4.01228,8.709274 6.34039,18.838482 7.41158,32.246538 0.71359,8.932 1.30854,12.12255 3.13859,16.83162 0.70828,1.82253 1.71674,5.03036 2.24103,7.1285 l 0.95326,3.814808 -1.62741,1.53117 c -4.30269,4.04825 -14.46796,8.49465 -22.16413,9.69483 -2.56336,0.39974 -5.74098,0.95136 -7.06138,1.22582 -2.35989,0.49053 -2.4181,0.46013 -3.4223,-1.78756 -0.56186,-1.25762 -1.71759,-4.69152 -2.5683,-7.63088 -0.8507,-2.93936 -1.74801,-5.591298 -1.99402,-5.893198 -1.34323,-1.64831 -2.719,14.630628 -2.86262,33.872178 -0.13521,18.11478 -1.27039,38.89282 -3.07436,56.27232 -0.9752,9.3951 -0.8473,14.23388 0.89742,33.95202 0.59666,6.74325 1.25517,17.77765 1.46336,24.5209 0.20819,6.74325 0.53943,15.45295 0.7361,19.3549 0.47542,9.43239 -0.0524,10.85115 -5.10766,13.72971 -4.16329,2.37064 -9.03132,3.33907 -21.84531,4.34582 -6.5429,0.51405 -15.48485,1.49784 -19.87101,2.18619 -9.1097,1.42965 -20.882684,1.55847 -29.261306,0.32016 z"                  id="path847" 
                />
              </clipPath>
            </svg>
          </div>
          <span :style="{ 'color': frames[step <=4 ? step : 4].color }" class="splash-text">
              {{ frames[step <=4 ? step : 4].text }}
          </span>
        </div>
      `
    }
  });
})(sy);
