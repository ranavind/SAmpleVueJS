((sy) => {
  sy.stateModules.push({
    name: 'responsive',
    module: {
      state: () => ({
        width: 0,
        height: 0,
        device: 4 // 'desktop'
      }),
      mutations: {
        responsive_setResolution(state, { height, width }) {
          state.height = height;
          state.width = width;

          if (width > 1367) {
            state.device = 4; //; 'desktop-wide'
          } else if (width > 1024) {
            state.device = 3; //  'desktop'
          } else if (width > 768) {
            state.device = 2; // 'tablet'
          } else {
            state.device = 1; // 'mobile'
          }
        },
      },
      actions: { 
      },
      getters: {
        responsive_getDevice: state => state.device,
      }
    }
  });
})(sy);

