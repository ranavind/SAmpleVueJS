((sy) => {
  sy.components.push({
    element: 'sy-message-dialog',
    component: {
      data() {
        return {}
      },
      computed: {
        isVisible() {
          return this.$store.getters.messageDialogIsVisible;
        },
        message() {
          return this.$store.getters.messageDialogMessage;
        },
        title() {
          return this.$store.getters.messageDialogTitle;
        },
        dialogType() {
          const dialogType = this.$store.getters.messageDialogType === 1 ? "info" : this.$store.getters.messageDialogType === 2 ? "warning" : "error";
          return dialogType;
        }
      },
      methods: {
        onOk() {
          this.$store.commit('messageDialog_hide');
        },
        onClose() {
          this.$store.commit('messageDialog_hide');
        }
      },
      template: `
        <div 
          id="syMessageDialog" 
          class="sy-message-dialog"
          v-if="isVisible"
        >
          <div class="sy-message-container">
            <header :class="[dialogType]">
              <label>
                {{ title }}
              </label>
              <button type="button" class="close" @click="onClose()">
                <i class="fas fa-times"></i>
              </button>
            </header>
            <main>
              <label>
                {{ message }}
              </label>
            </main>
            <footer>
              <button type="button" class="close" @click="onOk()"> Ok </button>
            </footer>
          </div>
        </div>
      `
    }
  });
})(sy);
