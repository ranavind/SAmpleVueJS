var sy = sy || { components: [], stateModules: [] };
((sy) => {
  sy.components.push({
    element: 'sy-checkout',
    component: {
      computed: {
        checkoutVisible() {
          return this.$store.getters.checkout_Visible;
        },
        grandSubtotal() {
          return this.$store.getters.checkout_grandSubtotal;
        },
        missingQuantity() {
          return this.$store.getters.checkout_missingQuantity;
        },
        lineItems() {
          return this.$store.getters.checkout_items;
        },
        sizes() {
          return this.$store.getters.checkout_sizes;
        },
        materials() {
          return this.$store.getters.checkout_materials;
        },
        hasMaterials() {
          return this.$store.getters.checkout_hasMaterials;
        },
        isMobile() {
          return this.$store.getters.responsive_getDevice == 1;
        }
      },
      methods: {
        subTotal(item) {
          return `${(item.price * item.qty).toFixed(2)}`;
        },
        onDeleteItem(removeItem) {
          this.$store.dispatch('checkout_removeRow', removeItem);
        },
        onAddItem() {
          this.$store.dispatch('checkout_addRow');
        },
        onCloseCheckout() {
          this.$store.dispatch('checkoutHide');
        },
        onCheckout() {
          let button = angular.element(document.querySelector('.kb-button-single-item-checkout-buy-now'));
          button.triggerHandler('click');
          this.$store.dispatch('waiting_show');
          this.$store.commit('waiting_setMessage', 'Please wait while we prepare the patterns for your custom order.');
        },
        onSizeChange(size, item) {
          this.$store.dispatch('checkout_itemSizeChange', { item, size });
        },
        onMaterialChange(material, item) {
          this.$store.dispatch('checkout_itemMaterialChange', { item, material });
        },
        onQuantityChanged(quantity, item) {
          this.$store.dispatch('checkout_itemQuantityChanged', { item, quantity });
        },
      },
      beforeMount() {
        this.$bus.on('product_loaded', data => {
          this.$store.dispatch('checkout_getSizesFromKb');
        });
      },
      template: `
        <div
          class="size-checkout-container"
          v-if="checkoutVisible"
        >
        <div id="sizeCheckout" class="size-checkout">

          <div class="size-checkout-title">
            Select quantity and sizes
  
            <button type="button" id="closeCheckout" class="close-checkout" @click="onCloseCheckout()">
              <i class="fas fa-times" />
            </button>
          </div>
  
          <table class="size-checkout-table">
            <thead>
              <tr>
                <td class="label material">
                  <span v-if="hasMaterials">material:</span>
                  <div v-else class="material"></div></td>
                <td class="label">size:</td>
                <td class="label" v-if="isMobile">qty:</td>
                <td class="label" v-else>quantity:</td>
                <td class="garment-subtotal">price:</td>
                <td class="garment-remove"></td>
              </tr>
            </thead>
            <tbody>
              <tr class="checkout-row" v-for="item in lineItems" :key="item.id">
                <td class="material">
                  <sy-material-picker
                    v-if="hasMaterials"
                    class="material"
                    :value="item.material"
                    :materials="materials"
                    @changed="onMaterialChange($event, item)"
                  ></sy-material-picker>
                </td>
                <td class="size">
                  <sy-size-picker
                    class="size"
                    :value="item.size"
                    :sizes="sizes"
                    @changed="onSizeChange($event, item)"
                  ></sy-size-picker>
                </td>
                <td class="value">
                  <input 
                    type="number" maxlength="4" min="0" max="9999" step="1" 
                    :value="item.qty"
                    @input="onQuantityChanged($event.target.value, item)" />
                </td>
                <td class="garment-subtotal">
                  $ {{ subTotal(item) }}
                </td>
                <td class="garment-remove">
                  <button type="button" @click="onDeleteItem(item)"><i class="fas fa-times" /></button>
                </td>
              </tr>
            </tbody>  
            <tfoot class="checkout-footer">
              <tr>
                <td colspan="3" style="text-align: right; padding: 5px 20px; vertical-align: top;">
                  <button type="button" class="add-button" id="addSizeButton" @click="onAddItem()" style="float: left;">
                    add size <i class="fas fa-plus" />
                  </button>
                  <span class="total-label">subtotal</span>
                </td>
                <td colspan="2" class="total-container" style="text-align: left; ">
                  <div class="total-value">$ {{ grandSubtotal }}</div>
                  <div class="shipping-message">+ plus tax and shipping</div>
                </td>
              </tr>
            </tfoot>
          </table>

          <div class="checkout-buttons">
            <button type="button" class="checkout-button" @click="onCheckout()" :disabled="missingQuantity || lineItems.length === 0">check out</button>
          </div>
        </div>
      </div>
      `
    }
  });
})(sy);

((sy) => {
  sy.components.push({
    element: 'sy-material-picker',
    component: {
      id: 'MaterialPicker',
      props: ['value', 'materials'],
      data() {
        return {
          dropdownVisible: false
        }
      },
      methods: {
        onSelect(item) {
          this.$emit('changed', item.name);
          this.toggleDropdown();
        },
        toggleDropdown(e) {
          this.dropdownVisible = !this.dropdownVisible;
        }
      },
      template: `
        <div class="drop-down-button-container">
          <div @click="toggleDropdown($event)" class="drop-down-button">
            <span>
              {{ value }}
            </span>
          </div>
          <div v-if="dropdownVisible" class="dropdown">
            <ul>
              <li
                v-for="material in materials" 
                :key="material.name" 
                :class="[{ 'selected': material.name == value }]"
                @click="onSelect(material)"
              >
                {{ material.name }}
              </li>
            </ul>
          </div>
        </div>
      `
    }
  });
})(sy);
((sy) => {
  sy.components.push({
    element: 'sy-size-picker',
    component: {
      id: 'SizePicker',
      props: ['value', 'sizes'],
      data() {
        return {
          dropdownVisible: true
        }
      },
      methods: {
        onSelect(item) {
          this.$emit('changed', item.name);
          this.toggleDropdown();
        },
        toggleDropdown(e) {
          this.dropdownVisible = !this.dropdownVisible;
        }
      },
      template: `
        <div class="drop-down-button-container">
          <div @click="toggleDropdown($event)" class="drop-down-button">
            <span>
              {{ value }}
            </span>
          </div>
          <div v-if="dropdownVisible" class="dropdown">
            <ul>
              <li
                v-for="size in sizes" 
                :key="size.id" 
                :class="[{ 'selected': size.name == value }]"
                @click="onSelect(size)"
              >
                {{ size.name }}
              </li>
            </ul>
          </div>
        </div>
      `
    }
  });
})(sy);
((sy) => {
  sy.components.push({
    element: 'sy-message-dialog',
    component: {
      data() {
        return {}
      },
      computed: {
        isVisible() {
          return this.$store.getters.messageDialogIsVisible;
        },
        message() {
          return this.$store.getters.messageDialogMessage;
        },
        title() {
          return this.$store.getters.messageDialogTitle;
        },
        dialogType() {
          const dialogType = this.$store.getters.messageDialogType === 1 ? "info" : this.$store.getters.messageDialogType === 2 ? "warning" : "error";
          return dialogType;
        }
      },
      methods: {
        onOk() {
          this.$store.commit('messageDialog_hide');
        },
        onClose() {
          this.$store.commit('messageDialog_hide');
        }
      },
      template: `
        <div 
          id="syMessageDialog" 
          class="sy-message-dialog"
          v-if="isVisible"
        >
          <div class="sy-message-container">
            <header :class="[dialogType]">
              <label>
                {{ title }}
              </label>
              <button type="button" class="close" @click="onClose()">
                <i class="fas fa-times"></i>
              </button>
            </header>
            <main>
              <label>
                {{ message }}
              </label>
            </main>
            <footer>
              <button type="button" class="close" @click="onOk()"> Ok </button>
            </footer>
          </div>
        </div>
      `
    }
  });
})(sy);

((sy) => {
  sy.components.push({
    element: 'sy-splash',
    component: {
      data() {
        return {
          start: false,
          fadeOut: false,
          step: 0,
          intervalHandle: null,
          frames: [
            { text: 'Hold on to your shirts ...', color: 'black', class: 'splash-bg-stripes' },
            { text: 'Getting our Shirt together', color: 'darkred', class: 'splash-bg-polka-dots' },
            { text: 'The shirt is hitting the fan', color: 'darkblue', class: 'splash-bg-arches' },
            { text: 'Holy shirt!', color: 'darkgreen', class: 'splash-bg-butterflies' },
            { text: 'Shirt Yourself!', color: 'black', class: 'splash-bg-paisley' },
          ],
          logoPattern: null,
          nextStep: 0
        }
      },
      beforeMount() {
        this.$store.dispatch('splash_rehydrateState');
      },
      mounted() {
        this.logoPattern = document.getElementById('logoPattern');
        this.updateAnimation();
        if (this.loadCount > 1) {
          // Display waiting indicator instead
          this.$store.dispatch('waiting_show');
          this.$store.commit('waiting_setMessage', 'Getting the 3D model ready ...');
        }
        setTimeout(() => {
          this.start = true;
          this.intervalHandle = setInterval(this.updateAnimation, 1000);
        }, 500);
      },
      methods: {
        updateAnimation() {
          this.step = this.nextStep;

          const kbDesignerLoaded = this.designerLoaded();
          const kbLockerRoomLoaded = this.lockerRoomLoaded();

          if (kbLockerRoomLoaded) {
            this.hideAnimation(false);
          } else if (kbDesignerLoaded && this.loadCount >= 1) {
            this.hideAnimation(true);
          } else if (this.step >= this.frames.length && kbDesignerLoaded) {
            this.hideAnimation(true);
          }

          if (this.step > 0 && this.step < this.frames.length + 1) {
           // this.logoPattern.classList.remove(this.frames[this.step - 1].class);
          }
          if (this.step < this.frames.length) {
           // this.logoPattern.classList.add(this.frames[this.step].class);
          }
          this.nextStep++;
        },
        hideAnimation(showToolbars) {
          clearInterval(this.intervalHandle);
          this.fadeOut = true;

          // Fade in KitBuilder
          const kb = document.getElementById('kitBuilder');
          kb.setAttribute('style', 'opacity: 1');

         // this.logoPattern.classList.remove(...this.logoPattern.classList);

          this.$store.dispatch('waiting_hide');
          // Remove from the dom after 1 second
          setTimeout(
            () => {
              this.$store.dispatch('splash_hide');
              if (showToolbars) {
                this.$store.dispatch('toolbars_show');
              }
            },
            500
          );
        },
        designerLoaded() {
          const wrapper = document.querySelector('.kb-vector-wrapper');
          if (wrapper) {
            const isLoading = wrapper.classList.contains('kb-loading');
            if (!isLoading) {
              return true;
            }
          }
          return false;
        },
        lockerRoomLoaded() {
          const lockerRoom = document.querySelector('.kb-locker-room-wrapper, .kb-page-folder');
          if (lockerRoom) {
              return true;
          }
          return false;
        }
      },
      computed: {
        isVisible() {
          return this.$store.getters.splashIsVisible;
        },
        previouslyLoaded() {
          return this.$store.getters.splashPreviouslyLoaded;
        },
        loadCount() {
          return this.$store.getters.splashloadCount;
        }
      },
      template: `
        <div
          id="sySplash"
          class="splash-container"
          v-if="isVisible"
          :class="[{ 'splash-fade-out': fadeOut }]"
          v-show="loadCount < 2"        
        >
          <div :class="['splash-animation', { 'splash-animate': start }]">
            <div :class="['splash-shirt', { 'splash-bg-stripes': step == 0}, { 'splash-bg-polka-dots': step == 1}, { 'splash-bg-arches': step == 2}, { 'splash-bg-butterflies': step == 3 }, { 'splash-bg-paisley': step >= 4 } ]">
            </div>
            <svg viewBox="0 0 210 297" x="0px" y="0px">
              <clipPath id="splashClipPath" clipPathUnits="objectBoundingBox" transform="scale(0.0033670, 0.0047619)">
                <path 
                  fill="#000000" stroke-width="0.593345"
                  d="m 86.585264,288.00601 c -6.719296,-0.99306 -9.083892,-1.31525 -18.758051,-2.55586 -12.610324,-1.61713 -17.034344,-3.25908 -20.408811,-7.57461 -1.55306,-1.98617 -1.777454,-2.67028 -1.507331,-4.59541 0.174552,-1.24402 0.583244,-10.60839 0.908204,-20.80971 0.324959,-10.20133 0.995852,-25.90413 1.490874,-34.89513 1.158591,-21.04331 1.160704,-29.82638 0.01089,-45.26936 -0.514945,-6.91615 -1.181597,-20.77989 -1.481448,-30.80831 -0.878783,-29.39059 -1.88829,-42.440018 -3.283171,-42.440018 -0.212528,0 -0.832355,1.909798 -1.377394,4.243998 -0.545039,2.3342 -1.782187,6.17187 -2.749217,8.52816 -1.973737,4.80925 -1.804784,4.75659 -7.438874,2.31869 -1.53984,-0.6663 -4.941487,-1.80801 -7.559215,-2.53714 -5.756095,-1.60326 -14.072045,-5.90184 -16.9977395,-8.78626 -2.52018,-2.48462 -2.5105,-2.72051 0.46187,-11.261788 1.979906,-5.68939 2.7343305,-10.13452 3.3945615,-20.001013 0.285655,-4.268825 1.316249,-10.248312 3.328985,-19.314715 0.149736,-0.674489 0.637113,-2.089713 1.083059,-3.144943 0.445947,-1.05523 1.343443,-3.31385 1.994436,-5.019155 2.129466,-5.578237 8.833493,-14.816088 10.752224,-14.816088 0.221423,0 4.1326,-1.94513 8.691505,-4.32251 4.558905,-2.37738 11.046929,-5.223669 14.417831,-6.325086 3.370903,-1.101417 9.613571,-3.683224 13.872589,-5.737348 4.259024,-2.054123 7.994967,-3.7347701 8.302101,-3.7347701 0.307134,0 1.720567,-1.202467 3.140966,-2.672149 l 2.582542,-2.67215 17.982812,0.0838 c 9.890548,0.04609 21.741618,0.280298 26.335728,0.520461 l 8.35291,0.436659 1.72604,2.132889 c 2.11358,2.611788 15.81534,9.3904171 24.10951,11.9276311 5.28152,1.615635 10.15027,3.916726 20.64691,9.758244 5.88656,3.275947 8.6941,6.465998 11.99317,13.627145 4.01228,8.709274 6.34039,18.838482 7.41158,32.246538 0.71359,8.932 1.30854,12.12255 3.13859,16.83162 0.70828,1.82253 1.71674,5.03036 2.24103,7.1285 l 0.95326,3.814808 -1.62741,1.53117 c -4.30269,4.04825 -14.46796,8.49465 -22.16413,9.69483 -2.56336,0.39974 -5.74098,0.95136 -7.06138,1.22582 -2.35989,0.49053 -2.4181,0.46013 -3.4223,-1.78756 -0.56186,-1.25762 -1.71759,-4.69152 -2.5683,-7.63088 -0.8507,-2.93936 -1.74801,-5.591298 -1.99402,-5.893198 -1.34323,-1.64831 -2.719,14.630628 -2.86262,33.872178 -0.13521,18.11478 -1.27039,38.89282 -3.07436,56.27232 -0.9752,9.3951 -0.8473,14.23388 0.89742,33.95202 0.59666,6.74325 1.25517,17.77765 1.46336,24.5209 0.20819,6.74325 0.53943,15.45295 0.7361,19.3549 0.47542,9.43239 -0.0524,10.85115 -5.10766,13.72971 -4.16329,2.37064 -9.03132,3.33907 -21.84531,4.34582 -6.5429,0.51405 -15.48485,1.49784 -19.87101,2.18619 -9.1097,1.42965 -20.882684,1.55847 -29.261306,0.32016 z"                  id="path847" 
                />
              </clipPath>
            </svg>
          </div>
          <span :style="{ 'color': frames[step <=4 ? step : 4].color }" class="splash-text">
              {{ frames[step <=4 ? step : 4].text }}
          </span>
        </div>
      `
    }
  });
})(sy);

((sy) => {
  sy.components.push({
    element: "sy-url-watcher",
    component: {
      name: "urlWatcher",
      data() {
        return {
          oldHash: "",
          oldProductId: "",
          resizedSmaller: false,
          interval: null,
          mobileMenuLinks: null,
          skipMenuFirstClick: false
        };
      },
      mounted() {
        window.addEventListener("hashchange", (e) => this.urlChanged(e));
        this.urlChanged(null);

        window.addEventListener("resize", this.resized);
        this.interval = setInterval(() => {
          const panels = document.querySelectorAll(".kb-wrapper .kb-customise-page .kb-preview-panel, .kb-locker-room-wrapper");
          console.log('Waiting for KB to load. resized width', window.innerWidth);
          if (panels.length > 0) {
            this.resized();
            clearInterval(this.interval);
            this.interval = null;
          }
        }, 1000);

        document.getElementById("syMobileMenu")
          .addEventListener("click", () => this.toggleMobileMenu());
        this.mobileMenuLinks = document.querySelector(".header-links");

        // Reset ReturnUrl for login/register links
        const registerLink = document.getElementById('headerRegisterLink');
        if (registerLink) {
          registerLink.href = registerLink.href + encodeURI(window.location.hash);
        }
        const loginLink = document.getElementById('headerLoginLink')
        if (loginLink) {
          loginLink.href = loginLink.href + encodeURI(window.location.hash);
        }
      },
      beforeUnmount() {
        window.removeEventListener("hashchange", this.urlChanged);
        if (this.interval) { clearInterval(this.interval); }
      },
      methods: {
        toggleMobileMenu() {
          if (this.mobileMenuLinks.classList.contains("visible")) {
            this.hideMobileMenu();            
          } else {
            this.showMobileMenu();
          }
        },
        showMobileMenu() {
          window.addEventListener('click', this.hideMobileMenu);
          this.mobileMenuLinks.classList.add("visible");
          console.log('add event');
          this.skipMenuFirstClick = true;
        },
        hideMobileMenu() {
          if (this.skipMenuFirstClick) {
            this.skipMenuFirstClick = false;
            console.log('skipped');
            return;
          }
          this.mobileMenuLinks.classList.remove("visible");
          window.removeEventListener('click', this.hideMobileMenu);
          console.log('remove event');
        },

        resized() {

          // Update resolution in state
          this.$store.commit('responsive_setResolution', { width: window.innerWidth, height: window.innerHeight });

          // *** Hack for Mobile browsers to get actual screen height without the built in url bar
          // First we get the viewport height and we multiple it by 1% to get a value for a vh unit
          // let vh = window.innerHeight * 0.01;

          // Then we set the value in the --vh custom property to the root of the document
          // document.documentElement.style.setProperty('--vh', `${vh}px`);

          const forEach = function (array, callback, scope) {
            for (var i = 0; i < array.length; i++) {
              callback.call(scope, i, array[i]); // passes back stuff we need
            }
          };
          // *** end ofhack

          const panels = document.querySelectorAll(
            ".kb-wrapper .kb-customise-page .kb-preview-panel"
          );
          const image = document.querySelectorAll(
            ".kb-wrapper .kb-customise-page .kb-3d-wrapper"
          );

          if (window.innerWidth < 760 || window.innerHeight < 770) {
            if (this.resizedSmaller) return;

            console.log("scale smaller");
            forEach(panels, (index, x) => {
              x.setAttribute("style", "width: 100% !important");
            });

            let height = 500;

            if (window.innerWidth > 750 && window.innerHeight < 1025 ) {
              height = 650;
            }

            forEach(image, (index, x) => {
              x.setAttribute(
                "style",
                `width: 100% !important; height: ${ height }px !important;`
              );
            });
            this.resizedSmaller = true;
          } else {
            if (!this.resizedSmaller) return;
            console.log("scale bigger");
            forEach(panels, (index, x) => {
              x.removeAttribute("style");
            });

            forEach(image, (index, x) => {
              x.removeAttribute("style");
            });

            this.resizedSmaller = false;
          }

          let kbMobileNav = document.querySelector(".kb-customize-mobile-nav");
          kbMobileNav.setAttribute("style", "display: none !important");
        },
        urlChanged(e) {
          console.log('url changed', window.location.hash);
          if (this.oldHash == window.location.hash) {
            return;
          }

          if (window.location.hash.indexOf('custom') > -1) { 
            this.$store.dispatch('product_refreshProduct');
            this.$store.commit('toolbar_ClearSelectedTool');
          }
          this.oldHash = window.location.hash;

          // Show/Hide Toolbars depending on view
          let fragment = window.location.hash.toString();
          if (fragment.toLowerCase().indexOf('custom') > -1) {
            this.$store.dispatch('toolbars_show');
          } else if (window.location.hash.indexOf('locker') > -1) {
            this.$store.dispatch('toolbars_hide');
          } else {
            window.location.hash = yba.homeProducts[0].RendererUrl;
          }
        },
      },
      template: `
        <div></div>
      `,
    },
  });
})(sy);

((sy) => {
  sy.components.push({
    element: 'sy-waiting',
    component: {
      computed: {
        isVisible() {
          return this.$store.getters.waitingIsVisible;
        },
        message() {
          return this.$store.getters.waitingMessage;
        }
      },
      template: `
        <div 
          id="syWaitingIndicator"
          class="waiting-overlay"
          v-if="isVisible"
        >
          <div class="waiting-message">
            {{ message }}
          </div>
          <div class="waiting-animation">
            <i class="waiting-t-shirt fas fa-tshirt fa-10x"></i>
            <i class="waiting-gear fas fa-cog fa-spin fa-5x gear"></i>        
          </div>
        </div>
      `
    }
  });
})(sy);


((sy) => {
  sy.components.push({
    id: "imageSearchDialog",
    element: "sy-image-dialog",
    component: {
      name: "imageSearchDialog",
      data() {
        return { };
      },
      computed: {
        isVisible() {
          return this.$store.getters.imageDialog_IsVisible;
        },
        selectedTab() {
          return this.$store.getters.imageDialog_selectedTab;
        }
      },
      methods: {
        onClose() {
          this.$store.commit("imageDialog_ToggleVisibility", false);
        },
        onModalClick(event) {
          event.cancelBubble = true;
          event.preventDefault();
        },
        onSelectTab(tab) {
          this.activeTab = tab;
          this.scrollTop();
        },
        scrollTop() {
          window.scrollTo(0, 0);
          document.body.scrollTop = 0;
        }
      },
      template: `
        <div id="imageDialog" class="sy-modal" :style="{ 'display': isVisible ? 'block' : 'none' }">
          <div class="sy-modal-container">
          <!-- @click="onModalClick($event)" -->
            <div class="sy-modal-title">
              IMAGE CHOOSER
            </div>
            <div class="sy-modal-header">
              <span class="sy-modal-close" @click="onClose()">
                <i class="fas fa-times"></i>
              </span>
            </div>
            <div class="sy-modal-tabs">
              <ul>
                <li :class="{ 'active': selectedTab === 1 }" @click="$store.commit('imageDialog_SetSelectedTab', 1)">Image Library</li>
                <li :class="{ 'active': selectedTab === 2 }" @click="$store.commit('imageDialog_SetSelectedTab', 2)">Upload Image</li>
                <li :class="{ 'active': selectedTab === 3 }" @click="$store.commit('imageDialog_SetSelectedTab', 3)">My Images</li>
              </ul>
            </div>
            <div class="sy-modal-body">
              <sy-image-search-results v-if="selectedTab === 1"></sy-image-search-results>
              <sy-image-upload v-if="selectedTab === 2"></sy-image-upload>
              <sy-image-my-files v-if="selectedTab === 3"></sy-image-my-files>
            </div>
          </div>
        </div>
      `,
    },
  });
})(sy);

((sy) => {
  sy.components.push({
    id: "imageMyFiles",
    element: "sy-image-my-files",
    component: {
      name: "imageMyFiles",
      data() {
        return {
          images: [],
          distributionId: "",
          selectedImage: {},
          selectedImageSrc: "",
          isPreviewVisible: false,
          showPlacements: false,
        };
      },
      computed: {
        imagePlacementOptions() {
          return this.$store.getters.imageDialog_PlacementOptions;
        },
      },
      methods: {
        refreshImages() {
          const kbPlacementElement = document.querySelector(
            ".kb-editor-placement-image"
          );
          if (kbPlacementElement) {
            const scope = angular.element(kbPlacementElement).scope();
            this.images = Array
              .from(new Set(scope.imageLibrary.images.map(x => x.thumbnailImageId)))
              .map(id => scope.imageLibrary.images.find(item => item.thumbnailImageId == id));
              
              // scope.imageLibrary.images
              // .filter(x => x.thumbnailImageId && x.thumbnailImageId > 0)
              // .filter((x, i, a) => a.indexOf(x) == i)
          }
        },
        onImageSelected(placementKey) {
          this.isPreviewVisible = false;
          this.showPlacements = false;
          this.$store.dispatch("placeImageOnGarment", {
            placementKey: placementKey,
            fileData: {
              id: this.selectedImage.thumbnailImageId,
              isBitmap: this.selectedImage.isBitmap,
              bitmapWidth: this.selectedImage.originalWidth,
              bitmapHeight: this.selectedImage.originalHeight,
            },
          });
          this.$store.commit("imageDialog_ToggleVisibility", false);
        },
        onPreview(image) {
          this.selectedImage = image;
          this.selectedImageSrc = `https://api.kitbuilder.co.uk/Api/file/${this.selectedImage.thumbnailImageId}/?width=500&height=500&${this.distributionId}`;
          this.isPreviewVisible = true;
        },
        onCancel() {
          this.isPreviewVisible = false;
          this.showPlacements = false;
        },
        onPlaceImageClicked() {
          this.showPlacements = !this.showPlacements;
        },
      },
      mounted() {
        this.distributionId = yba.kitBuilder.distributionId;
        this.refreshImages();
      },
      template: `
        <div class="image-my-files-tab">
          <div class="my-images-content" v-if="!isPreviewVisible">
            <ul class="image-list" v-if="images.length > 0">
              <li v-for="image in images" :key="image.thumbnailImageId" @click="onPreview(image)">
                <i class="fas fa-cog fa-spin fa-3x" style="opacity: .5"></i>
                <img :src="'https://api.kitbuilder.co.uk/Api/file/' + image.thumbnailImageId + '/?width=175&height=172&' + distributionId" />
              </li>
            </ul>
            <span v-else class="no-files">
              No images have been previously selected or uploaded.  Use the Image Library to select from the Shirt Yourself image library or the "Upload" to use your own photos.
            </span>
          </div>
          <div v-else class="preview-container">
            <div class="image-container" style="vertical-align: center">
              <img :src="selectedImageSrc" />
            </div>
            <div class="preview-buttons">
              <button type="button" class="discard-btn" @click="onCancel()">Cancel</button>

              &nbsp;&nbsp;&nbsp;
              
              <div class="dropdown">
                <button @click="onPlaceImageClicked()" class="dropdown-btn">Place Image</button>
                <div class="dropup-content" :class="{ 'show': showPlacements }">
                  <ul class="dropdown-list">
                    <li v-for="p in imagePlacementOptions" @click="onImageSelected(p.placementKey)">{{ p.name }}</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>        
        </div>
      `,
    },
  });
})(sy);

(sy => {
  sy.components.push({
    id: 'imagePreview',
    element: 'sy-image-preview',
    component: {
      name: 'imagePreview',
      data() {
        return {
        }
      },
      computed: {
      },
      methods: {
      },
      template: `
        <div> 
          <div>
            Preview Image here
            <img />
          </div>
          <div>
            <button type="button">Cancel</button>
            <button type="button">Use</button>
          </div>
        </div>
      `
    }
  });
})(sy);
((sy) => {
  sy.components.push({
    id: "imageSearchFilter",
    element: "sy-image-search-filter",
    component: {
      name: "imageSearchFilter",
      data() {
        return {};
      },
      computed: {
        isExpanded() {
          return this.$store.getters.imageDialog_SearchIsExpanded;
        },
        searchQuery: {
          get() {
            return this.$store.getters.imageDialog_SearchQuery;
          },
          set(value) {
            this.$store.commit("imageDialog_UpdateSearchQuery", value);
          },
        },
        imageType: {
          get() {
            return this.$store.getters.imageDialog_SearchImageType;
          },
          set(value) {
            this.$store.commit("imageDialog_UpdateSearchImageType", value);
          },
        },
      },
      methods: {
        onSearch(e) {
          e.preventDefault();
          e.stopPropagation();
          // this.pager.currentPage = 1;

          this.$store.dispatch("imageSearch_executeSearch");
          this.scrollTop();
        },
        upateImageType(value) {
          this.$store.commit("imageDialog_UpdateSearchImageType", value);
        },
        onExpand() {
          this.$store.commit(
            "imageDialog_ToggleSearchExpanded",
            !this.isExpanded
          );
        },
        scrollTop() {
          window.scrollTo(0, 0);
          document.body.scrollTop = 0;
        }
      },
      template: `
        <div class="search-filter-container" :class="{ expanded: isExpanded }">
          <div class="search-filter-title">
            <span v-if="isExpanded">
              Search Filters
            </span>
            <button @click="onExpand()">
              <i v-if="isExpanded" class="fas fa-times fa-lg"></i>
              <i v-else class="fas fa-search fa-lg"></i>
            </button>
          </div>
          <form class="search-filter-criteria" v-if="isExpanded">
            <dl>
              <dt><label>Search:</label></dt>
              <dd><input type="text" v-model="searchQuery" placeholder="keywords" maxlength="200" @blur="scrollTop()" /></dd>

              <dt><label>Image Type:</label></dt>
              <dd>
                <select v-model="imageType">
                  <option value="all">All</option>
                  <option value="vector">Illustration</option>
                  <option value="photo">Photo</option>
                </select>
              </dd>
            </dl>
            <button class="search-btn" type="submit" @click="onSearch($event)" :disabled="!searchQuery">
              Search Library
            </button>
          </form>
        </div>
      `,
    },
  });
})(sy);

((sy) => {
  sy.components.push({
    id: "imageSearchPager",
    element: "sy-search-pager",
    component: {
      name: "imageSearchPager",
      data() {
        return {};
      },
      computed: {
        pager() {
          return this.$store.getters.imageDialog_SearchPager;
        }
      },
      methods: {
        onPreviousPage() {
          this.$store.dispatch('imageDialog_PreviousPage');
        },
        onNextPage() {
          this.$store.dispatch('imageDialog_NextPage');
        },
        executeSearch(value) {
          this.$store.dispatch('imageDialog_SetPage', value);
        }
      },
      template: `
        <div class="image-pager" v-if="pager.total > 0">
          <div class="page-counts">
            <span>Images: {{ pager.total }}</span>
            &nbsp;&nbsp;&nbsp;  
            <span>Displaying page {{ pager.currentPage }} of {{ pager.pageCount }}</span>
          </div>
          <div class="page-controls">
            <span @click="onPreviousPage()"><i class="fas fa-less-than" style="cursor: pointer"></i></span>
            &nbsp;
            <input :value="pager.currentPage" id="currentPage" @blur="executeSearch($event.target.value)" style="width: 25px" />
            &nbsp;
            <span @click="onNextPage()"><i class="fas fa-greater-than" style="cursor: pointer"></i></span>
          </div>
        </div>
      `,
    },
  });
})(sy);

((sy) => {
  sy.components.push({
    id: "imageSearchResults",
    element: "sy-image-search-results",
    component: {
      name: "imageSearchResults",
      data() {
        return {
          searchResultElement: null,
          isPreviewVisible: false,
          selectedImage: {},
          showPlacements: false,
        };
      },
      computed: {
        images() {
          if (this.searchResultElement) {
            this.searchResultElement.scrollTop = 0;
          }
          return this.$store.getters.imageDialog_SearchResultImages;
        },
        searchMessage() {
          return this.$store.getters.imageDialog_SearchMessage;
        },
        searchInProgress() {
          return this.$store.getters.imageDialog_searchInProgress;
        },
        imagePlacementOptions() {
          return this.$store.getters.imageDialog_PlacementOptions;
        },
      },
      methods: {
        onImageSelected(placementKey) {
          this.isPreviewVisible = false;
          this.showPlacements = false;
          this.$store.dispatch("imageDialog_ProcessVendorImage", {
            image: this.selectedImage,
            placementKey,
          });
        },
        onPreview(image) {
          this.selectedImage = image;
          this.isPreviewVisible = true;
        },
        onCancel() {
          this.isPreviewVisible = false;
          this.showPlacements = false;
        },
        onPlaceImageClicked() {
          this.showPlacements = !this.showPlacements;
        },
      },
      mounted() {
        this.searchResultElement = document.getElementById("searchResults");
      },
      template: `
        <div class="image-library-tab">
          <div class="image-library-container" v-if="!isPreviewVisible">
            <sy-image-search-filter></sy-image-search-filter>
            <div class="search-results-container" id="searchResults">
              <div class="image-list-container">
                <ul class="image-list" v-if="images.length > 0 && !searchInProgress">
                  <li v-for="image in images" :key="id" @click="onPreview(image)">
                    <img :src="image.medium_thumbnail" />
                  </li>
                </ul>
                <span v-else>
                    {{ searchMessage }}
                </span>
              </div>    
              <sy-search-pager></sy-search-pager>
            </div>
          </div>
          <div v-else class="preview-container">
            <div class="image-container">
              <img id="previewFileBytes" :src="selectedImage.url_big" />
            </div>
            <div class="preview-buttons">
              <button type="button" class="discard-btn" @click="onCancel()">Cancel</button>

              &nbsp;&nbsp;&nbsp;
              
              <div class="dropdown">
                <button @click="onPlaceImageClicked()" class="dropdown-btn">Place Image</button>
                <div class="dropup-content" :class="{ 'show': showPlacements }">
                  <ul class="dropdown-list">
                    <li v-for="p in imagePlacementOptions" @click="onImageSelected(p.placementKey)">{{ p.name }}</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      `,
    },
  });
})(sy);

((sy) => {
  sy.components.push({
    id: "imageUpload",
    element: "sy-image-upload",
    component: {
      name: "imageUpload",
      data() {
        return {
          isDragOver: false,
          previewFileBytes: "#",
          isPreviewVisible: false,
          showPlacements: false,
          file: null,
        };
      },
      computed: {
        imagePlacementOptions() {
          return this.$store.getters.imageDialog_PlacementOptions;
        },
      },
      methods: {
        onDrag(e) {
          this.preventDefault(e);
        },

        onDragOver(e) {
          this.preventDefault(e);
          this.isDragOver = true;
        },

        onDragEnd(e) {
          this.preventDefault(e);
          this.isDragOver = false;
        },

        onDrop(e) {
          this.preventDefault(e);
          this.isDragOver = false;

          if (
            !e.dataTransfer ||
            !e.dataTransfer.files ||
            e.dataTransfer.files.length === 0
          ) {
            return;
          }

          this.file = e.dataTransfer.files[0];
          this.showPreview();
        },

        preventDefault(e) {
          e.preventDefault();
          e.stopPropagation();
        },

        onFileAdded(event) {
          if (!event.currentTarget.files || event.currentTarget.files == 0) {
            return;
          }
          this.file = event.currentTarget.files[0];
          this.showPreview();
        },

        onPlaceImageClicked() {
          this.showPlacements = !this.showPlacements;
        },

        showPreview() {
          this.previewFileBytes = URL.createObjectURL(this.file); // convert to base64 string
          this.isPreviewVisible = true;
        },

        onUploadFile(placementKey) {
          this.showPlacements = false;
          this.isPreviewVisible = false;

          this.$store.commit("kitBuilderImagePlaceholderSelect", placementKey);

          this.$store.dispatch("uploadImageFromLocal", {
            file: this.file,
            placementKey,
          });
          this.isPreviewVisible = false;
        },

        onDiscard() {
          this.file = null;
          this.isPreviewVisible = false;
          this.showPlacements = false;
        },

        openFileDialog(e) {
          console.log("open file dialog");
          const fileInput = document.querySelector("#uploadImageInput");
          fileInput.click();
        },
      },
      template: `
      <div class="image-upload-tab">
        <div v-if="!isPreviewVisible"
          class="drop-container"
          :class="{ 'drag-over': isDragOver }"

          @drag="onDrag($event)" 
          @dragstart="onDrag($event)" 
          @dragend="onDragEnd($event)" 
          @dragover="onDragOver($event)" 
          @dragenter="onDragOver($event)" 
          @dragleave="onDragEnd($event)" 
          @drop="onDrop($event)"
          @click="openFileDialog($event)"
        >
          <label class="upload-text">
            Drag and Drop an image here or click to upload.

            <span class="upload-icon">
              <i class="fas fa-file-upload"></i>
            </span>
          </label>
          <div style="display: none">
            <input
                id="uploadImageInput"
                name="uploadImageInput"
                type="file"
                @change="onFileAdded($event)"
                max-size="26214400"
                allowed-mime-types="image/jpeg,image/png,image/gif,application/postscript,application/pdf,application/illustrator"
                accept="image/jpeg,image/png,image/gif,application/postscript,application/pdf,application/illustrator"
            />
          </div>
        </div>
        
        <div v-else class="preview-container">
          <div class="image-container">
            <img id="previewFileBytes" :src="previewFileBytes" />
          </div>
          <div class="preview-buttons">
              <button type="button" class="discard-btn" @click="onDiscard()">Discard</button>

              &nbsp;&nbsp;&nbsp;
              
              <div class="dropdown">
                <button @click="onPlaceImageClicked()" class="dropdown-btn">Place Image</button>
                <div class="dropup-content" :class="{ 'show': showPlacements }">
                  <ul class="dropdown-list">
                    <li v-for="p in imagePlacementOptions" @click="onUploadFile(p.placementKey)">{{ p.name }}</li>
                  </ul>
                </div>
              </div>
          </div>
        </div>
    </div>
      `,
    },
  });
})(sy);

((sy) => {
  sy.components.push({
    id: "productSearchDialog",
    element: "sy-product-dialog",
    component: {
      name: "productSearchDialog",
      computed: {
        isVisible() {
          return this.$store.getters.productSearch_IsVisible;
        },
        selectedTab() {
          return this.$store.getters.productSearch_selectedTab;
        }
      },
      methods: {
        onModalClick(event) {
          event.cancelBubble = true;
          event.preventDefault();
        },
        onCloseDialog() {
          this.$store.commit("toolbar_ClearSelectedTool");
          this.$store.dispatch('productSearch_HideDialog');
        }
      },
      template: `
        <div id="productDialog" class="sy-product-search-modal" :style="{ 'display': isVisible ? 'block' : 'none', 'visibility': isVisible ? 'visible' : 'hidden' }">
          <div class="sy-modal-container">
            <div class="sy-modal-title">
              Catalog
            </div>
            <div class="sy-modal-header">
              <span class="sy-modal-close" @click="onCloseDialog()">
                <i class="fas fa-times"></i>
              </span>
            </div>
            <div class="sy-modal-tabs">
              <ul>
                <li :class="{ 'active': selectedTab === 1 }" @click="$store.commit('productSearch_SetSelectedTab', 1)">Search</li>
              </ul>
            </div>
            <div class="sy-modal-body">
              <sy-product-search-tab v-if="selectedTab === 1"></sy-product-search-tab>
            </div>
          </div>
        </div>
      `,
    },
  });
})(sy);

(sy => {
  sy.components.push({
    id: 'productPreview',
    element: 'sy-product-preview',
    component: {
      name: 'productPreview',
      computed: { 
        product() {
          return this.$store.getters.productSearch_PrevewProduct;
        }
      },
      template: `
        <div class="preview-container">
          <div class="image-container">
            <img id="previewFileBytes" :src="product.image" />
            <div class="product-description">
              <h2 class="title">{{ product.name }}</h2>
              <p class="description" v-html="product.fullDescription"></p>
            </div>
          </div>
          <div class="preview-buttons">
            <button type="button" class="discard-btn" @click="$store.dispatch('productSearch_HidePreview')">Back</button>
            <button type="button" class="select-btn" @click="$store.dispatch('productSearch_SelectProduct')">Select</button>
          </div>
        </div>
      `
    }
  });
})(sy);
((sy) => {
  sy.components.push({
    id: "productSearchFilter",
    element: "sy-product-search-filter",
    component: {
      name: "productSearchFilter",
      data() {
        return {
          shirts: [{ key: 'all', text: 'All' }, { key: 'short sleeve t', text: 'Short Sleeve T' }, { key: 'long sleeve t', text: 'Long Sleeve T' }, { key: 'hoodie', text: 'Hoodie' }],
          themes: [{ key: 'all', text: 'All' }, { key: 'gaming', text: 'Gaming' }, { key: 'animals', text: 'Animals' }, { key: 'food', text: 'Food' }, { key: 'random', text: 'Random/Goofy/Funny' }, { key: 'fantasy', text: 'Fantasy' }],
         // fits: [{ key: 'all', text: 'All' }, { key: 'unisex', text: 'Unisex' }, { key: 'women', text: 'Women' }, { key: 'men', text: 'Men' }, { key: 'youth', text: 'Youth' }],
          prints: [{ key: 'all', text: 'All' }, { key: 'DTG', text: 'Direct to Garment' }, { key: 'Sublimation', text: 'Sublimation' }],
          materials: [{ key: 'all', text: 'All' }],
          fits: [
            { id: 1, text: 'Women', value: 'Women', selected: 'false', isactive: '', target: "pills-women" },
            { id: 2, text: 'Men', value: 'Men', selected: 'true', isactive: 'active', target: "pills-Men" },
            { id: 3, text: 'Youth', value: 'Youth', selected: 'false', isactive: '', target: "pills-youth" },
          ],
        };
      },
      computed: {
        isExpanded() {
          return this.$store.getters.productSearch_SearchIsExpanded;
        },
        filterKeywords: {
          get() {
            return this.$store.getters.productSearch_FilterKeywords
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterKeywords", value);
          }
        },
        filterShirts: {
          get() {
            return this.$store.getters.productSearch_FilterShirts;
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterShirts", value);
          }
        },
        filterFits: {
          get() {
            return this.$store.getters.productSearch_FilterFits;
          },
          set(value) {
            console.log(value);
            this.$store.commit("productSearch_SetFilterFits", value);
          }
        },
        filterThemes: {
          get() {
            return this.$store.getters.productSearch_FilterThemes;
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterThemes", value);
          }
        },
        filterPrints: {
          get() {
            return this.$store.getters.productSearch_FilterPrints;
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterPrints", value);
          }
        },
        filterMaterials: {
          get() {
            this.$store.getters.productSearch_FilterMaterials;
          },
          set(value) {
            this.$store.commit("productSearch_SetFilterMaterials", value);
          }
        }
      },
      methods: {
        warn: function (message, event) {
          // now we have access to the native event
          for (i = 0; i < this.fits.length; i++) {

            if (this.fits[i].text === message) {
              this.fits[i].isactive = "active";
              //this.filterFits.set(this.fits[i].target);
              this.$store.commit("productSearch_SetFilterFits", this.fits[i].value);
            }
            else {
              this.fits[i].isactive = "";
             // this.$store.commit("productSearch_SetFilterFits", "All");
            }
            // <------ ... IT WORKS
          }
          this.$store.commit('productSearch_ClearProducts');
          this.$store.dispatch('productSearch_executeSearch');
        },
        onSearch(e) {
          e.preventDefault();
          e.stopPropagation();

          this.$store.commit('productSearch_ClearProducts');
          this.$store.dispatch('productSearch_executeSearch');

          // This handles a phenomenon in IOS where the screen 
          // scrolls up when the virtual keyboard opens and does not scroll
          // back.  This is a manual intervention.
          this.scrollTop();
        },
        onExpand() {
          this.$store.commit("productSearch_ToggleSearchExpanded", !this.isExpanded);
        },
        onFocus(e) {
          this.scrollTop();
        },
        scrollTop() {
          window.scrollTo(0, 0);
          document.body.scrollTop = 0;
        }
      },
      template: `
        <ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="tablist">
              <template v-for="item in fits" :key="item.text">
              <li  class="nav-item" role="tab">
             <button v-model="filterFits" class="nav-link rounded-pill px-4 me-2" :class="item.isactive"  v-bind:id="item.target +'-tab'" data-bs-toggle="pill"
                             v-bind:data-bs-target="'#'+item.target" type="button" role="tab" :aria-controls="item.target"
                            :aria-selected="item.selected" v-on:click="warn(item.text, $event)">
                        {{item.text}}
                    </button>
              </li>
          </template>
          </ul>        
<div class="search-filter-container" :class="{ expanded: isExpanded }">
          <div class="search-filter-title">
            <span v-if="isExpanded">
              Search Filters
            </span>
            <button @click="onExpand()">
              <i v-if="isExpanded" class="fas fa-times fa-lg"></i>
              <i v-else class="fas fa-search fa-lg"></i>
            </button>
          </div>
          <form class="search-filter-criteria" v-if="isExpanded">
            <dl>
              <dt><label>Search:</label></dt>
              <dd><input type="text" v-model="filterKeywords" placeholder="keywords" maxlength="200" @focus="onFocus($event)" @blur="onFocus($event)" /></dd>

              <dt><label>Shirt:</label></dt>
              <dd>
                <select v-model="filterShirts">
                  <option v-for="item in shirts" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd>
 
              <dt><label>Fit:</label></dt>
              <dd>
                <select v-model="filterFits">
                  <option v-for="item in fits" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd>
 
              <dt><label>Theme:</label></dt>
              <dd>
                <select v-model="filterThemes">
                  <option v-for="item in themes" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd>
 
              <dt><label>Print:</label></dt>
              <dd>
                <select v-model="filterPrints">
                  <option v-for="item in prints" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd>

              <!-- <dt><label>Material:</label></dt>
              <dd>
                <select v-model="filterMaterials">
                  <option v-for="item in materials" :value="item.key"> {{ item.text }}</option>
                </select>
              </dd> -->
            </dl>
            <button class="search-btn" type="submit" @click="onSearch($event)">
              Search
            </button>
          </form>
        </div>
      `,
    },
  });
})(sy);

/// <reference path="../../../newproductscreen.js" />
((sy) => {
  sy.components.push({
    id: "productSearchResults",
    element: "sy-product-search-results",
    component: {
      name: "productSearchResults",
      data() {
        return {
          productViewport: null,
          productList: null,
          scrollTop: 0
        };
      },
      computed: {
        products() {
          // if (this.productList) {
          //   console.log('Scroll to:', this.scrollTop);
          //   document.getElementById('productSearchViewPort').scrollTop = this.scrollTop;
          // }
          return this.$store.getters.productSearch_SearchResultProducts;
        },
        isPreviewVisible() {
          return this.$store.getters.productSearch_IsPreviewVisible
        },
        searchMessage() {
          return this.$store.getters.productSearch_SearchMessage;
        },
        searchInProgress() {
          return this.$store.getters.productSearch_searchInProgress;
        },
      },
      methods: {
        onPreview(selectedProductIndex) {
          this.$store.commit('productsSearch_setPrevewProductIndex', selectedProductIndex);
          this.$store.dispatch('productSearch_ShowPreview');
          this.$store.dispatch('productSearch_SelectProduct');
        },
        onScroll() {
          this.productViewport = $('#productSearchViewPort');
          this.productList = $('#productList');

          //List height
          const scrollHeight = this.productList.height();

          //scroll position
          var scrollPos = this.productViewport.height() + this.productViewport.scrollTop();

          // fire if the scroll position is 300 pixels above the bottom of the viewer
          if (((scrollHeight - 300) >= scrollPos) / scrollHeight == 0) {
            this.scrollTop = document.getElementById('productSearchViewPort').scrollTop;
            this.$store.dispatch('productSearch_LoadMoreProducts');
          }
          console.log('Scrolled', scrollHeight, scrollPos);
        }
      },
      template: `
     
              <div class="row row-cols-2 row-cols-sm-2 row-cols-md-2 row-cols-lg-2 d-flex justify-content-center" id="productList" v-if="products.length > 0 && !searchInProgress">
                <div class="col" v-for="(product, index) in products" :key="product.id" @click="onPreview(index)">
<label>{{ product.name }}</label>                 
<img :src="product.image" class="img-fluid"  />
                  
                </div>
              </ul>

            </div>
       
      `,
    },
  });
})(sy);

((sy) => {
  sy.components.push({
    id: "productSearchTab",
    element: "sy-product-search-tab",
    component: {
      name: "productSearchTab",
      computed: {
        isPreviewVisible() {
          return this.$store.getters.productSearch_IsPreviewVisible
        }
      },
      template: `
        <div class="product-search-tab">
          <div class="product-search-container" v-if="!isPreviewVisible">
            <sy-product-search-filter></sy-product-search-filter>
            <sy-product-search-results></sy-product-search-results>
          </div>
          <sy-product-preview v-else></sy-product-preview>
        </div>
      `,
    },
  });
})(sy);

((sy) => {
  sy.components.push({
    element: 'sy-sharing',
    component: {
      id: 'Sharing',
      computed: {
        isVisible() {
          if (this.$store.getters.sharing_shareStreamsAreVisible) {
            const productContainer = document.getElementById('productContainer');
            productContainer.classList.add('friend-share');
          } else {
            const productContainer = document.getElementById('productContainer');
            if (productContainer) {
              productContainer.classList.remove('friend-share');
            }
          }
          return this.$store.getters.sharing_shareStreamsAreVisible;
        }
      },
      beforeMount() {
        this.$bus.on('product_beforeProductChange', data => {
          console.log('pause sharing');
          this.$store.dispatch('sharing_pauseSharing');
        });

        this.$bus.on('product_loaded', data => {
          if (this.$store.getters.sharing_isSharing) {
            this.$store.dispatch('sharing_shareRenderer');
          }
        });
      },
      template: `
        <div v-if="isVisible">
          <sy-sharing-local></sy-sharing-local>
          <sy-sharing-remote></sy-sharing-remote>
        </div>
        <sy-sharing-dialog></sy-sharing-dialog>
      `
    }
  });
})(sy);
((sy) => {
  sy.components.push({
    element: 'sy-sharing-dialog',
    component: {
      id: 'SharingDialog',
      data() {
        return {
          dialogVisible: false,
          isConnecting: false
        }
      },
      computed: {
        shareDialogIsVisible() {
          if (this.$store.getters.sharing_shareDialogIsVisible) {
            this.$store.dispatch('sharing_connectSignalR');
            this.$store.dispatch('sharing_getIceServers');
          }

          setTimeout(() => {
            this.dialogVisible = this.$store.getters.sharing_shareDialogIsVisible ? true : false;
          }, 0);

          return this.$store.getters.sharing_shareDialogIsVisible;
        },
        shareDialogStep() {
          return this.$store.getters.sharing_shareDialogStep;
        },
        signalRId() {
          return this.$store.getters.sharing_localSignalRId;
        },
        remoteSignalRId: {
          get() {
            return this.$store.getters.sharing_remoteSignalRId;
          },
          set(value) {
            this.$store.commit('sharing_setRemoteSignalRId', value);            
          }
        }
      },
      methods: {

        onClose() {
          // Let the dialog fade out
          this.dialogVisible = false;
          this.isConnecting = false;
          // before removing the component from the dom
          setTimeout(() => {
            this.$store.commit('sharing_hideDialog');
          }, 1000);
        },

        createCode() {
          this.$store.commit('sharing_setInitiator', false);
          this.$store.dispatch('sharing_createPeer');
          this.$store.commit('sharing_setDialogStep', 2);
        },

        haveCode() {
          this.$store.commit('sharing_setDialogStep', 3);
        },

        callAFriend() {
          this.isConnecting = true;
          this.$store.commit('sharing_setInitiator', true);
          this.$store.dispatch('sharing_createPeer');
        },

        copyCodeToClipboard() {
          const code = document.querySelector("#friendSharingCode");
          code.select();
          document.execCommand("copy");
        },

        shareStreams() {
          this.$store.dispatch('sharing_startStreamSharing');
          this.onClose();
        }
      },
      template: `
        <div 
          v-if="shareDialogIsVisible" 
          class="sharing-dialog"
        >
          <div class="sharing-dialog-body" :class="{ visible: dialogVisible }">
              <button type="button" class="close-dialog" @click="onClose()" title="Close share dialog">
                <i class="fas fa-times"></i>
              </button>

              <div style="text-align: center">

                <!-- Step 1: Start -->
                <div class="sharing-step" v-if="shareDialogStep === 1">
                  <h2>
                    It's more fun to shirt together!
                  </h2>
                  <br />
                  <span class="message"> 
                    How would you like to join?
                  </span>
                  <div class="dialog-buttons">
                    <button type="button" class="button" @click="haveCode()">Have a code</button>
                    <button type="button" class="button" @click="createCode()">Send a code</button>
                  </div>
                </div>

                <!-- Step 2: Send a code -->
                <div class="sharing-step" v-if="shareDialogStep === 2">
                  <h2>
                    Get ready to play!
                  </h2>
                  <br />
                  <span class="message"> 
                    Click to copy this code and send it to your friend to start shirting together.
                  </span>
                  <br />
                  <input 
                    type="input"
                    id="friendSharingCode" 
                    class="share-code" 
                    :value="signalRId" 
                    @click="copyCodeToClipboard()"
                    readonly />
                  <button class="copy-button" @click="copyCodeToClipboard()" title="Copy to clipboard">
                    <i class="fas fa-copy"></i>
                  </button>
                  <div>
                    <button type="button" class="button" @click="onClose()" title="Done">Done</button>
                  </div>
                </div>

                <!-- Step 3: Join with code -->
                <div class="sharing-step" v-if="shareDialogStep === 3">
                  <h2>
                    Get ready to play!
                  </h2>
                  <br />

                  <span class="message"> 
                    Enter the code
                  </span>
                  <br />

                  <input type="text" v-model="remoteSignalRId" class="share-code" />
                  <button 
                    type="button" 
                    class="button"
                    @click="callAFriend()"
                    :disabled="isConnecting">
                      {{ isConnecting ? 'Connecting' : 'Join' }}
                  </button>
                </div>

                <!-- Step 4: Friend has joined -->
                <div class="sharing-step" v-if="shareDialogStep === 4">
                  <h2>
                    Your friend has joined!
                  </h2>
                  <br />

                  <span class="message"> 
                    Please grant access to your mic and camera when prompted.
                  </span>
                  <br />
                  
                  <button 
                    type="button" 
                    class="button"
                    @click="shareStreams()">
                    Go!
                  </button>
                </div>

                 <!-- Step 5: Error connecting -->
                 <div class="sharing-step" v-if="shareDialogStep === 5">
                  <h2>
                    There was a problem!
                  </h2>
                  <br />

                  <span class="message"> 
                    Something went wrong connecting to your friend.  Please try again later.
                  </span>
                  <br />
                  <button type="button" class="button" @click="onClose()" title="Close">Close</button>
                </div>
              </div>
          </div>
        </div>
      `
    }
  });
})(sy);
((sy) => {
  sy.components.push({
    element: 'sy-sharing-local',
    component: {
      id: 'SharingLocal',
      beforeMount() {
        this.$bus.on('sharing_playLocalVideo', stream => { 
          this.playLocalVideoStream(stream);
        })
      },
      beforeUnmount() {
        this.$bus.on('sharing_playLocalVideo', stream => { 
          this.playLocalVideoStream(stream);
        })
      },      
      computed: {
        isVisible() {
          return this.$store.getters.sharing_shareStreamsAreVisible;
        }
      },
      methods: {
        playLocalVideoStream(stream) {
          const localVideo = document.getElementById('localVideo');
          if (localVideo) {
            localVideo.srcObject = stream; // yba.sharing.localVideoStream;
            localVideo.play();
          }
        },
      },
      template: `
        <div 
          v-if="isVisible"
          class="local-stream-container"
        >
          <video id="localVideo" 
            playsinline 
            autoplay 
            muted 
            style="width: 100%; height: 100%">
          </video>
        </div>            
      `
    }
  });
})(sy);
((sy) => {
  sy.components.push({
    element: "sy-sharing-remote",
    component: {
      id: "SharingRemote",
      data() {
        return {};
      },
      beforeMount() {
        this.$bus.on('sharing_playRemoteVideo', stream => {
          console.log('Sharing remote component received trigger to play video.')
          this.playRemoteVideo(stream);
        });
        this.$bus.on('sharing_playRemoteRenderer', stream => {
          console.log('Sharing remote component received trigger to play renderer.')
          this.playRemoteRenderer(stream);
        });
      },
      beforeUnmount() {
        this.$bus.off('sharing_playRemoteVideo', stream => {
          this.playRemoteVideo(stream);
        });
        this.$bus.off('sharing_playRemoteRenderer', stream => {
          this.playRemoteRenderer(stream);
        });
      },
      computed: {
        isVisible() {
          return this.$store.getters.sharing_shareStreamsAreVisible;
        }
      },
      methods: {
        playRemoteVideo(stream) {
          if (!yba.sharing.remoteVideoStream) {
            return;
          }
          const remoteVideo = document.getElementById('remoteVideo');
          if (remoteVideo) {
            remoteVideo.srcObject = stream; // yba.sharing.remoteVideoStream;
            remoteVideo.play();
          }
        },
        playRemoteRenderer(stream) {
          if (!yba.sharing.remoteCanvasStream) {
            return;
          }
          const remoteCanvas = document.getElementById('remoteCanvas');
          if (remoteCanvas) {
            remoteCanvas.srcObject = stream; // yba.sharing.remoteCanvasStream;
            remoteCanvas.play();
          }
        }
      },
      template: `
        <div 
          v-if="isVisible"
          class="remote-stream-container"
        >
          <video 
            id="remoteVideo" 
            class="remote-video"
            playsinline 
            autoplay
          >
          </video>
          <video 
            id="remoteCanvas" 
            class="remote-renderer"
            playsinline 
            autoplay 
            muted>
          </video>
          <div class="remote-button-container">
            <button id="btnHangUp" @click="$store.dispatch('sharing_stopShare', 1)" title="Stop sharing">
              <i class="fas fa-phone-slash"></i>
            </button>
          </div>
        </div>      
      `,
    },
  });
})(sy);

((sy) => {
  sy.components.push({
    element: 'sy-toolbar-editors',
    component: {
      data() {
        return {
          tools: [
           /* { id: 1, title: 'merchandise', name: 'merchandise', image: 'fa-tshirt', controlId: 'btnMerchandise', top: 0, left: '95px' },*/
            { id: 2, title: 'colors', name: 'color', image: 'fa-palette', controlId: 'btnColorPicker', top: 0, left: '5px' },
            { id: 3, title: 'text', name: 'text', image: 'fa-font', controlId: 'btnAddText', top: 0, left: '95px' },
            { id: 4, title: 'images', name: 'image', image: 'fa-image', controlId: 'btnAddImage', top: 0, left: '95px' },
            { id: 5, title: 'print guide', name: 'printguide', image: 'fa-border-none', controlId: 'btnPrintGuide', top: 0, left: '95px' },
          ],
          title: 'DESIGN TOOLS',
          printGuide: false
        }
      },
      computed: {
        toolbarsVisible() {
          return this.$store.getters.toolbarsVisible;
        },
        collapsed() {
          return this.$store.getters.toolbarsEditCollapsed;
        },
        selectedTool() {
          return this.$store.getters.toolbarsEditSelectedTool || { name: '' };
        },
        isMobile() {
          return this.$store.getters.responsive_getDevice == 1;
        }
      },
      methods: {
        toolClick(tool, e) {

          if (this.selectedTool.name === tool.name) {
            this.$store.commit("toolbar_ClearSelectedTool");
            return;
          }

          this.$store.commit('toolbar_SetSelectedTool', tool);

          tool.top = `${e.target.offsetTop - 15}px`;
          tool.left = '95px';

          if (tool.name === 'merchandise') {
            this.$store.dispatch('productSearch_ShowDialog');
          } else if (tool.name === 'text') {
            this.$refs.textMenu.repositionKbPickers();
          } else if (tool.name === 'image') {
            this.$refs.imageMenu.repositionKbPickers();
          } else if (tool.name === 'color') {
            this.$refs.colorMenu.repositionKbPickers();
          } else if (tool.name = 'printguide') {
            const t = document.querySelector('.kb-wizard-form-key-print-guide input[type="checkbox"]');
            if (t) {
              t.click();
            }
            this.printGuide = t.checked;
            this.$store.commit("toolbar_ClearSelectedTool");
            return;
          }

          this.$store.dispatch('toolbars_collapse', { toolbar: 'purchaseToolbar', collapsed: true });
        },
        toggleCollapse() {
          this.$store.dispatch('toolbars_toggle', { toolbar: 'editorToolbar' })
        },
        closeMenu(tool) {
          tool.isSubMenuVisible = false;
        },
        initPrintGuide() {
          const kbPrintGuide = document.querySelector('.kb-wizard-form-key-print-guide');
          if (kbPrintGuide) {
            this.hasPrintGuide = true;
            this.printGuide = document.querySelector('.kb-wizard-form-key-print-guide input[type="checkbox"]').checked;
          }
        }
      },
      beforeMount() {
        this.$bus.on('product_loaded', data => {
          this.initPrintGuide();
        });
      },
      template: `
      <div class="" :class="[ 'toolbar', 'toolbar-left', 'toolbar-side', { 'toolbar-collapsed': collapsed } ]" v-show="toolbarsVisible">
        <div class="toolbar-title" @click="toggleCollapse()">
            <span class="toolbar-label">{{ title }}</span>
        </div>
        <div class="toolbar-arrow arrow-left" @click="toggleCollapse()"></div>
        <div class="toolbar-tools" id="toolsToolbarTools">
          <div class="toolbar-tools-body">
            <ul style="padding-left:1px!important;">
              <template v-for="tool in tools" :key="tool.id">
                <li>
                  <button 
                    class="toolbar-item" 
                    :class="[{ 'highlight': tool.name === 'printguide' && printGuide === true }]"
                    :id="tool.controlId" 
                    @click="toolClick(tool, $event)"
                  >
                    <i :class="['fas', tool.image]"></i>
                    <label class="tool-label">{{ tool.title }}</label>
                  </button>

                  <sy-text-menu
                    ref="textMenu"
                    v-if="tool.name === 'text'"
                    id="textMenu"
                    :style="{ top: isMobile ? 0 : tool.top, left: tool.left }"
                    :class="{ 'sy-toolbar-item-active': selectedTool.name === 'text' }"
                  ></sy-text-menu>

                  <sy-image-menu
                    ref="imageMenu"
                    id="imageMenu"
                    v-if="tool.name === 'image'"
                    :style="{ top: isMobile ? 0 : tool.top, left: tool.left }"
                    :class="{ 'sy-toolbar-item-active': selectedTool.name === 'image' }"
                  ></sy-image-menu>

                  <sy-color-menu
                    ref="colorMenu"
                    id="colorMenu"
                    v-if="tool.name === 'color'"
                    :style="{ top: isMobile ? 0 : tool.top, left: tool.left }"
                    :class="{ 'sy-toolbar-item-active': selectedTool.name === 'color' }"
                  ></sy-color-menu>
                </li>
                <li class="toolbar-divider" v-if="tool.id !== tools.length"></li>
              </template>
            </ul>
          </div>
        </div>
      </div>
    `
    }
  });
})(sy);
((sy) => {
  sy.components.push({
    element: 'sy-toolbar-purchase',
    component: {
      data() {
        return {
          tools: [             
            { id: 2, name: 'locker room', image: 'fa-piggy-bank', controlId: 'btnLockerRoom', title: "My saved designs", bottom: 0, left: 0 },
            { id: 3, name: 'save', image: 'fa-save', controlId: 'btnSave', title: "Save this design for later.", bottom: 0, left: 0 },
            { id: 4, name: 'checkout', image: 'fa-shopping-cart', controlId: 'btnCheckout', title: "Select sizes and quantity", bottom: 0, left: 0 },
            { id: 5, name: 'description', image: 'fa-clipboard-list', controlId: 'btnDescription', title: "Product description", bottom: 0, left: 0 },
            { id: 6, name: 'live share', image: 'fa-user-friends', controlId: 'btnLiveShare', title: "Shirt yourself with a friend", display: 'none', bottom: 0, left: 0 },
            { id: 7, name: 'stop share', image: 'fa-phone-slash', controlId: 'btnStopShare', title: "Stop sharing", display: 'none', bottom: 0, left: 0 }
          ],
          selectedTool: { name: '' },
          title: 'I LIKE IT!'
        }
      },
      computed: {
        toolbarsVisible() {
          return this.$store.getters.toolbarsVisible && (window.yba && window.yba.showBuyToolbar);
        },
        collapsed() {
          return this.$store.getters.toolbarsPurchaseCollapsed;
        },
        liveShareEnabled() {
          // Hack: Hide live share until it's ready
          const device = this.$store.getters.responsive_getDevice;
          const enabledForDevice = device > 2; // liveshare is only on desktop

          const shareButton = this.tools.find(x => x.controlId === 'btnLiveShare');
          shareButton.display = this.$store.getters.product_liveShareEnabled && enabledForDevice ? 'block' : 'none';

          return this.$store.getters.product_liveShareEnabled;
        },
        lockerRoomEnabled() {
          // Hack: Hide locker room until it's ready
          const lockerButton = this.tools.find(x => x.controlId === 'btnLockerRoom');
          // lockerButton.visible = this.$store.getters.product_lockerRoomEnabled ? 'visible' : 'hidden';
          lockerButton.display = this.$store.getters.product_lockerRoomEnabled ? 'block' : 'none';
          
          const saveButton = this.tools.find(x => x.controlId === 'btnSave');
          // saveButton.visible = lockerButton.visible;
          saveButton.display = lockerButton.display;
          
          return this.$store.getters.product_lockerRoomEnabled;
        },
        isMobile() {
          return this.$store.getters.responsive_getDevice == 1;
        }
      },
      methods: {
        toolClick(tool, e) {

          switch (tool.controlId) {
            case 'btnCheckout':
              this.$store.dispatch('checkoutShow');
              break;
            case 'btnLiveShare':
              this.$store.commit('sharing_showDialog', 1);
              break;
            case 'btnStopShare':
              this.$store.dispatch('sharing_stopShare', 1);
              break;
            case 'btnSave':
              this.$store.dispatch('lockerRoom_ShowSave')
              break;
            case 'btnLockerRoom':
              this.$store.dispatch('lockerRoom_ShowLockerRoom');
              break;
            case 'btnDescription':
              let descriptionWidth = 500;
              if (this.$store.getters.responsive_getDevice === 1) {
                descriptionWidth = 400;
              }

              tool.bottom = `${e.target.offsetTop + 45}px`;
              tool.left = `${e.target.offsetLeft - descriptionWidth}px`;

              this.$store.dispatch('toolbars_toggleProductPrice');
              break;
          }

        },
        toggleCollapse() {
          this.$store.dispatch('toolbars_toggle', { toolbar: 'purchaseToolbar' });
        },
        liveShareUpdate(isActive) {
          const btnStopShare = this.tools.find(x => x.controlId === 'btnStopShare');
          btnStopShare.display = isActive  ? 'block' : 'none';

          const btnLiveShare = this.tools.find(x => x.controlId === 'btnLiveShare');
          btnLiveShare.display = isActive ? 'none' : 'block';
        }
      },
      beforeMount() {
        this.$bus.on('sharing_start', () => { this.liveShareUpdate(true); });
        this.$bus.on('sharing_end', () => { this.liveShareUpdate(false); });
      },
      beforeUnmount() {
        this.$bus.off('sharing_start', () => { this.liveShareUpdate(true); });
        this.$bus.off('sharing_end', () => { this.liveShareUpdate(false); });
      },
      template: `
      <div
        :class="['toolbar', 'toolbar-bottom', { 'toolbar-collapsed': collapsed } ]"
        :style="[{ 'width': isMobile ? '180px' : 'auto' }]"
        
      >
        <div class="toolbar-title" @click="toggleCollapse()">
            <span class="toolbar-label"> {{ title }} </span>
        </div>
        <div class="toolbar-arrow arrow-down" @click="toggleCollapse()"></div>
        <div class="toolbar-tools">
          <div class="toolbar-tools-body">
            <template v-for="tool in tools" :key="tool.id">
              <button 
                :id="tool.controlId" 
                :title="tool.title" 
                :style="[{ 'display': tool.display || 'default' }]"
                @click="toolClick(tool, $event)"
                class="toolbar-item" 
              >
                <i :class="['fas', tool.image]"></i>
                <label class="tool-label">{{ tool.name }}</label>
              </button>
              <!-- <div class="toolbar-divider-vertical" v-if="tool.id < 4" :id="'btn' + tool.name"></div> -->

              <sy-price-popover 
                v-if="tool.controlId == 'btnCheckout'" 
              ></sy-price-popover>
              <!-- :style="{ bottom: tool.bottom, left: tool.left }" -->
              
              <sy-product-description-popover 
                v-if="tool.controlId == 'btnDescription'"
              >
              </sy-product-description-popover>
            </template>
          </div>
        </div>
        <div style="display:none">
          {{ liveShareEnabled }}
          {{ lockerRoomEnabled }}
        </div>
      </div>
    `
    }
  });
})(sy);

((sy) => {
  sy.components.push({
    element: 'sy-color-menu',
    component: {
      name: 'colorMenu',
      data() {
        return {
          menuItems: [],
          selectedItem: ''
        }
      },
      beforeMount() {
        this.$bus.on('product_change', data => { 
          // console.log('color picker received product change event');
          this.reset();
        })
      },
      beforeUnmount() {
        this.$bus.off('product_change', data => { 
          this.reset();
        })
      },
      methods: {
        displayColorPicker(menuItem, e) {
          if (this.selectedItem !== menuItem.id) {
            menuItem.top = `${e.offsetTop + 40}px`;
            this.selectedItem = menuItem.id;
          } else {
            this.selectedItem = '';
          }
        },
        reset() {
          // Remove all the children that we manually appended
          this.menuItems.forEach(item => {
            let menuItemContainer = document.getElementById('menuItemContainer' + item.id);
            if (!menuItemContainer) { return; }
            while (menuItemContainer.firstChild) {
              menuItemContainer.removeChild(menuItemContainer.firstChild);
            }
          });
          // console.log('Clear color menu');
          this.menuItems = [];
        },
        repositionKbPickers() {
          if (this.menuItems && this.menuItems.length > 0) { return; }

          let colorContainers = document.querySelector('.kb-wizard > li > div').children;
          this.menuItems.length = 0;
          this.selectedItem = '';
          colorContainers.forEach(color => {
            // Check to see if it has a color picker child
            if (color.getElementsByClassName('kb-tile-picker-color').length > 0) {
              let menuItem = {
                text: color.children[0].innerText,
                id: this.menuItems.length, // color.classList.value.replace('-', '')
                kbSelector: `.${color.classList.value}`, //  '.kb-group-base-colour',
                isLoaded: false,
                top: 0,
                selectedColor: 'white'
              }
              this.menuItems.push(menuItem);
            }
          });

          // Need Vue to digest the model change and update the dom before
          // we move the KB color pickers to the menu
          // use a timeout to achieve this
          setTimeout(() => {
            this.menuItems.forEach(item => {
              if (!item.isLoaded) {
                let kbColorContainer = document.querySelector(item.kbSelector);
                let menuItemContainer = document.getElementById('menuItemContainer' + item.id);

                let node = kbColorContainer.getElementsByClassName('kb-wizard-form-row')[0];
                node.style = 'display: block !important; visibility: visible !important';

                node = kbColorContainer.getElementsByClassName('kb-wizard-form-label')[0];
                node.style = 'display: none !important';

                menuItemContainer.append(kbColorContainer);

                const colorValue = kbColorContainer.querySelector(`input[type="radio"]:checked`).value;
                item.selectedColor = this.extractColorValue(colorValue);
                item.isLoaded = true;

                if (this.menuItems.length == 1) {
                  // Display default color picker if there is only 1
                  this.displayColorPicker(this.menuItems[0], menuItemContainer);
                }
              }
            });

          }, 1);
        },
        colorChanged(menuItem) {
          colorValue = document.querySelector(`${menuItem.kbSelector} input[type="radio"]:checked`).value;
          menuItem.selectedColor = this.extractColorValue(colorValue);
        },
        closeMenu() {
          this.$store.commit("toolbar_ClearSelectedTool");
          this.selectedItem = '';
        },
        closeColorPicker() {
          this.selectedItem = '';
        },
        extractColorValue(colorValue) {
          if (colorValue.substring(0, 1) === '#')
          {
            return colorValue;
          } else if (colorValue.startsWith('kb-cmyk')) {
            return colorValue.substring(8, 15);
          }
          return '#fff';
        }
      },
      template: `
        <div class="sy-color-menu sy-toolbar-color-menu">
          <div class="close-toolbar" @click="closeMenu()"></div>
          <ul>
            <li
              v-for="menuItem in menuItems" :key="menuItem.id"
              @click="displayColorPicker(menuItem, $event.currentTarget)"
              :class="['sy-color-menu-item',
              { 'active': menuItem.id === selectedItem }]"
            >
              <label>{{ menuItem.text }}</label>
              <button 
                type="button" 
                class="color-dropdown-button"
                @click="displayColorPicker(menuItem, index, $event)"
              >
                  <i class="fas fa-caret-down outer-arrow"></i>
                  <i class="fas fa-caret-down inner-arrow" :style="{ 'color': menuItem.selectedColor }"></i>
              </button>
            </li>
          </ul>
          <div
            v-for="menuItem in menuItems"
            :key="menuItem.id"
            v-show="menuItem.id === selectedItem"
            :id="'menuItemContainer' + menuItem.id"
            class="sy-color-picker-body"
            :style="{ top: menuItem.top }"
            @click="colorChanged(menuItem)"
          >
            <div class="close-toolbar" @click="closeColorPicker()"></div>
              <!-- KB Color Picker will be inserted here -->
          </div>
        </div>
      `
    }
  });
})(sy);


((sy) => {
  sy.components.push({
    element: 'sy-image-menu',
    component: {
      name: 'imageMenu',
      data() {
        return {
          selectedItem: '',
          maskAreas: [],
          domObserver: null
        }
      },
      beforeMount() {
        this.$bus.on('product_change', data => { 
          this.reset();
        })
        this.$bus.on('product_loaded', data => {
          this.repositionKbPickers();
        });
      },
      beforeUnmount() {
        this.$bus.off('product_change', data => {
          this.reset();
        });
        if (this.domObserver) {
          this.domObserver.disconnect();
        };
      },      
      methods: {
        reset() {
          if (this.domObserver) {
            this.domObserver.disconnect();
          };
  
          this.maskAreas.forEach(item => {
            const parentNode = document.getElementById(`placedImageContainer${item.id}`);
            while (parentNode.firstChild) {
              parentNode.removeChild(parentNode.firstChild);
            }
          });
          this.$store.commit('kitBuilderImagePlaceholderClear');
          this.maskAreas.length = 0;
        },
        repositionKbPickers() {
          if (this.maskAreas.length > 0) { return; }

          let kitBuilderImagePickerContainer = document.querySelector('.kb-wizard > li:nth-child(2) > div .kb-wizard-form-row .kb-wizard-form-field .kb-editor');
          kitBuilderImagePickerContainer.children.forEach(group => {
            let header = group.querySelector('.kb-wizard-group-header');
            header.style = 'display: none !important;';

            let scope = angular.element(group).scope();
            this.maskAreas.push({
              id: this.maskAreas.length,
              text: header.innerText.replace('Upload Your', ''),
              placement: scope.placement,
              kbElement: group,
              isLoaded: false,
              scope: scope,
              isLabelVisible: true
            });
            this.$store.commit('kitBuilderImagePlaceholderInsert', scope.placement);

            // item in getModel('image', placement.placementKey)  get list of placed images
          });

          if (this.maskAreas.length > 0 && this.maskAreas[0].placement) {
            this.$store.commit('kitBuilderImagePlaceholderSelect', this.maskAreas[0].placement.placementKey);
          }

          setTimeout(() => {
            this.maskAreas.forEach(item => {
              if (item.kbElement) {

                // Reparent placed image
                let addImageContainer = document.getElementById(`placedImageContainer${item.id}`);
                addImageContainer.append(item.kbElement);

                let image = item.kbElement.querySelector('.kb-editor-placement-image > div:nth-child(2)');
                image.style = 'display: block !important; visibility: visible !important';

                item.isLoaded = true;
              }
            });

            // Update labels and price
            this.onImageUpdate();
            this.watchDom();
          }, 1);
        },

        watchDom() {
          let dom = document.querySelector('.sy-image-menu');

          // Options for the observer (which mutations to observe)
          const config = { attributes: true, childList: true, subtree: true };
          let updatePlacedImages = this.onImageUpdate;

          // Callback function to execute when mutations are observed
          const domMutated = function (mutationsList, observer) {
            for (const mutation of mutationsList) {
              if (mutation.type !== 'attributes') {
                updatePlacedImages();
              }
            }
          };

          // Create an observer instance linked to the callback function
          this.domObserver = new MutationObserver(domMutated);

          // Start observing the target node for configured mutations
          this.domObserver.observe(dom, config);
        },

        onImageUpdate() {
          this.maskAreas.forEach(item => {
            let addImageContainer = document.getElementById(`placedImageContainer${item.id}`);
            let image = addImageContainer.querySelectorAll('img');

            // If area has images then display Label
            item.isLabelVisible = (image.length > 0) ? true : false;

            let sideText = item.text.toLowerCase();
            let side = sideText.indexOf('front') > 0 ? 'front' :
              sideText.indexOf('back') > 0 ? 'back' :
              sideText.indexOf('left') > 0 ? 'left' :
              sideText.indexOf('right') > 0 ? 'right' : null;

            // Update price for DTG garments that are printed on more than one side
            if (image.length > 0 && side !== null) {
              this.$store.commit('product_setImageSide', { side, value: true });
            } else {
              this.$store.commit('product_setImageSide', { side, value: false });
            }
          });
        },

        onOpenSearch() {
          this.$store.commit('imageDialog_SetSelectedTab', 1)
          this.$store.commit('imageDialog_ToggleVisibility', true);
        },
        onUploadImage() {
          this.$store.commit('imageDialog_SetSelectedTab', 2)
          this.$store.commit('imageDialog_ToggleVisibility', true);
        },
        closeMenu() {
          this.$store.commit("toolbar_ClearSelectedTool");
        }
      },
      template: `
        <div class="sy-image-menu">
          <div class="close-toolbar" @click="closeMenu()"></div>
          <div class="image-button-container">
            <div>
              <button
                type="button"
                id="btnUploadImage"
                title="Upload image from your computer"
                @click="onUploadImage()"
              >
                  <i class="fas fa-upload fa-3x"></i>
              </button>
              <label for="btnUploadImage">Upload</label>
            </div>
            <div>
              <button
                type="button"
                id="btnSearchImageLibrary"
                title="Search our library for images"
                @click="onOpenSearch()"
              >
                <i class="fas fa-search fa-3x"></i>
              </button>
              <label for="btnSearchImageLibrary">Library</label>
            </div>
          </div>
          <div
            v-for="menuItem in maskAreas"
            :key="menuItem.id"
            :id="'addedImageContainer' + menuItem.id"
            class="placed-image-container"
            v-show="menuItem.isLabelVisible"
          >
          <!-- v-show="isLabelVisible" -->

            <div :id="'placedImageContainer' + menuItem.id" class="placed-images kb-wrapper">
              <div class="image-area-label">
                <span>{{ menuItem.text }}: </span>
              </div>
              <!-- insert KitBuilder image placement here  -->
            </div>
          </div>
        </div>
      `
    }
  });
})(sy);


(sy => {
  sy.components.push({
    element: 'sy-style-picker',
    component: {
      data() {
        return {
          expand: false,
          container: {
            x: -125,
            y: -125
          },
          currentSelectedId: 0
        }
      },
      computed: {
        pickerVisible() {
          setTimeout(() => this.expand = this.$store.getters.stylePickerVisible, 100);
          return this.$store.getters.stylePickerVisible;
        },
        matrix() {
          return this.$store.getters.stylePickerMatrix;
        },
      },
      methods: {
        onItemClick(event) {

          const triggerElement = event.target;

          // Only proces events from products
          if (!triggerElement.classList.contains('picker-choice')) {
            return;
          }

          const newSelectedId = parseInt(triggerElement.getAttribute('data-item-id'), 10);
          const selectedItem = this.$store.state.stylePicker.matrix.find(x => x.id === newSelectedId);

          if (newSelectedId === this.currentSelectedId) {
            const styleItem = this.$store.state.stylePicker.styles.find(x => x.id === newSelectedId);
            
            const basketIndex = window.location.hash.indexOf('basket');
            const basketIndexFragment = window.location.hash.substring(basketIndex);
            let basketIndexParm = basketIndexFragment.split('&')[0]; // Url may contain additional parameters, split on ampersand
            const delimiter = (styleItem.hash && styleItem.hash.indexOf('?') > -1) ? '&' : '?';

            window.location.hash = `${styleItem.hash}${delimiter}${basketIndexParm}`;
            this.closeMenu();
            return;
          } else {
            this.$store.dispatch('stylePickerMatrixScrolled', newSelectedId);
            this.$store.dispatch('stylePickerSetHero', newSelectedId);
            this.currentSelectedId = newSelectedId;
          }

          let imageWidth = this.$store.state.stylePicker.imageWidth;
          this.container.x = (selectedItem.posX * -1) * imageWidth - (imageWidth / 2);
          this.container.y = (selectedItem.posY * -1) * imageWidth - (imageWidth / 2);
        },
        closeMenu() {
          this.$store.commit("toolbar_ClearSelectedTool");
          this.$store.dispatch('stylePickerHide');
        }
      },
      template: `
        <div
          id="styleViewport"
          class="style-viewport"
          v-if="pickerVisible"
          @click="onItemClick($event)"
          :class="[{ 'expand': expand }]"
        >
          <div class="close-toolbar" @click="closeMenu()"></div>
          <div
            id="styleContainer"
            class="style-container"
            :style="{ transform: 'translate(' + container.x + 'px, ' + container.y + 'px)' }"
          >
            <template v-for="product in matrix" :key="product.id">
              <div
                :class="[ 'picker-choice', { 'hero': product.hero } ] "
                :style="[{ top: product.y + 'px' }, { left: product.x + 'px' }, { 'background-image': 'url(' + product.image + ')' }, { 'background-size': 'contain' } ]"
                :id="'picker-' + product.id"
                :data-item-id="product.id"
              >
              </div>
            </template>
          </div>
        </div>
      `
    }
  });
})(sy);
((sy) => {
  sy.components.push({
    element: 'sy-price-popover',
    component: {
      data() {
        return { }
      },
      methods: {
      },
      computed: {
        collapsed() {
          return this.$store.getters.toolbarsPurchaseCollapsed;
        },
        isVisible() {
          return this.$store.getters.toolbars_ProductPriceIsVisible;
        },
        dollars() {
          return this.$store.getters.product_priceDollars;
        },
        cents() {
          return this.$store.getters.product_priceCents;
        }
      },
      template: `
        <div
          id="shirtPricePopover"
          v-show="!collapsed && isVisible"
          class="price-popover-container"
        >
          <div class="price-popover-bubble">
            <div>
              <span class="price-dollars"> {{ '$' + dollars }} </span>
              <span class="price-cents"> {{ cents }} </span>
            </div>
            <div>
              <span class="price-shipping"> + tax &amp; shipping </span>
            </div>
          </div>
          <div class="price-popover-callout-container">
            <div class="price-popover-callout-arrow-outer"></div>
            <div class="price-popover-callout-arrow-inner"></div>
          </div>
        </div>
      `
    }
  });
})(sy);

((sy) => {
  sy.components.push({
    element: 'sy-product-description-popover',
    component: {
      computed: {
        collapsed() {
          return this.$store.getters.toolbarsPurchaseCollapsed;
        },
        isVisible() {
          return this.$store.getters.toolbars_ProductDescriptionIsVisible
        },
        description() {
          return this.$store.getters.product_fullDescription;
        },
        productName() {
          return this.$store.getters.product_productName;
        }
      },
      methods: {
        onClose() {
          this.$store.dispatch('toolbars_toggleProductPrice');
        }
      },
      template: `
        <div
          id="productDescriptionPopover"
          v-show="!collapsed && isVisible"
          class="product-description-popover-container"
        >
          <div class="product-description-popover-bubble">
            <h2 class="product-title">{{ productName }}</h2>
            <span class="product-close" @click="onClose()">
                <i class="fas fa-times"></i>
            </span>
            <div class="product-description">
              <p v-html="description"></p>
            </div>
          </div>
          <div class="product-description-popover-callout-container">
            <div class="product-description-popover-callout-arrow-outer"></div>
            <div class="product-description-popover-callout-arrow-inner"></div>
          </div>
        </div>
      `
    }
  });
})(sy);

((sy) => {
  sy.components.push({
    element: 'sy-text-menu',
    component: {
      name: 'textMenu',
      data() {
        return {
          maskAreas: [],
          selectedItem: '',
          domObserver: null,
          selectedInputId: ''
        }
      },
      beforeMount() {
        this.$bus.on('product_change', data => { 
          this.reset();
        })
        this.$bus.on('product_loaded', data => {
          this.repositionKbPickers();
        });
      },
      beforeUnmount() {
        this.$bus.off('product_change', data => {
          this.reset();
        });
        if (this.domObserver) {
          this.domObserver.disconnect();
        };
      },
      methods: {
        reset() {
          console.log('text picker menu reset');
          // Stop watching Dom
          if (this.domObserver) {
            this.domObserver.disconnect();
          };

          // Clear reparented KitBuilder child nodes
          this.maskAreas.forEach(area => {
            area.items.forEach(item => {
              item.scope = null;
            });
            area.items.length = 0;
            area.kbElement = null;
            area.scope = null;
            area.placedTextScope = null;

            let addTextContainer = document.getElementById(`addedTextItems${area.id}`);

            // Remove text inputs
            if (addTextContainer) {
              while (addTextContainer.firstChild) {
                addTextContainer.removeChild(addTextContainer.firstChild);
              }
            }

            // Remove text color picker
            let colorPickerContainer = document.getElementById(`textColorPicker${area.id}`);
            if (colorPickerContainer) {
              while (colorPickerContainer.lastChild && colorPickerContainer.childNodes.length > 1) {
                if (!colorPickerContainer.lastChild.classList.contains('close-toolbar'))
                colorPickerContainer.removeChild(colorPickerContainer.lastChild);
              }
            }
          })

          // Clear mask areas
          this.maskAreas.length = 0;
          this.selectedItem = '';
        },
        displayMenu(toolbarMenuItem, e) {
          if (this.selectedItem !== toolbarMenuItem.id) {
            toolbarMenuItem.top = `${e.currentTarget.offsetTop + 40}px`;
            this.selectedItem = toolbarMenuItem.id;
          } else {
            this.selectedItem = '';
          }
        },
        watchDom() {
          let dom = document.querySelector('.sy-toolbar-add-text-menu');

          // Options for the observer (which mutations to observe)
          const config = { attributes: true, childList: true, subtree: true };
          let updateTextItems = this.updateTextItems;

          // Callback function to execute when mutations are observed
          const domMutated = function (mutationsList, observer) {
            for (const mutation of mutationsList) {
              if (mutation.type !== 'attributes') {
                updateTextItems();
              }
            }
          };

          // Create an observer instance linked to the callback function
          this.domObserver = new MutationObserver(domMutated);

          // Start observing the target node for configured mutations
          this.domObserver.observe(dom, config);
        },
        repositionKbPickers() {
          // Check if text areas have already been loaded
          if (this.maskAreas.length > 0) { return; }

          // Set up mask text areas
          let kitBuilderTextAreas = document.querySelectorAll(".kb-wizard-form > ul > li:nth-child(3) .kb-editor-placement");
          let idx = -1;
          kitBuilderTextAreas.forEach(textAreaNode => {
            idx++;

            let textHeadingNode = textAreaNode.querySelector('.kb-editor-heading');
            if (textHeadingNode && textHeadingNode.innerText) {
              let maskArea = {
                text: textHeadingNode.innerText,
                id: this.maskAreas.length,
                kbElement: textAreaNode.parentElement.parentElement,
                isLoaded: false,
                top: 0,
                items: [],
                scope: angular.element(textHeadingNode).scope(),
                placedTextScope: angular.element(textAreaNode.querySelector('.kb-editor-placed-texts')).scope(),
                isColorPickerVisible: false,
                index: idx
              }
              this.maskAreas.push(maskArea);

              let placedTextScope = angular.element(textAreaNode.querySelector('.kb-editor-placed-texts')).scope();
              let texts = placedTextScope.getModel('text', placedTextScope.placement.placementKey);

              texts.forEach(text => {
                let textItem = {
                  text: text.text,
                  id: maskArea.items.length,
                  fontColor: this.extractColorValue(text.fontColor),
                  strokeColor: text.strokeColor,
                  scope: placedTextScope,
                  kbItem: text,
                  isEditMode: false
                }
                maskArea.items.push(textItem);
              });

            }
          });

          setTimeout(() => {
            this.maskAreas.forEach(item => {

              if (item.kbElement) {
                // Reparent placed text
                let addTextContainer = document.getElementById(`addedTextItems${item.id}`);
                let kbPlacedText = item.kbElement.querySelector('.kb-editor-placed-texts');
                addTextContainer.append(kbPlacedText);

                // Reparent placed text color picker
                let colorPickerContainer = document.getElementById(`textColorPicker${item.id}`);
                let kbColorPicker = item.kbElement.querySelector('.kb-editor-text-controls');
                colorPickerContainer.append(kbColorPicker);

                item.isLoaded = true;
              }

            });

            this.watchDom();
          }, 1);

        },
        updateTextItems() {
          // console.log('update text items');
          this.maskAreas.forEach(maskArea => {
            let texts = maskArea.placedTextScope.getModel('text', maskArea.placedTextScope.placement.placementKey);
            if (maskArea.items.length !== texts.length) {
              maskArea.items.length = 0;
              texts.forEach(text => {
                let textItem = {
                  text: text.text,
                  id: maskArea.items.length,
                  fontColor: this.extractColorValue(text.fontColor),
                  strokeColor: text.strokeColor,
                  scope: maskArea.placedTextScope,
                  kbItem: text,
                  isEditMode: false
                }
                maskArea.items.push(textItem);
              });
            }

            // Identify side with text printing and update state for pricing
            let sideText = maskArea.text.toLowerCase();
            let side = sideText.indexOf('front') > 0 ? 'front' :
              sideText.indexOf('back') > 0 ? 'back' :
              sideText.indexOf('left') > 0 ? 'left' :
              sideText.indexOf('right') > 0 ? 'right' : null;

            // Update price for DTG garments that are printed on more than one side
            if (maskArea.items.length > 0 && side !== null) {
              this.$store.commit('product_setTextSide', { side, value: true });
            } else {
              this.$store.commit('product_setTextSide', { side, value: false });
            }
          })
        },
        onColorChange(maskArea, index, event) {
          const selectedColor = event.target.getAttribute('kb-bg-color');
          if (selectedColor) {
            maskArea.items[index].fontColor = this.extractColorValue(selectedColor);
          }
        },
        onAddNewText(maskArea) {
          maskArea.scope.addText(maskArea.scope.placement.placementKey);
        },
        onDoneEditing() {
          item.isEditMode = false;
        },
        onDeleteText(item) {
          // item.scope.deleteItem(item.kbItem)
          // ToDo: remove item from array
        },
        onFocusDisplayColorPicker(maskArea, index, e) {
          e.preventDefault();
          e.stopPropagation();

          if (e.target.type == "text") {
            if (maskArea.text.toLowerCase().indexOf('front') > -1) {
              // Rotate model to front
              angular.element(document.querySelector('.kb-preview-panel')).scope().changeView(0);

            } else if (maskArea.text.toLowerCase().indexOf('back') > -1) {
              // Rotate model to back
              angular.element(document.querySelector('.kb-preview-panel')).scope().changeView(1);
            }

            this.selectedInputId = e.target.id;
            maskArea.isColorPickerVisible = true;
            if (maskArea.isColorPickerVisible) {
              let currentInput = angular.element(document.getElementById(this.selectedInputId));
              currentInput.triggerHandler('mousedown');
              maskArea.top = `${e.target.offsetTop + 30}px`;
            }
          } else if (e.target.tagName.toLowerCase() == 'span' && e.target.classList.contains("kb-tile-picker-tile")) {
            let inputs = document.querySelectorAll(`#maskAreaContainer${maskArea.id} input`);
            let idx = 0;
            for (let cnt = 0; cnt < inputs.length; cnt++) {
              if (inputs[cnt].id === this.selectedInputId) {
                idx = cnt;
                break;
              }
            }

            this.onColorChange(maskArea, idx, e);
            return;
          } else {
            return;
          }

          this.maskAreas.forEach(i => {
            if (i.id !== maskArea.id) {
              i.isColorPickerVisible = false;
            }
          });
        },

        onColorPickerArrowClick(maskArea, index, e) {
          e.preventDefault();
          e.stopPropagation();

          maskArea.isColorPickerVisible = !maskArea.isColorPickerVisible;
          if (maskArea.isColorPickerVisible) {
            let inputs = document.querySelectorAll(`#maskAreaContainer${maskArea.id} input`);
            let currentInput = angular.element(inputs[index]);
            this.selectedInputId = inputs[index].id;
            currentInput.triggerHandler('mousedown');
            maskArea.top = `${e.currentTarget.offsetTop + 23}px`;
          }

          this.maskAreas.forEach(x => {
            if (x.id !== maskArea.id) {
              x.isColorPickerVisible = false;
            }
          });

          // KitBuildre - use this to switch to front or back
          // changeView(1) - back
          // changeView(0) - front
        },

        closeColorPicker(menuItem, e) {
          e.preventDefault();
          e.stopPropagation();
          menuItem.isColorPickerVisible = false;
        },
        closeMenu() {
          this.$store.commit("toolbar_ClearSelectedTool");
        },
        extractColorValue(colorValue) {
          if (colorValue.substring(0, 1) === '#')
          {
            return colorValue;
          } else if (colorValue.startsWith('kb-cmyk')) {
            return colorValue.substring(8, 15);
          }
          return '#fff';
        }
      },
      template: `
        <div class="sy-toolbar-add-text-menu">
          <div class="close-toolbar" @click="closeMenu()"></div>
          <div v-for="(maskArea, index) in maskAreas" :key="maskArea.id" @click="onFocusDisplayColorPicker(maskArea, index, $event)">
            
            <!-- This contains the text inputs for that clip mask area -->
            <div :id="'maskAreaContainer' + maskArea.id" class="added-text-container">
              <div :id="'addedTextItems' + maskArea.id"></div>
              <div :id="'textColorPicker' + maskArea.id"
                :v-show="maskArea.isColorPickerVisible"
                class="color-picker-container"
                :style="{ display: maskArea.isColorPickerVisible ? 'block !important' : 'none', top: maskArea.top }"
              >
                <div class="close-toolbar" @click="closeColorPicker(maskArea, $event)"></div>
              </div>
            </div>
            
            <!-- This contains the color picker arrows for -->
            <div class="added-text-color-container">
              <ul>
                <li v-for="(item, index) in maskArea.items">
                  <button 
                    type="button"
                    @click="onColorPickerArrowClick(maskArea, index, $event)">

                    <!-- Outline of arrow -->
                    <i class="fas fa-caret-down outer-arrow"></i>

                    <!-- Inside color of arrow -->
                    <i 
                      class="fas fa-caret-down inner-arrow" 
                      :style="{ 'color': item.fontColor }"
                    ></i>
                  </button>
                </li>
              </ul>
            </div>

            <div class="add-text-button-container" style="z-index: 10">
              <span>{{ maskArea.text }}</span>
              <button type="button" @click="onAddNewText(maskArea)">
                <i class="fas fa-plus"></i>
              </button>
            </div>
          </div>
        </div>
      `
    }
  });
})(sy);

((sy) => {
  sy.stateModules.push({
    name: 'checkout',
    module: {
      state: () => ({
        isVisible: false,
        kitBuilderSizes: [],
        sizes: [],
        materials: [],
        lineItems: []
      }),
      mutations: {
        checkout_ToggleVisibility: (state, visible) => state.isVisible = visible,
        checkout_KitBuilderSizes: (state, kbSizes) => state.kitBuilderSizes = kbSizes,
        checkout_setLineItems: (state, lineItems) => state.lineItems = lineItems,
        checkout_setSizes: (state, sizes) => state.sizes = sizes,
        checkout_setMaterials: (state, materials) => state.materials = materials,
        checkout_removeItem: (state, index) => state.lineItems.splice(index, 1)
      },
      actions: {
        checkoutHide: (transaction) => {
          transaction.commit('checkout_ToggleVisibility', false);
          transaction.dispatch('toolbars_show');

          const kb = document.getElementById('kitBuilder');
          if (kb) { kb.classList.remove('shrink-kit-builder'); }
        },
        checkoutShow: (transaction) => {
          transaction.commit('checkout_ToggleVisibility', true);
          transaction.dispatch('toolbars_hide');

          const kb = document.getElementById('kitBuilder');
          if (kb) { kb.classList.add('shrink-kit-builder'); }

          if (transaction.state.lineItems.length === 0) {
            transaction.dispatch('checkout_addRow');
          }
        },

        checkout_getSizesFromKb(transaction) {
          // Get a handle to the scope of the quantities inputs
          let selector = '.kb-field-teamdetails > div > div.kb-wizard-form-field.kb-wizard-form-field-full-width.ng-scope > div > div > div.kb-pane-aggregate > div:nth-child(1) > div > table > tbody > tr:nth-child(4) > td.kb-table-cell.kb-table-cell-number.kb-aggregate-size-quantity > input';
          let scope = angular.element(document.querySelector(selector)).scope();
            if (!scope) {
            return;
          }

          let sizes = new Set();
          let materials = new Set();
          scope.sizes.forEach(size => {
            let values = size.name.split('_');
            if (values.length > 1) {
              materials.add({ name: values[1] });
            }
            sizes.add({ name: values[0] });
          })

          transaction.commit('checkout_setSizes', [...sizes].filter((v, i, a) => a.findIndex(t => (t.name === v.name)) === i));
          transaction.commit('checkout_setMaterials', [...materials].filter((v,i,a)=>a.findIndex(t=>(t.name === v.name))===i));

          transaction.dispatch('checkout_syncQuantityFromKitBuilder');
        },

        checkout_syncQuantityFromKitBuilder(transaction) {
          let selector = '.kb-field-teamdetails > div > div.kb-wizard-form-field.kb-wizard-form-field-full-width.ng-scope > div > div > div.kb-pane-aggregate > div:nth-child(1) > div > table > tbody > tr:nth-child(4) > td.kb-table-cell.kb-table-cell-number.kb-aggregate-size-quantity > input';
          let scope = angular
            .element(document.querySelector(selector))
            .scope();
  
          if (!scope) {
            return;
          }
  
          let lineItems = [];
          const teamSizes = scope.teamDetailSizes();
          const kbAvailableSizes = scope.sizes;

          for (const property in teamSizes) {
            if (teamSizes[property] > 0) {

              const kbSize = kbAvailableSizes.find(x => x.id == property);
              const splitSize = kbSize.name.split('_');
              let sizeName = splitSize[0];
              let materialName = splitSize.length > 1 ? splitSize[1] : '';

              lineItems.push({
                id: 0,
                size: sizeName,
                material: materialName,
                qty: teamSizes[property],
                price: yba.currentProduct.price.PriceValue
              });
            }
          }

          transaction.commit('checkout_setLineItems', lineItems);
        },

        checkout_syncQuantityToKitBuilder(transaction) {
          let selector = '.kb-field-teamdetails > div > div.kb-wizard-form-field.kb-wizard-form-field-full-width.ng-scope > div > div > div.kb-pane-aggregate > div:nth-child(1) > div > table > tbody > tr:nth-child(4) > td.kb-table-cell.kb-table-cell-number.kb-aggregate-size-quantity > input';
          let scope = angular.element(document.querySelector(selector)).scope();
          if (!scope) {
            return;
          }
  
          // Iterate over team sizes in KitBuilder
          // Filter the list of line items to items that have matching "size|material"
          // Sum those quantities and write them back to the kit builder TeamSize
          const teamSizes = scope.teamDetailSizes();
          const hasMaterials = transaction.getters.checkout_hasMaterials;
          scope.sizes.forEach(size => {
            let qty = transaction.state
              .lineItems
              .filter(li => (hasMaterials ? `${li.size}_${li.material}` : li.size) == size.name)
              .reduce((accumulator, x) => accumulator + x.qty, 0);

            teamSizes[size.id] = +qty;
          });
        },

        checkout_addRow(transaction) {
          // let selectedSizes = transaction.state.lineItems.map(x => x.size);
          // let notSelectedSizes = transaction.state.sizes.filter(size => !selectedSizes.includes(size));
          // if (notSelectedSizes.length === 0) { return; }
          transaction.state.lineItems.push({
            id: 0,
            style: 'M',
            size: transaction.state.sizes[0].name,
            material: transaction.state.materials.length > 0 ? transaction.state.materials[0].name : "",
            qty: 1,
            price: transaction.getters.product_price
          });

          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        },

        checkout_removeRow(transaction, removeItem) {
          const idx = transaction.state.lineItems.findIndex(item => item == removeItem);
          transaction.commit('checkout_removeItem', idx);
          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        },

        checkout_itemSizeChange(transaction, { item, size }) {
          item.size = size;
          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        },

        checkout_itemMaterialChange(transaction, { item, material }) {
          item.material = material;
          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        },

        checkout_itemQuantityChanged(transaction, { item, quantity }) {
          const parsedValue = parseInt(quantity, 10);
          item.qty = isNaN(parsedValue) || parsedValue == 0 ? 1 : parsedValue;
          // ToDo: update quantity in store

          transaction.dispatch('checkout_syncQuantityToKitBuilder');
        }

      },
      getters: {
        checkout_Visible: state => state.isVisible,
        checkout_grandSubtotal: state => {
          let total = 0;
          state.lineItems.forEach(item => total += item.price * item.qty);
          return `${total.toFixed(2)}`;
        },
        checkout_missingQuantity: state => {
          let noQuantity = state.lineItems
            .filter(x => parseInt(x.qty, 10) == 0 || isNaN(parseInt(x.qty, 10)))
            .length > 0;
          return noQuantity;
        },
        checkout_items: state => state.lineItems,
        checkout_sizes: state => state.sizes,
        checkout_materials: state => state.materials,
        checkout_hasMaterials: state => state.materials.length > 0,
      }
    }
  });
})(sy);


((sy) => {
  sy.stateModules.push({
    name: 'messageDialog',
    module: {
      state: () => ({
        isVisible: false,
        message: '',
        dialogType: 1,
        title: ''     // 1 = info, 2 = warning, 3 = error
      }),
      mutations: {
        messageDialog_hide(state) {
          state.isVisible = false;
        },
        messageDialog_show(state, { message, dialogType, title }) {
          state.isVisible = true;
          state.message = message || '';
          state.dialogType = dialogType || 1;
          state.title = title || '';
        },
      },
      actions: { 
      },
      getters: {
        messageDialogIsVisible: state => state.isVisible,
        messageDialogTitle: state => state.title,
        messageDialogMessage: state => state.message,
        messageDialogType: state => state.dialogType,
      }
    }
  });
})(sy);
((sy) => {
  sy.stateModules.push({
    name: 'waiting',
    module: {
      state: () => ({
        kitBuilderId: null,
        currentProduct: null,
        sidesWithImages: 0,
        images: {
          front: false,
          back: false,
          left: false,
          right: false
        },
        text: {
          front: false,
          back: false,
          left: false,
          right: false
        }
      }),
      mutations: {
        product_setKitBuilderId(state, kitBuilderId) {
          state.kitBuilderId = kitBuilderId;
        },
        product_setProduct(state, product) {
          state.currentProduct = product;
        },
        product_clearProduct(state) {
          state.currentProduct = null;
          state.kitBuilderId = null;

          state.images.front = false;
          state.images.back = false;
          state.images.left = false;
          state.images.right = false;
          state.text.front = false;
          state.text.back = false;
          state.text.left = false;
          state.text.right = false;
        },
        product_setImageSide(state, { side, value }) {
          state.images[side] = value;
        },
        product_setTextSide(state, { side, value }) {
          state.text[side] = value;
        }
      },
      actions: { 
        product_refreshProduct(transaction) {
          if (!transaction.rootState.splash.isVisible) {
            transaction.commit('waiting_setMessage', 'Getting the 3D model ready ...');
            transaction.dispatch('waiting_show');
          }

          const interval = setInterval(() => {
            console.log('waiting');
            const wrapper = document.querySelector('.kb-vector-wrapper');
            if (wrapper) {
              const isLoading = wrapper.classList.contains('kb-loading');
              if (!isLoading) {
                setTimeout(() => {
                  transaction.dispatch('waiting_hide');
                  sy.syApp.config.globalProperties.$bus.trigger('product_loaded');
                }, 1000)
                clearInterval(interval);
              }
            }
          }, 500);

          // Sample URL - #/customise/89880639?basketIndex=117&customDesignId=92774578
          let hash = window.location.hash;
          hash = hash.replace('#/customise/', ''); 
          let qsIndex = hash.indexOf('?');
          const kitBuilderProductId = hash.substring(0, qsIndex);
          transaction.commit('product_setKitBuilderId', kitBuilderProductId);
          sy.syApp.config.globalProperties.$bus.trigger('product_change', { productId: kitBuilderProductId });

          if (kitBuilderProductId === '' || kitBuilderProductId == null) {
            return;
          }

          let request = {
            method: 'get',
            url: '/api/productsapi/KitBuilderProduct',
            params: {
              kitBuilderId: kitBuilderProductId
            }
          }
          axios(request)
            .then(response => {
              transaction.commit('product_setProduct', response.data);
            });
        }
      },
      getters: {
        product_kitBuilderId: state => state.kitBuilderId,
        product_price: (state, getters) => {
          let price = state.currentProduct ? state.currentProduct.Price.PriceValue : 0;

          // No adjustments for non DTG products
          if (!getters.product_isDtg) {
            return price;
          }

          let printSidesAttribute = state.currentProduct.Attributes.find(x => x.Name.toLowerCase().indexOf('print') > -1);
          if (getters.product_sidesWithPrinting > 0 && printSidesAttribute) {
            // Locate Product Atribute that has a number corresponding to the number of printed sides
            let printSidesValue = printSidesAttribute.Values.find(x => x.Name.indexOf(getters.product_sidesWithPrinting) > -1);
            if (printSidesValue) {
              price += printSidesValue.PriceAdjustmentValue;
            }
          }
          return price;
        },
        product_priceDollars: (state, getters) => {
          const price = getters.product_price.toString().split('.');
          const dollars = price.length > 0 ? price[0] : 0;
          return dollars;
        },
        product_priceCents: (state, getters) => {
          const price = getters.product_price.toString().split('.');
          const cents = price.length > 1 ? (price[1].replace('.', '') + '00').substring(0, 2) : '00';
          return cents;
        },
        product_liveShareEnabled: state => {
          return state.currentProduct && state.currentProduct.LiveShareEnabled === true
        },
        product_lockerRoomEnabled: state => {
          return state.currentProduct && state.currentProduct.LockerRoomEnabled === true
        },
        product_sidesWithPrinting: state => {
          let cnt = 0;
          if (state.images.front || state.text.front) cnt++;
          if (state.images.back || state.text.back) cnt++;
          if (state.images.left || state.text.left) cnt++;
          if (state.images.right || state.text.right) cnt++;
          return cnt;
        },
        product_fullDescription: state => (state.currentProduct && state.currentProduct.FullDescription) ? state.currentProduct.FullDescription : '' ,
        product_productName: state => (state.currentProduct && state.currentProduct.Name) ? state.currentProduct.Name : '',
        product_isDtg: state => (state.currentProduct && state.currentProduct.Tags) ? state.currentProduct.Tags.findIndex(tag => tag == "dtg") > -1 : false,
        product_isSublimation: state => (state.currentProduct && state.currentProduct.Tags) ? state.currentProduct.Tags.findIndex(tag => tag == "sublimation") > -1 : false
      }
    }
  });
})(sy);


((sy) => {
  sy.stateModules.push({
    name: 'responsive',
    module: {
      state: () => ({
        width: 0,
        height: 0,
        device: 4 // 'desktop'
      }),
      mutations: {
        responsive_setResolution(state, { height, width }) {
          state.height = height;
          state.width = width;

          if (width > 1367) {
            state.device = 4; //; 'desktop-wide'
          } else if (width > 1024) {
            state.device = 3; //  'desktop'
          } else if (width > 768) {
            state.device = 2; // 'tablet'
          } else {
            state.device = 1; // 'mobile'
          }
        },
      },
      actions: { 
      },
      getters: {
        responsive_getDevice: state => state.device,
      }
    }
  });
})(sy);


((sy) => {
  sy.stateModules.push({
    name: 'splash',
    module: {
      state: () => ({
        isVisible: true,
        previouslyLoaded: true,
        loadCount: 0
      }),
      mutations: {
        splash_toggleVisible(state, isVisible) {
          state.isVisible = isVisible;
        },
        splash_setPreviouslyLoaded(state, previouslyLoaded) {
          state.previouslyLoaded = previouslyLoaded;
          localStorage.setItem('sy.previouslyLoaded', previouslyLoaded);
          localStorage.setItem('sy.lastLoadDate', new Date());
        },
        splash_incrementLoadCount(state) {
          state.loadCount = state.loadCount + 1;
          localStorage.setItem('sy.loadCount', state.loadCount);
        },
        splash_resetLoadCount(state) {
          state.loadCount = 0;
          localStorage.setItem('sy.loadCount', state.loadCount);
        },
        splash_setLoadCount(state, loadCount) {
          state.loadCount = +loadCount;
        }
      },
      actions: { 
        splash_show: transaction => transaction.commit('splash_toggleVisible', true),
        splash_hide: transaction => {
          transaction.commit('splash_toggleVisible', false);
          transaction.commit('splash_setPreviouslyLoaded', true);
          transaction.commit('splash_incrementLoadCount');
        },
        splash_rehydrateState: transaction => {
          const previouslyLoaded = localStorage.getItem('sy.previouslyLoaded');
          const firstDateLoad = localStorage.getItem('sy.lastLoadDate');
          if (firstDateLoad) {
            const today = new Date().getDate();
            const lastLoadedDay = new Date(firstDateLoad).getDate();
            if (today > lastLoadedDay) {
              transaction.commit('splash_resetLoadCount');
              // Exit, which will show the full animation sequence
              return;
            }
          }
          if (previouslyLoaded === 'true') {
            const loadCount = localStorage.getItem('sy.loadCount');
            transaction.commit('splash_setLoadCount', loadCount > 0 ? loadCount : 0);
            transaction.commit('splash_setPreviouslyLoaded', true);
          }
        }
      },
      getters: {
        splashIsVisible: state => state.isVisible,
        splashPreviouslyLoaded: state => state.previouslyLoaded,
        splashloadCount: state => state.loadCount
      }
    }
  });
})(sy);
((sy) => {
  sy.stateModules.push({
    name: 'waitingState',
    module: {
      state: () => ({
        isVisible: false,
        message: 'Test Message'
      }),
      mutations: {
        waiting_toggleVisible(state, isVisible) {
          state.isVisible = isVisible;
          // Clear message when hiding the spinnger
          state.message = isVisible ? state.message : '';
        },
        waiting_setMessage(state, message) {
          state.message = message;
        }
      },
      actions: { 
        waiting_show: transaction => transaction.commit('waiting_toggleVisible', true),
        waiting_hide: transaction => transaction.commit('waiting_toggleVisible', false),
      },
      getters: {
        waitingIsVisible: state => state.isVisible,
        waitingMessage: state => state.message
      }
    }
  });
})(sy);


((sy) => {

  const defaultSearchMessage = 'Search our library of over 150,000,000 million images.  Enter some key words in the search box to begin.';

  sy.stateModules.push({
    name: 'imagePicker',
    module: {
      state: () => ({
        imageDialog: {
          isVisible: false,
          selectedTab: 1,
          pager: {
            pageSize: 100,
            currentPage: 0,
            pageCount: 0,
            total: 0
          },
          searchFilter: {
            searchQuery: '',
            imageType: 'all',
          },
          searchIsExpanded: true,
          searchInProgress: false,
          searchMessage: defaultSearchMessage,
          images: []
        },
        kitBuilder: {
          images: {
            placeholders: [],
            selectedPlacementKey: ''
          },
        },
      }),
      mutations: {
        imageDialog_ToggleVisibility(state, visible) {
          state.imageDialog.isVisible = visible;
        },
        imageDialog_UpdateSearchQuery(state, searchQuery) {
          state.imageDialog.searchFilter.searchQuery = searchQuery;
        },
        imageDialog_UpdateSearchImageType(state, imageType) {
          state.imageDialog.searchFilter.imageType = imageType;
        },
        imageDialog_ToggleSearchExpanded(state, expanded) {
          state.imageDialog.searchIsExpanded = expanded;
        },
        imageDialog_InsertImages(state, images) {
          state.imageDialog.images = images;
        },
        imageDialog_UpdateMessage(state, message) {
          state.imageDialog.searchMessage = message;
        },
        imageDialog_UpdateSearchInProgress(state, value) {
          state.imageDialog.searchInProgress = value;
        },
        imageDialog_UpdatePagerTotal(state, value) {
          const pager = state.imageDialog.pager;

          pager.total = value;
          pager.pageCount = (pager.total > 0 && pager.pageSize > 0) ? Math.round(pager.total / pager.pageSize) : 0;
        },
        imageDialog_SetPagerPage(state, value) {
          state.imageDialog.pager.currentPage = +value;
        },
        imageDialog_SetSelectedTab(state, tabIndex) {
          state.imageDialog.selectedTab = tabIndex;
        },

        kitBuilderImagePlaceholderInsert(state, placeholder) {
          state.kitBuilder.images.placeholders.push(placeholder);
        },
        kitBuilderImagePlaceholderClear(state) {
          state.kitBuilder.images.placeholders.length = 0;
        },

        kitBuilderImagePlaceholderSelect(state, placeholderKey) {
          state.kitBuilder.images.selectedPlacementKey = placeholderKey;
        },
      },
      actions: {
        imageDialog_NextPage(transaction) {
          const pager = transaction.state.imageDialog.pager;
          if (pager.currentPage + 1 <= pager.pageCount) {
            const nextPage = pager.currentPage < pager.pageCount ? pager.currentPage + 1 : pager.pageCount;
            transaction.commit('imageDialog_SetPagerPage', nextPage);
            transaction.dispatch('imageSearch_executeSearch');
          }
        },
        imageDialog_PreviousPage(transaction) {
          const pager = transaction.state.imageDialog.pager;
          if (pager.currentPage - 1 > 0) {
            const nextPage = pager.currentPage > 1 ? pager.currentPage - 1 : 1;
            transaction.commit('imageDialog_SetPagerPage', nextPage);
            transaction.dispatch('imageSearch_executeSearch');
          }
        },
        imageDialog_SetPage(transaction, page) {
          const pager = transaction.state.imageDialog.pager;
          if (page > 0 && page <= pager.pageCount) {
            transaction.commit('imageDialog_SetPagerPage', page);
            transaction.dispatch('imageSearch_executeSearch');
          }
        },

        imageDialog_ProcessVendorImage(transaction, payload) {
          let imageId = payload.image.id;
          let imageType = payload.image.type;
          transaction.commit('imageDialog_ToggleVisibility', false);
          transaction.dispatch('waiting_show');
          transaction.commit('waiting_setMessage', 'Please wait while we retrieve the high resolution image.');

          axios({
            method: 'get',
            url: `/api/imagesapi/ProcessImage`,
            params: { imageId, imageType }
          }).then((response) => {
            transaction.dispatch('placeImageOnGarment', {
              placementKey: payload.placementKey,
              fileData: response.data
            })
          })
          .catch(function (error) {
            transaction.dispatch('waiting_hide');

            let errorMessage = 'There was a problem uploading and placing this image.';
            if (error.response && error.response.data) {
              if (error.response.data.message) {
                errorMessage = error.response.data.message;
              } else {
                errorMessage = error.response.data;
              }
            }

            transaction.commit('messageDialog_show', {
              message: errorMessage,
              title: 'Error',
              dialogType: 3
            });
            console.log(error);
          });
        },
   
        uploadImageFromLocal(transaction, { file, placementKey }) {
    
          transaction.commit('imageDialog_ToggleVisibility', false);
          transaction.dispatch('waiting_show');
          transaction.commit('waiting_setMessage', 'Please wait while we upload your image.');

          const formData = new FormData();
          formData.append("image", file);
          axios.post('/api/imagesapi/Upload',
            formData,
            {
              headers: {
                'Content-Type': 'multipart/form-data'
              }
            }
          ).then(response => { 
            transaction.dispatch('placeImageOnGarment', {
              placementKey: placementKey,
              fileData: response.data
            })
          }).catch(function (error) {
            transaction.dispatch('waiting_hide');

            let errorMessage = 'There was a problem uploading and placing this image.';
            if (error.response && error.response.data) {
              if (error.response.data.message) {
                errorMessage = error.response.data.message;
              } else {
                errorMessage = error.response.data;
              }
            }

            transaction.commit('messageDialog_show', {
              message: errorMessage,
              title: 'Error',
              dialogType: 3
            });
            console.log(error);
          });
        },

        placeImageOnGarment(transaction, { fileData, placementKey }) {

          transaction.commit('waiting_setMessage', 'Almost there, placing the image on your garment.');

          // Get the Angular scope of the upload input
          let scope = angular
            .element(document.querySelector(`.kb-placement-${placementKey} input`))
            .scope();

          // Call the success method to update the UI with the
          // new image (will display the image in the selector)
          scope.uploadSuccess(fileData);

          // Add the image to the garment
          scope.addImage(
            placementKey,
            fileData.id,
            fileData.bitmapWidth,
            fileData.bitmapHeight
          );
          transaction.dispatch('waiting_hide');
        },

        imageSearch_executeSearch(transaction) {

          const searchFilter = transaction.state.imageDialog.searchFilter;
          const pager = transaction.state.imageDialog.pager;
          transaction.state.imageDialog.pager.currentPage = transaction.state.imageDialog.pager.currentPage > 0 ? transaction.state.imageDialog.pager.currentPage : 1;
          let params = {
            searchQuery: searchFilter.searchQuery,
            pageIndex: pager.currentPage > 0 ? pager.currentPage : 1,
            pageSize: pager.pageSize
          };

          if (searchFilter.imageType !== 'all') {
            params.imageType = searchFilter.imageType;
          }

          transaction.commit('imageDialog_UpdateSearchInProgress', true);
          transaction.commit('imageDialog_UpdateMessage', 'Searching the library ...');

          axios({
            method: 'get',
            url: '/api/imagesapi/search',
            params
          })
          .then((response) => {
            const payload = response.data;
            const images = payload.result.filter(x => x.iseditorial === false);

            transaction.commit('imageDialog_UpdatePagerTotal', payload.count);
            transaction.commit('imageDialog_InsertImages', images);
            transaction.commit('imageDialog_UpdateSearchInProgress', false);
              
            if (payload.result.length > 0) {
              transaction.commit('imageDialog_UpdateMessage', defaultSearchMessage);
              transaction.commit('imageDialog_ToggleSearchExpanded', false);
            } else {
              transaction.commit('imageDialog_UpdateMessage', 'No images were found that match your search.  Please enter a different search and try again.');
              transaction.commit('imageDialog_SetPagerPage', 1);
            }
          })
          .catch(function (error) {
            // console.log(error);
            transaction.commit('imageDialog_UpdateSearchInProgress', false);
            transaction.commit('imageDialog_UpdateMessage', defaultSearchMessage);
          });
        }

      },
      getters: {
        imageDialog_IsVisible: state => state.imageDialog.isVisible,
        imageDialog_PlacementOptions: state => state.kitBuilder.images.placeholders,
        imageDialog_SelectedPlacementKey: state => state.kitBuilder.images.selectedPlacementKey,
        imageDialog_SearchQuery: state => state.imageDialog.searchFilter.searchQuery,
        imageDialog_SearchImageType: state => state.imageDialog.searchFilter.imageType,
        imageDialog_SearchPager: state => state.imageDialog.pager,
        imageDialog_SearchResultImages: state => state.imageDialog.images,
        imageDialog_SearchIsExpanded: state => state.imageDialog.searchIsExpanded,
        imageDialog_SearchMessage: state => state.imageDialog.searchMessage,
        imageDialog_searchInProgress: state => state.imageDialog.searchInProgress,
        imageDialog_selectedTab: state => state.imageDialog.selectedTab,
      }
    }
  });
})(sy);


((sy) => {
  sy.stateModules.push({
    name: 'locker-room',
    module: {
      state: () => ({
      }),
      mutations: {
      },
      actions: { 
        lockerRoom_ShowSave: (transaction) => {
          if (yba.customer.isAuthenticated) {

            const customDesignId = window.location.hash.indexOf("customDesignId");
            if (customDesignId > -1) {
              let resaveButton = angular.element(document.querySelector('.kb-locker-room-buttons-save-update'))
              resaveButton.triggerHandler('click');
              return;
            }
            
            let saveButton = angular.element(document.querySelector('.kb-locker-room-buttons-save-new'))
            if (saveButton) {
              saveButton.triggerHandler('click')
              return;
            }

            console.log('Couldn\'t find save button to click');
            
            return;
          }
          document.getElementById('headerLoginLink').click();
        },
        
        lockerRoom_ShowLockerRoom: (transaction) => {
          if (yba.customer.isAuthenticated) {
            transaction.dispatch('stylePickerHide');
            transaction.dispatch('toolbars_hide');
            transaction.commit('product_clearProduct');
            window.location.hash = '#/locker-room';
            return;
          }
          document.getElementById('headerLoginLink').click();
        }

      },
      getters: {
        // splashIsVisible: state => state.isVisible,
      }
    }
  });
})(sy);
((sy) => {

  const defaultSearchMessage = 'Search the product catalog.  Enter some key words in the search box to begin.';
  const defaultPager = {
    pageSize: 25,
    currentPage: 1,
    totalPages: 0
  };
  const defaultSearch = {
    keywords: '',
    shirts: 'all',
    fits: 'all',
    themes: 'all',
    prints: 'all',
    materials: 'all'
  };

  sy.stateModules.push({
    name: 'productSearch',
    module: {
      state: () => ({
        isVisible: false,
        selectedTab: 1,
        pager: defaultPager,
        searchFilter: defaultSearch,
        searchIsExpanded: true,
        searchInProgress: false,
        searchMessage: defaultSearchMessage,
        products: [],
        isPreviewVisible: false,
        prevewProductIndex: null,
        addProductsInProgress: false,
        isFirstLoad: true,
      }),
      mutations: {
        productSearch_ToggleVisibility: (state, visible) => state.isVisible = visible,
        productSearch_PreviewToggleVisibility: (state, value) => state.isPreviewVisible = value,
        productsSearch_setPrevewProductIndex: (state, value) => state.prevewProductIndex = value,
        productSearch_ToggleSearchExpanded: (state, expanded) => state.searchIsExpanded = expanded,
        productSearch_UpdateMessage: (state, message) => state.searchMessage = message,
        productSearch_UpdateSearchInProgress: (state, value) => state.searchInProgress = value,
        productSearch_SetSelectedTab: (state, tabIndex) => state.selectedTab = tabIndex,
        productSearch_InsertProducts: (state, newProducts) => state.products = state.products.concat(newProducts),
        productSearch_SetAddProductsInProgress: (state, value) => state.addProductsInProgress = value,
        productSearch_UpdatePagination: (state, pager) => state.pager = pager,
        productSearch_SetPagerPage: (state, value) => state.pager.currentPage = +value,
        productSearch_ClearProducts(state) {
          state.products = [];
          state.pager = defaultPager;
        },
        productSearch_SetFilterKeywords: (state, value) => state.searchFilter.keywords = value,
        productSearch_SetFilterShirts: (state, value) => state.searchFilter.shirts = value,
        productSearch_SetFilterFits: (state, value) => state.searchFilter.fits = value,
        productSearch_SetFilterThemes: (state, value) => state.searchFilter.themes = value,
        productSearch_SetFilterPrints: (state, value) => state.searchFilter.prints = value,
        productSearch_SetFilterMaterials: (state, value) => state.searchFilter.materials = value,
        productSearch_SetIsFirstLoad: (state, value) => state.isFirstLoad = value,
      },
      actions: {
        productSearch_ShowDialog(transaction) {
          transaction.commit('productSearch_ToggleVisibility', true)
          if (transaction.state.isFirstLoad) {
            transaction.dispatch('productSearch_executeSearch');
          }
        },
        productSearch_HideDialog(transaction) {
          transaction.commit('productSearch_ToggleVisibility', false)
        },
        productSearch_ShowPreview(transaction) {
          transaction.commit('productSearch_PreviewToggleVisibility', true)
        },
        productSearch_HidePreview(transaction) {
          transaction.commit('productSearch_PreviewToggleVisibility', false)
        },

        productSearch_LoadMoreProducts(transaction) {

          console.log('add products fired.')
          const pager = transaction.state.pager;
          if (transaction.state.addProductsInProgress || pager.currentPage >= pager.totalPages) {
            return;
          }

          console.log('fetch more products.')
          transaction.commit('productSearch_SetAddProductsInProgress', true);

          const nextPage = pager.currentPage < pager.totalPages ? pager.currentPage + 1 : pager.totalPages;

          transaction.commit('productSearch_SetPagerPage', nextPage);
          transaction.dispatch('productSearch_executeSearch');
        },

        productSearch_executeSearch(transaction) {

          const pager = transaction.state.pager;
          const filter = transaction.state.searchFilter;

          const apiUrl = `/api/productsapi/search?&page=${pager.currentPage}&pageSize=${pager.pageSize}`;
          const headers = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          };

          const postData = { 
            Keywords: filter.keywords ? filter.keywords : '',
            Shirts: (filter.shirts !== 'all') ? [filter.shirts] : [],
            Fits: (filter.fits !== 'all') ? [filter.fits] : [],
            Themes: (filter.themes !== 'all') ? [filter.themes] : [],
            Prints: (filter.prints !== 'all') ? [filter.prints] : [],
            Materials: (filter.materials !== 'all') ? [filter.materials] : [],
          };

          transaction.commit('productSearch_UpdateSearchInProgress', true);
          transaction.commit('productSearch_UpdateMessage', 'Searching products ..');

          axios.post(apiUrl, postData, headers)
            .then(response => transaction.dispatch('productSearch_processApiResponse', response))
            .catch(function (error) {
              transaction.commit('productSearch_UpdateSear*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************hInProgress', false);
              transaction.commit('productSearch_UpdateMessage', defaultSearchMessage);
              transaction.commit('productSearch_SetAddProductsInProgress', false);
            });
        },
        productSearch_processApiResponse(transaction, response) {
          const payload = response.data;
          const pager = JSON.parse(response.headers['x-pagination']);

          let products = payload.map(p => {
            return {
              id: p.Id,
              name: p.Name,
              shortDescription: p.ShortDescription,
              fullDescription: p.FullDescription,
              href: `/${p.SeName}/${p.RendererUrl}`,
              hash: `${p.RendererUrl}`,
              image: p.DefaultPictureModel.FullSizeImageUrl
            };
          });

          transaction.commit('productSearch_InsertProducts', products);
          transaction.commit('productSearch_UpdatePagination', pager);
          transaction.commit('productSearch_UpdateSearchInProgress', false);
          transaction.commit('productSearch_SetAddProductsInProgress', false);

          if (payload.length > 0) {
            transaction.commit('productSearch_UpdateMessage', defaultSearchMessage);

            if (!transaction.state.isFirstLoad) {
              transaction.commit('productSearch_ToggleSearchExpanded', false);
            } else {
              transaction.commit('productSearch_SetIsFirstLoad', false);
            }
          } else {
            transaction.commit('productSearch_UpdateMessage', 'No products were found that match your search.  Please enter a different search and try again.');
            transaction.commit('productSearch_SetPagerPage', 1);
          }
        },
        productSearch_SelectProduct(transaction) {
          const product = transaction.state.products[transaction.state.prevewProductIndex];
          const basketIndex = window.location.hash.indexOf('basket');
          const basketIndexFragment = window.location.hash.substring(basketIndex);
          let basketIndexParm = basketIndexFragment.split('&')[0]; // Url may contain additional parameters, split on ampersand
          if (product.hash.indexOf('?') > -1) {
            basketIndexParm = '&' + basketIndexParm;
          } else {
            basketIndexParm = '?' + basketIndexParm;
          }

          sy.syApp.config.globalProperties.$bus.trigger('product_beforeProductChange');

          window.location.hash = product.hash + basketIndexParm;
          
          transaction.dispatch('productSearch_HidePreview');
          transaction.dispatch('productSearch_HideDialog');
        }
      },
      getters: {
        productSearch_IsVisible: state => state.isVisible,
        productSearch_SearchPager: state => state.pager,
        productSearch_SearchIsExpanded: state => state.searchIsExpanded,
        productSearch_SearchMessage: state => state.searchMessage,
        productSearch_searchInProgress: state => state.searchInProgress,
        productSearch_selectedTab: state => state.selectedTab,
        productSearch_IsPreviewVisible: state => state.isPreviewVisible,
        productSearch_PrevewProduct: state => state.prevewProductIndex < state.products.length ? state.products[state.prevewProductIndex] : { },
        productSearch_SearchResultProducts: state => state.products,

        productSearch_FilterKeywords: state => state.searchFilter.keywords,
        productSearch_FilterShirts: state => state.searchFilter.shirts,
        productSearch_FilterFits: state => state.searchFilter.fits,
        productSearch_FilterThemes: state => state.searchFilter.themes,
        productSearch_FilterPrints: state => state.searchFilter.prints,
        productSearch_FilterMaterials: state => state.searchFilter.materials,
      }
    }
  });
})(sy);

((sy) => {

  window.yba = window.yba ||
  {
    sharing: {}
  };

  window.yba.sharing = {
    hub: null,
    peer: null,
    remoteVideoStream: null,
    remoteCanvasStream: null,
    localVideoStream: null,
    initiator: false,
  };

  sy.stateModules.push({
    name: 'webRtc',
    module: {
      state: () => ({
        shareDialogIsVisible: false,
        shareDialogStep: 1,
        shareStreamsAreVisible: false,

        localUserName: '',
        localSignalRId: '',
        localRtcConnectionId: '',

        remoteUserName: '',
        remoteSignalRId: '',
        remoteRtcConnectionId: '',
        remoteSignalReceived: false,

        peerConnectionError: null,
        iceServers: null,
        initiator: false,
        isSharing: false,
        nextStreamType: ''
      }),
      mutations: {
        sharing_setLocalUserName(state, userName) {
          state.localUserName = userName;
        },
        sharing_setLocalSignalRId(state, localSignalRId) {
          state.localSignalRId = localSignalRId;
        },
        sharing_setLocalRtcId(state, localRtcId) {
          state.localRtcConnectionId = localRtcId
        },

        sharing_setRemoteUserName(state, userName) {
          state.remoteUserName = userName;
        },
        sharing_setRemoteSignalRId(state, signalRId) {
          state.remoteSignalRId = signalRId;
        },
        sharing_setRemoteRtcId(state, remoteRtcId) {
          state.remoteRtcConnectionId = remoteRtcId;
        },

        sharing_showDialog(state, dialogStep) {
          state.shareDialogIsVisible = true;
          state.shareDialogStep = dialogStep || 1;
        },

        sharing_hideDialog(state) {
          state.shareDialogIsVisible = false;
        },

        sharing_setDialogStep(state, step) {
          state.shareDialogStep = step;
        },

        sharing_showShareStreams(state) {
          state.shareStreamsAreVisible = true;
        },
        sharing_hideShareStreamsAreVisible(state) {
          state.shareStreamsAreVisible = false;
        },

        sharing_setPeerConnectionError(state, error) {
          state.peerConnectionError = error;
        },

        sharing_setRemoteSignalReceived(state, value) {
          state.remoteSignalReceived = value;
        },

        sharing_setIceServers(state, iceServers) {
          state.iceServers = iceServers;
        },

        sharing_setInitiator(state, initiator) {
          state.initiator = initiator;
          yba.sharing.initiator = initiator;
        },

        sharing_setIsSharing(state, value) {
          state.isSharing = value;
        },

        sharing_setNextStreamType(state, value) {
          state.nextStreamType = value;
        }
      },
      actions: {
        // transaction.dispatch('sharing_createPeer', true);
        // yba.sharing.initiator = initiator;

        async sharing_connectSignalR(transaction) {

          if (yba.sharing.hub && yba.sharing.hub.connection.connectionState == "Connected") {
            return;
          }

          yba.sharing.hub = new signalR.HubConnectionBuilder()
            .withUrl('/signalrtc')
            .build();

          // Receive RTC connection info peer info from
          yba.sharing.hub.on('SendRtcSignal', (remoteSignalRId, remoteRtcId) => {
            // console.log('SignalR RTC Received', remoteSignalRId, remoteRtcId);
            transaction.commit('sharing_setRemoteSignalRId', remoteSignalRId);
            transaction.dispatch('sharing_receiveRemoteRtcSignal', remoteRtcId);
          });
          await yba.sharing.hub.start();

          transaction.commit('sharing_setLocalSignalRId', yba.sharing.hub.connection.connectionId);
        },

        async sharing_receiveRemoteRtcSignal(transaction, remoteRtcId) {
          transaction.commit('sharing_setRemoteRtcId', remoteRtcId);
          yba.sharing.peer.signal(JSON.parse(remoteRtcId));
          // console.log('Peer.signal sent to remote peer.');
        },

        async sharing_getIceServers(transaction) {
          try {
            if (transaction.state.iceServers) { return; }
            
            const response = await axios({
              method: 'get',
              url: `/api/LiveShareApi/IceServers`
            });
              
            const iceServers = response.data;
            transaction.commit('sharing_setIceServers', iceServers);
            // console.log('Ice Servers Retrieved: ', iceServers);
          }
          catch (error) {
            // console.log('Error getting Ice Servers: ', error);
          }
        },

        // Create the RTC Peer Connection
        sharing_createPeer(transaction) {
          if (yba.sharing.peer) {
            return;
          }

          const peer = new SimplePeer({
            initiator: yba.sharing.initiator,
            trickle: true,
            iceServers: transaction.state.iceServers
          });
          yba.sharing.peer = peer;

          peer.on('error', error => { transaction.dispatch('sharing_onPeerError', error); });
          peer.on('signal', localPeerInfo => { transaction.dispatch('sharing_onPeerSignal', localPeerInfo); });
          peer.on('connect', () => { transaction.dispatch('sharing_onPeerConnect'); });
          peer.on('stream', stream => { transaction.dispatch('sharing_onPeerStream', stream); });
          peer.on('data', data => { transaction.dispatch('sharing_onPeerData', data); });
        },

        async sharing_onPeerSignal(transaction, localPeerInfo) {

          // 1. Save the local RTC connection info
          const localPeerRtcConnection = JSON.stringify(localPeerInfo);
          transaction.commit('sharing_setLocalRtcId', localPeerRtcConnection);

          // 2. Send the local RTC connection info to the peer via SginalR
          // console.log('Transmitting Web RTC via SignalR to Peer', localPeerInfo);
          try {
            await yba.sharing.hub
              .invoke('SendRtcSignal', localPeerRtcConnection, transaction.state.remoteSignalRId);
          }
          catch (err) {
            console.log(err);
            transaction.commit('sharing_setPeerConnectionError', err);

            // Show error to user
            transaction.commit('sharing_showDialog', 5);
          }
        },

        sharing_onPeerConnect(transaction) {
          console.log('Peer connected to remote');
          yba.sharing.peer.send('Hello Peer! ' + Math.random());
          sy.syApp.config.globalProperties.$bus.trigger('sharing_start');

          // Display prompt to share stream
          transaction.commit('sharing_showDialog', 4);
        },

        sharing_onPeerError(transaction, error) {
          console.log('Simple Peer Error: ', error);
          transaction.commit('sharing_setPeerConnectionError', error);

          // Show error to user
          transaction.commit('sharing_showDialog', 5);
        },

        sharing_onPeerStream(transaction, stream) {
          // Display streams
          transaction.commit('sharing_showShareStreams');

          console.log('Peer stream received');

          if (transaction.state.nextStreamType == 'transmit:renderer') {
            yba.sharing.remoteCanvasStream = stream;
            setTimeout(() => {
              sy.syApp.config.globalProperties.$bus.trigger('sharing_playRemoteRenderer', stream);
            }, 100);

            console.log('Sending renderer acknowledgement');
            yba.sharing.peer.send('acknowledge:renderer');
          } else if (transaction.state.nextStreamType == 'transmit:camera') {
            yba.sharing.remoteVideoStream = stream;
            setTimeout(() => {
              sy.syApp.config.globalProperties.$bus.trigger('sharing_playRemoteVideo', stream);
            }, 100);

            console.log('Sending renderer acknowledgement');
            yba.sharing.peer.send('acknowledge:camera');
          }
        },

        sharing_onPeerData(transaction, data) {
          const value = new TextDecoder("utf-8").decode(data);
          console.log('received data', value);

          if (value.indexOf('transmit') > -1) {
            transaction.commit('sharing_setNextStreamType', value);
            return;
          }

          if (value.indexOf('acknowledge') > -1) {
            transaction.dispatch('sharing_streamAcknowledged', value);
            return;
          }
          
          if (value == 'stop' || data == 'stop') {
            console.log('Sharing stopped by remote.');
            transaction.dispatch('sharing_stopShare');
            return;
          } 
        },

        sharing_startStreamSharing(transaction) {
          transaction.commit('sharing_setIsSharing', true);

          // Display streams
          transaction.commit('sharing_showShareStreams');

          // 3D renderer stream
          transaction.dispatch('sharing_shareRenderer');

          console.log('Hide share dialog');
          transaction.commit('sharing_hideDialog');
        },

        sharing_shareRenderer(transaction) {
          console.log('start streaming renderer');
          try {
            yba.sharing.peer.send('transmit:renderer');

            const canvas = document.querySelector('canvas');
            const canvasStream = canvas.captureStream(30);

            // let options = {
            //   audioBitsPerSecond : 128000,
            //   videoBitsPerSecond : 2500000,
            //   mimeType : 'video/mp4'
            // }
            // let mediaRecorder = new MediaRecorder(canvasStream,options);
            // debugger;

            yba.sharing.localCanvasStream = canvasStream;
            yba.sharing.peer.addStream(canvasStream);
            console.log('Canvas stream added to peer');
          } catch (err) {
            console.log('Canvas renderer stream error: ', err);
          }
        },

        async sharing_shareCamera(transaction) {
          console.log('start streaming camera');
          try {
            yba.sharing.peer.send('transmit:camera');

            if (!navigator || !navigator.mediaDevices) return;
            const videoStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });

            // Save reference to the stream
            yba.sharing.localVideoStream = videoStream;
            yba.sharing.peer.addStream(videoStream);

            sy.syApp.config.globalProperties.$bus.trigger('sharing_playLocalVideo', videoStream);

            console.log('Video stream added to peer');
          } catch (err) {
            console.log('video stream error: ', err)
          }
        },

        sharing_streamAcknowledged(transaction, data) {

          if (data.indexOf('renderer') > -1) {
            // After the stream has been acknowledged by remote:
            // Rotate the renderer from front 
            // This will create some activity to update the canvas on the remote computer
            setTimeout(() => { 
              angular.element(document.querySelector('.kb-preview-panel')).scope().changeView(1);
              setTimeout(() => angular.element(document.querySelector('.kb-preview-panel')).scope().changeView(0), 1000);
            }, 1000);

            // Video Camera Stream
            if (yba.sharing.localVideoStream == null) {
              transaction.dispatch('sharing_shareCamera');
            }
          }
        },
        
        sharing_pauseSharing(transaction) {
          transaction.dispatch("sharing_stopShareRenderer");
        },

        sharing_stopShare(transaction) {
          if (yba.sharing.peer) {
            transaction.commit('sharing_setIsSharing', false);

            transaction.commit('sharing_hideShareStreamsAreVisible');
            yba.sharing.peer.send('stop');

            transaction.dispatch('sharing_stopShareVideo');
            transaction.dispatch('sharing_stopShareRenderer');

            yba.sharing.peer.destroy();

            sy.syApp.config.globalProperties.$bus.trigger('sharing_end');
            yba.sharing.peer = null;
          }
        },

        sharing_stopShareRenderer() {
          try {
            console.log('Stop sharing renderer.');
            if (yba.sharing.localCanvasStream) {
              const tracks = yba.sharing.localCanvasStream.getTracks();
              tracks.forEach(function (track) {
                track.stop();
              });
              yba.sharing.peer.removeStream(yba.sharing.localCanvasStream);
              yba.sharing.localCanvasStream = null;
            }
          } catch (e) {
            console.error('Error stopping local canvas renderer share.', e);
          }
        },

        sharing_stopShareVideo() {
          try {
            if (yba.sharing.localVideoStream) {
              const tracks = yba.sharing.localVideoStream.getTracks();
              tracks.forEach(function (track) {
                track.stop();
              });
              yba.sharing.peer.removeStream(yba.sharing.localVideoStream);
              yba.sharing.localVideoStream = null;
            }
          } catch (e) {
            console.error('Error stopping local video share.', e);
          }
        }
      },
      getters: {
        sharing_shareDialogIsVisible: (state => state.shareDialogIsVisible),
        sharing_shareDialogStep: (state => state.shareDialogStep),
        sharing_shareStreamsAreVisible: (state => state.shareStreamsAreVisible),

        sharing_localSignalRId: (state => state.localSignalRId),
        sharing_localUserName: (state => state.localUserName),

        sharing_remoteSignalRId: (state => state.remoteSignalRId),
        sharing_remoteUserName: (state => state.remoteUserName),

        sharing_isSharing: (state) => state.isSharing,
      },
    },
  });
})(sy);

((sy) => {
  sy.stateModules.push({
    name: 'toolbars',
    module: {
      state: () => ({
        isVisible: false,
        editorToolbar: {
          collapsed: false,
          selectedTool: { name: '', isSubMenuVisible: false }
        },
        purchaseToolbar: {
          collapsed: false,
          productPriceIsVisible: true,
          productDescriptionIsVisible: false
        },
      }),
      mutations: {
        toolbar_ToggleVisibility(state, visible) {
          state.isVisible = visible;
        },
        toolbar_SetCollapse(state, { toolbar, collapsed }) {
          if (toolbar == 'editorToolbar') {
            state.editorToolbar.collapsed = collapsed;
          } else {
            state.purchaseToolbar.collapsed = collapsed;
          }
        },
        toolbar_ToggleCollapse(state, { toolbar }) {
          if (toolbar == 'editorToolbar') {
            state.editorToolbar.collapsed = !state.editorToolbar.collapsed;
          } else {
            state.purchaseToolbar.collapsed = !state.purchaseToolbar.collapsed;
          }
        },
        toolbar_SetSelectedTool(state, tool) {
          state.editorToolbar.selectedTool = tool;
        },
        toolbar_ClearSelectedTool(state) {
          state.editorToolbar.selectedTool = { name: '', isSubMenuVisible: false };
        },
        toolbar_Purchase_SetProductDescriptionVisible(state, value) {
          state.purchaseToolbar.productDescriptionIsVisible = value;
        },
        toolbar_Purchase_SetPriceVisible(state, value) {
          state.purchaseToolbar.productPriceIsVisible = value;
        }
      },
      actions: {
        toolbars_show: (transaction) => {
          if (!transaction.rootState.splash.isVisible) {
            transaction.commit('toolbar_ToggleVisibility', true);
          }
        },
        toolbars_hide: (transaction) => transaction.commit('toolbar_ToggleVisibility', false),
        toolbars_collapse: (transaction, { toolbar }) => transaction.commit('toolbar_SetCollapse', { toolbar, collapsed: true }),
        toolbars_expand: (transaction, { toolbar }) => transaction.commit('toolbar_SetCollapse', { toolbar, collapsed: false }),
        toolbars_toggle: (transaction, { toolbar }) => transaction.commit('toolbar_ToggleCollapse', { toolbar }),
        toolbars_toggleProductPrice(transaction){ 
          if (transaction.state.purchaseToolbar.productDescriptionIsVisible) {
            transaction.commit('toolbar_Purchase_SetProductDescriptionVisible', false);
            transaction.commit('toolbar_Purchase_SetPriceVisible', true);
          } else {
            transaction.commit('toolbar_Purchase_SetProductDescriptionVisible', true);
            transaction.commit('toolbar_Purchase_SetPriceVisible', false);
          }
        }
      },
      getters: {
        toolbarsVisible: state => state.isVisible,
        toolbarsEditCollapsed: state => state.editorToolbar.collapsed,
        toolbarsPurchaseCollapsed: state => state.purchaseToolbar.collapsed,
        toolbarsEditSelectedTool: state => state.editorToolbar.selectedTool,
        toolbars_ProductPriceIsVisible: state => state.purchaseToolbar.productPriceIsVisible,
        toolbars_ProductDescriptionIsVisible: state => state.purchaseToolbar.productDescriptionIsVisible,
      }
    }
  });
})(sy);
(sy => {
  sy.stateModules.push({
    name: 'stylePicker',
    module: {
      state: () => ({
        isVisible: false,
        styles: [],
        matrix: [],
        currentOffset: 0,
        imageWidth: 270,
        pagination: {
          CurrentPage: 0,
          TotalPages: 0,
          PageSize: 15,
          TotalCount: 0,
          HasPrevious: false,
          HasNext: false
        }
      }),
      mutations: {
        stylePickerToggleVisibility: (state, visible) => state.isVisible = visible,
        stylePickerAppendStyles: (state, styles) => state.styles = state.styles.concat(styles),
        stylePickerUpdateMatrix: (state, matrix) => state.matrix = state.matrix.concat(matrix),
        stylePickerUpdateOffset: (state, offset) => state.currentOffset = offset,
        stylePickerUpdatePagination: (state, pagination) => state.pagination = pagination,
        stylePickerUpdateHero: (state, { index, value }) => state.matrix[index].hero = value
      },
      actions: {
        stylePickerHide: (transaction) => transaction.commit('stylePickerToggleVisibility', false),
        stylePickerShow: (transaction) => {
          if (transaction.state.styles.length == 0) {
            transaction.dispatch('stylePickerFetchStyles');
            return;
          }
          transaction.commit('stylePickerToggleVisibility', true);
        },
        stylePickerSetHero(transaction, heroId) {
          let index = transaction.state.matrix.findIndex(m => m.hero === true);
          transaction.commit('stylePickerUpdateHero', { index, value: false });

          index = transaction.state.matrix.findIndex(m => m.id === heroId);
          transaction.commit('stylePickerUpdateHero', { index, value: true });
        },
        stylePickerFetchStyles(transaction) {
          let request = {
            method: 'get',
            url: '/api/productsapi/search',
            params: {
              page: transaction.state.pagination.CurrentPage + 1,
              pageSize: transaction.state.pagination.PageSize
            }
          }
          axios(request).then(response => transaction.dispatch('stylePickerAppendStyles', response));
        },

        stylePickerAppendStyles(transaction, response) {

          const payload = response.data;
          const pagination = JSON.parse(response.headers['x-pagination']);

          let products = payload.map(p => {
            return {
              id: p.Id,
              name: p.Name,
              href: `/${p.SeName}/${p.RendererUrl}`,
              hash: `${p.RendererUrl}`,
              image: p.DefaultPictureModel.FullSizeImageUrl
            };
          });
          let shouldInitMatrix = transaction.state.matrix.length === 0;

          transaction.commit('stylePickerAppendStyles', products);
          transaction.commit('stylePickerUpdatePagination', pagination);

          if (shouldInitMatrix) transaction.dispatch('stylePickerInitMatrix');
        },

        stylePickerInitMatrix(transaction) {
          let imgWidth = transaction.state.imageWidth;
          let styles = transaction.state.styles;

          let matrix = [
            { posX: -1, posY: -1, x: -imgWidth, y: -imgWidth, id: styles[0].id, image: styles[0].image, href: styles[0].href, hero: false, hash: styles[0].RendererUrl },
            { posX: 0, posY: -1, x: 0, y: -imgWidth, id: styles[1].id, image: styles[1].image, href: styles[1].href, hero: false, hash: styles[1].RendererUrl },
            { posX: 1, posY: -1, x: imgWidth, y: -imgWidth, id: styles[2].id, image: styles[2].image, href: styles[2].href, hero: false, hash: styles[2].RendererUrl },

            { posX: -1, posY: 0, x: -imgWidth, y: 0, id: styles[3].id, image: styles[3].image, href: styles[3].href, hero: false, hash: styles[3].RendererUrl },
            { posX: 0, posY: 0, x: 0, y: 0, id: styles[4].id, image: styles[4].image, href: styles[4].href, hero: true, hash: styles[4].RendererUrl },
            { posX: 1, posY: 0, x: imgWidth, y: 0, id: styles[5].id, image: styles[5].image, href: styles[5].href, hero: false, hash: styles[5].RendererUrl },

            { posX: -1, posY: 1, x: -imgWidth, y: imgWidth, id: styles[6].id, image: styles[6].image, href: styles[6].href, hero: false, hash: styles[6].RendererUrl },
            { posX: 0, posY: 1, x: 0, y: imgWidth, id: styles[7].id, image: styles[7].image, href: styles[7].href, hero: false, hash: styles[7].RendererUrl },
            { posX: 1, posY: 1, x: imgWidth, y: imgWidth, id: styles[8].id, image: styles[8].image, href: styles[8].href, hero: false, hash: styles[8].RendererUrl }
          ];
          transaction.commit('stylePickerUpdateMatrix', matrix);
          transaction.commit('stylePickerUpdateOffset', matrix.length);
          transaction.commit('stylePickerToggleVisibility', true);
        },

        stylePickerMatrixScrolled(transaction, id) {

          const matrixCoordinates = [
            { x: -1, y: -1 }, // topLeft
            { x: 0, y: -1 },  // topCenter
            { x: 1, y: -1 },  // topRight

            { x: -1, y: 0 }, // middleLeft
            { x: 0, y: 0 },  // middleCenter
            { x: 1, y: 0 },  // middleRight

            { x: -1, y: 1 }, // bottomLeft
            { x: 0, y: 1 },  // bottomCenter
            { x: 1, y: 1 }   // bottomRight
          ];

          const selectedItem = transaction.state.matrix.find(x => x.id === id);
          let offset = transaction.state.currentOffset + 1;
          matrixCoordinates.forEach(coord => {

            let x = selectedItem.posX + coord.x;
            let y = selectedItem.posY + coord.y;
            let state = transaction.state;
            let loaded = state.matrix.find(row => row.posX === x && row.posY === y);

            if (!loaded) {
              // ToDo: need to load more styles
              if (offset < transaction.state.styles.length) {
                const newItem = {
                  posX: x,
                  posY: y, x: x * state.imageWidth,
                  y: y * state.imageWidth,
                  id: state.styles[offset].id,
                  image: state.styles[offset].image,
                  href: state.styles[offset].href,
                  hash: state.styles[offset].hash,
                  hero: false
                };
                transaction.commit('stylePickerUpdateMatrix', [newItem]);
                transaction.commit('stylePickerUpdateOffset', offset);
                offset++;
              }
            }
          });

          // Load more records if we're near the end of the loaded data
          if ((transaction.state.styles.length - offset) < 5 && transaction.state.pagination.HasNext) {
            transaction.dispatch('stylePickerFetchStyles');
          }
        },
      },
      getters: {
        stylePickerVisible: state => {
          return state.isVisible;
        },
        stylePickerMatrix: state => {
          return state.matrix;
        }
      }
    }
  });
})(sy);
((sy) => {

  class ServiceBusEvent{
    constructor(){
        this.events = {};
    }

    on(eventName, fn) {
        this.events[eventName] = this.events[eventName] || [];
        this.events[eventName].push(fn);
    }

    off(eventName, fn) {
        if (this.events[eventName]) {
            for (var i = 0; i < this.events[eventName].length; i++) {
                if (this.events[eventName][i] === fn) {
                    this.events[eventName].splice(i, 1);
                    break;
                }
            };
        }
    }

    trigger(eventName, data) {
        if (this.events[eventName]) {
            this.events[eventName].forEach(function(fn) {
                fn(data);
            });
        }
    }
  }

  // Application State Tree
  const store = new Vuex.Store({});

  // Register state modules
  sy.stateModules.forEach(x => store.registerModule(x.name, x.module));

  // Create the app
  const syApp = Vue.createApp({});
  syApp.config.globalProperties.$bus = new ServiceBusEvent();
  syApp.use(store);
  sy.syApp = syApp;

  // Register components
  sy.components.forEach(c => {
    syApp.component(c.element, c.component);
  });

  // Start the app
  syApp.mount('#syApp');

  // Prevent scroll problem on Mobile
  document.ontouchmove = (e) => e.preventDefault();

})(sy);
